// Simple workaround to avoid trouble between math.h, cmath and intel math.h
#ifdef __PURE_INTEL_C99_HEADERS__
#undef __PURE_INTEL_C99_HEADERS__
#endif // __PURE_INTEL_C99_HEADERS__

#define EXPORT_DLL
#include <iostream>
#include <cstring>
#define INT8_T char
#include "IEEE_Cigre_DLLInterface.h"
#include "RtOpalStruct.h"

#ifdef __cplusplus
extern "C" {
#endif

#include "PMU_clk/PMU_clk_types.h"
#include "PMU_clk/PMU_clk.h"

#ifdef __cplusplus
};
#endif


const int _defaultStrLength = 256;
static char ErrorMessage[_defaultStrLength];

namespace internal {
    RtOpalModelStruct* _rtOpalStruct = NULL;

    RT_MODEL_PMU_clk_T* _rtModel = NULL;
}

extern "C" {

const static StaticESEInputSignal inputs[] = {
        //   Signal name, description, Dimension, Units, input type (refer to IEEE_Cigre_DLLInterface.h)
        {"Xabc",      "",          3,         "",    90}, // 0
        {"Clock",     "",          1,         "",    90}  // 1
};

const static StaticESEOutputSignal outputs[] = {
        //   Signal name, description, Dimension, Units, output type (refer to IEEE_Cigre_DLLInterface.h)
        {"PhXabc",    "",          6,         "",    90}, // 0
        {"PhX1",      "",          2,         "",    90}, // 1
        {"Freq",      "",          1,         "",    90}, // 2
        {"ROCOF",     "",          1,         "",    90}, // 3
        {"Timestamp", "",          1,         "",    90}  // 4
};

const static StaticESEParameter parameters[] = {
        //   Name,         Description, Unit, Default, Min,     Max,    Type ( 0 for parameters which can be modified at any time, 1 for parameters which need to be defined at T0 but cannot be changed.)
        {"bMclass",    "",          "",   0.0,     -1e64,   1e64,   1 },
        {"clk_choice", "",          "",   0.0,     -1e64,   1e64,   1 },
        {"mode",       "",          "",   1.0,     -1e64,   1e64,   1 },
        {"rF0",        "",          "",   50.0,    -1e64,   1e64,   1 },
        {"z",          "",          "",   1.0,     -1e64,   1e64,   1 }
};

const static auto info = StaticExtSimEnvCapi {
        {1,0,0,0},                           // Release number of the API used during code generation
        "PMU_clk",                           // Model name
        "1.0.0.0",                           // Model version
        "OPAL-RT PMU_clk",                   // Model description
        "Version #1",                        // Version control information
        "General Information",               // General information
        "September 30, 2022",                // Model created on
        "JNB",                               // Model created by
        "September 30, 2022",                // Model last modified on
        "JNB",                               // Model last modified by
        "Initial Version",                   // Model modified comment
        "History of Changes: Initial model", // Model modified history
        "",                                  // Code generated on
        " ",                                 // Solver name (can be empty)
        0.00005,                         // Time Step sampling time (sec)
        // Inputs
        2,                                    // Number of Input Signals
        inputs,
        // Outputs
        5,                                   // Number of Output Signals
        outputs,
        // Parameters
        5,                                   // Number of Parameters
        parameters,
        // Number of State Variables
        0,                                   // Number of continuous states
        0,                                   // Size of work variables / misc states
        {0,0,0,0},                           // Simulink model checksum
        NULL,                                // LastErrorMessage
        3,                                   // Mode: EMT = 1, RMS = 2, EMT & RMS = 3, otherwise: 0
        0,                                   // Model contains a loadflow function: 0 = no, 1 = yes
        // new PSS/E Specific entries (MOVED TO USER INPUT AT DLL Import stage)
        "USRMDL",			                 // PSS/E Specific Data - ModelType:
        4,		                             // PSS/E Specific Data - IC Model Type Code
        0,		                             // PSS/E Specific Data - IT Code
        0,                                   // PSS/E Specific Data - DVTYP used in Aux models
        0,                 			         // PSS/E Specific Data - XGNDX used in Aux models
        // New State Variables for each data type
        0,                                   // Number of Integer states
        0,                                   // Number of Float states
        6,                                   // Number of Double states
        {{0}}
};

DLLEXPORT const StaticExtSimEnvCapi *FUNCALLTYPE Model_GetInfo(void) {
    return &info;
}

DLLEXPORT const char_T *FUNCALLTYPE Model_Initialize(InstanceExtSimEnvCapi *simEnv)
{
    if (NULL != simEnv->Extension.UserVoidPtr) {
        // Expect OpalCigreExtension
        internal::_rtOpalStruct = static_cast<RtOpalModelStruct*>(simEnv->Extension.UserVoidPtr);
        std::cout << "Found extension version: " << static_cast<uint32_t>(rtoModelGetVersionMajor(*internal::_rtOpalStruct))
                  << "." << static_cast<uint32_t>(rtoModelGetVersionMinor(*internal::_rtOpalStruct))
                  << "." << static_cast<uint32_t>(rtoModelGetVersionPatch(*internal::_rtOpalStruct)) << "\n";
        if (!rtoModelCheckCompatibility(*internal::_rtOpalStruct)) {
            std::cout << "/!\\ This version is incompatible with the current one: "
                    << RTOPALSTRUCT_VERSION_MAJOR << "."
                    << RTOPALSTRUCT_VERSION_MINOR << "."
                    << RTOPALSTRUCT_VERSION_PATCH << "\n";
            internal::_rtOpalStruct = nullptr;

            std::strncpy(ErrorMessage, "Incompatible OPAL-RT extension found, cannot continue simulation", _defaultStrLength);
            return ErrorMessage;
        }
        else {
            std::cout << " - Initial simulation time: " << rtoGetSimulationTime(*internal::_rtOpalStruct) << "s\n"
                      << " - DLL time step: " << rtoGetTimeStep(*internal::_rtOpalStruct) << "s" << std::endl;
        }
    }
    else {
        std::strncpy(ErrorMessage, "No OPAL-RT extension found, cannot continue simulation", _defaultStrLength);
        return ErrorMessage;
    }

    internal::_rtModel = PMU_clk();
    if (NULL == internal::_rtModel) {
        std::strncpy(ErrorMessage, "Cannot create PMU_clk!", _defaultStrLength);
        return ErrorMessage;
    }

    PMU_clk_initialize(internal::_rtModel);

    return NULL;
}

DLLEXPORT const char_T *FUNCALLTYPE Model_Outputs(InstanceExtSimEnvCapi *simEnv, uint32_T /*IsMajorTimeStep*/)
{
    if (NULL == internal::_rtOpalStruct) {
        std::strncpy(ErrorMessage, "Model not correctly initialized yet", _defaultStrLength);
        return ErrorMessage;
    }

    // Get inputs
    // ----------
    ExtU_PMU_clk_T& PMU_clk_U = *((ExtU_PMU_clk_T *) internal::_rtModel->inputs);

    /* InportID: 0, TaskID: 0 */
    PMU_clk_U.Xabc[0] = simEnv->ExternalInputs[0];
    PMU_clk_U.Xabc[1] = simEnv->ExternalInputs[1];
    PMU_clk_U.Xabc[2] = simEnv->ExternalInputs[2];

    /* InportID: 1, TaskID: 1 */
    PMU_clk_U.Clock = simEnv->ExternalInputs[3];

    // Get tunable parameters
    // ----------------------

    PMU_clk_P.bMclass = simEnv->Parameters[0];
    PMU_clk_P.clk_choice = simEnv->Parameters[1];
    PMU_clk_P.mode = simEnv->Parameters[2];
    PMU_clk_P.rF0 = simEnv->Parameters[3];
    PMU_clk_P.z = simEnv->Parameters[4];

    // Compute outputs
    // ---------------
    PMU_clk_step(internal::_rtModel);

    // output values now
    // -----------------
    ExtY_PMU_clk_T& PMU_clk_Y = *((ExtY_PMU_clk_T *) internal::_rtModel->outputs);

    /* outportid: 0, taskid: 1 */
    simEnv->ExternalOutputs[0] = PMU_clk_Y.PhXabc[0];
    simEnv->ExternalOutputs[1] = PMU_clk_Y.PhXabc[1];
    simEnv->ExternalOutputs[2] = PMU_clk_Y.PhXabc[2];
    simEnv->ExternalOutputs[3] = PMU_clk_Y.PhXabc[3];
    simEnv->ExternalOutputs[4] = PMU_clk_Y.PhXabc[4];
    simEnv->ExternalOutputs[5] = PMU_clk_Y.PhXabc[5];

    /* outportid: 1, taskid: 1 */
    simEnv->ExternalOutputs[6] = PMU_clk_Y.PhX1[0];
    simEnv->ExternalOutputs[7] = PMU_clk_Y.PhX1[1];

    /* outportid: 2, taskid: 1 */
    simEnv->ExternalOutputs[8] = PMU_clk_Y.Freq;

    /* outportid: 3, taskid: 1 */
    simEnv->ExternalOutputs[9] = PMU_clk_Y.ROCOF;

    /* outportid: 4, taskid: 1 */
    simEnv->ExternalOutputs[10] = PMU_clk_Y.Timestamp;

    return NULL;
}

DLLEXPORT const char_T *FUNCALLTYPE Model_Terminate(InstanceExtSimEnvCapi */*pInstanceCapi*/)
{
    if (NULL != internal::_rtModel) {
        PMU_clk_terminate(internal::_rtModel);
    }
    internal::_rtOpalStruct = NULL;

    return NULL;
}


}
