#ifndef UCM_PMU_clk_SIMFCNDECL_H
#define UCM_PMU_clk_SIMFCNDECL_H
/*
 * Simulation functions declarations file for model : PMU_clk
 *
 * Generated on : Mon Feb  3 11:46:33 EST 2020
 *
 * DO NOT EDIT !!!
 *
 * Hypersim (Ucm) : (c) Hydro-Quebec -- 2018
 */

void ucm_PMU_clk_init(HyUCMsimData *simData);
void ucm_PMU_clk_preVNode(HyUCMsimData *simData);
void ucm_PMU_clk_preVNodeIter(HyUCMsimData *simData);
void ucm_PMU_clk_postVNode(HyUCMsimData *simData);
int ucm_PMU_clk_postVNodeIter(HyUCMsimData *simData);
void ucm_PMU_clk_terminate(HyUCMsimData *simData);

#endif
