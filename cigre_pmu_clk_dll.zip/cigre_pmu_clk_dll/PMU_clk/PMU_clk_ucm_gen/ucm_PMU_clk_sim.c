/*-------------------------------------------------------------------------
 * Simulation functions for model : PMU_clk
 *
 * Generated on : Mon Feb  3 11:46:33 EST 2020
 *
 * DO NOT EDIT !!!
 *
 * Hypersim (Ucm) : (c) Hydro-Quebec -- 2018
 *-------------------------------------------------------------------------
 */

#include "HyUCMsimData.h"
#include "ucm_PMU_clk_sim.h"

#ifdef UCM_TEST_COMPILATION
# line 509 "../ucm_PMU_clk.def"
#endif /* UCM_TEST_COMPILATION */
/* 9.3.1 -- User includes */

#define PRECISION 1e-15
#if defined(__cplusplus) && defined(_WIN32)
extern "C" {
#endif
#include "chgSimulinkNames.h"
#if defined(__cplusplus) && defined(_WIN32)
}
#endif

#include <string.h>
#include <float.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#if defined(__cplusplus) && defined(_WIN32)
extern "C" {
#endif
#include "PMU_clk_data.c"
#if defined(__cplusplus) && defined(_WIN32)
}
#endif
#if defined(__cplusplus) && defined(_WIN32)
extern "C" {
#endif
#include "PMU_clk.c"
#if defined(__cplusplus) && defined(_WIN32)
}
#endif

/* 9.3.3 -- Declarations */

typedef struct model_data_PMU_clk{
  RT_MODEL_PMU_clk_T* PMU_clk_M;
  unsigned int	   do_step;		/* Permission to calculate step  = 1*/
  unsigned int	   step_count;	        /* Step counter for hypersim time step */
  unsigned int 	   step_count_simulink; /* Step counter for simulink time step */
  boolean_T EqualTimeStep;
  boolean_T OverrunFlag;
}model_data_PMU_clk;

#define PMU_clk_M model_data_PMU_clk_->PMU_clk_M
#define PMU_clk_U (*(ExtU_PMU_clk_T*)rtmGetU(PMU_clk_M))
#define PMU_clk_Y (*(ExtY_PMU_clk_T*)rtmGetY(PMU_clk_M))
#define PMU_clk_P (*(P_PMU_clk_T*)rtmGetDefaultParam(PMU_clk_M))
#define do_step model_data_PMU_clk_->do_step
#define step_count model_data_PMU_clk_->step_count
#define step_count_simulink model_data_PMU_clk_->step_count_simulink
#define EqualTimeStep model_data_PMU_clk_->EqualTimeStep
#define OverrunFlag model_data_PMU_clk_->OverrunFlag


/* 9.3.4 -- Local functions (static) */

/* Simulation Initialization Function */

void ucm_PMU_clk_init(HyUCMsimData *simData)
{

    /* Begin User code >>>>>>>>>>>>>>>> */

#ifdef UCM_TEST_COMPILATION
# line 574 "../ucm_PMU_clk.def"
#endif /* UCM_TEST_COMPILATION */
/* initialize model memory for multi instance*/
ucmInitData = (char *) malloc(sizeof(model_data_PMU_clk));
model_data_PMU_clk* model_data_PMU_clk_ = (model_data_PMU_clk*) ucmInitData;

if (model_data_PMU_clk_ == NULL)
   return;
   
PMU_clk_M = PMU_clk();
if (PMU_clk_M == NULL) 
   return;

do_step = 1;
step_count = 1;
step_count_simulink = 0;
EqualTimeStep = true;

// check whether Simulink time step and HYPERSIM time step have not the same
if (fabs(5.0E-5 - ucmTimeStep) > PRECISION)
	EqualTimeStep = false;

/* initialize error status */
rtmSetErrorStatus(PMU_clk_M, (NULL));
   
/* Initialize model */
PMU_clk_initialize(PMU_clk_M);

if(rtmGetErrorStatus(PMU_clk_M) != NULL)
   {
   do_step = 0;
   return;
   }

    /* <<<<<<<<<<<<<<< End of User Code */
}


/* Before voltages calculation simulation function */

void ucm_PMU_clk_preVNode(HyUCMsimData *simData)
{

    /* Begin User code >>>>>>>>>>>>>>>> */

#ifdef UCM_TEST_COMPILATION
# line 614 "../ucm_PMU_clk.def"
#endif /* UCM_TEST_COMPILATION */
    /* <<<<<<<<<<<<<<< End of User Code */
}


/* After voltages calculation simulation function */

void ucm_PMU_clk_postVNode(HyUCMsimData *simData)
{

    /* Begin User code >>>>>>>>>>>>>>>> */

#ifdef UCM_TEST_COMPILATION
# line 622 "../ucm_PMU_clk.def"
#endif /* UCM_TEST_COMPILATION */
   model_data_PMU_clk* model_data_PMU_clk_ = (model_data_PMU_clk*) ucmInitData;
   if (model_data_PMU_clk_ == NULL || PMU_clk_M == NULL)
      return;	  
 
   OverrunFlag = false;
 
  /*
   * Do a model step.
   */

  /* Output values remain unchanged when unable to do a step (do_step == 0) */

  if(!do_step)
    return;

  /* Get inputs
     ---------- */

          	    /* InportID: 0, TaskID: 0 */
	
	            PMU_clk_U.Xabc[0] = Xabc_0;
	            PMU_clk_U.Xabc[1] = Xabc_1;
	            PMU_clk_U.Xabc[2] = Xabc_2;
    	    /* InportID: 1, TaskID: 1 */
	
	          PMU_clk_U.Clock = Clock_i;


   /* Get tunable parameters
      --------------------- */

   			
PMU_clk_P.bMclass = (real_T) bMclass_param;
			
PMU_clk_P.clk_choice = (real_T) clk_choice_param;
			
PMU_clk_P.mode = (real_T) mode_param;
			
PMU_clk_P.rF0 = (real_T) rF0_param;
			
PMU_clk_P.z = (real_T) z_param;




    /* Calculate outputs
       ----------------- */

    /****************************
     * Is base step long enough *
     ****************************/

    /* Check for overrun */
	if (OverrunFlag) 
	{
		rtmSetErrorStatus(PMU_clk_M, "Overrun");
		goto error_stop;
	}

	OverrunFlag = true;
	
    /**************************
     * Check for other errors *
     **************************/

    if (rtmGetErrorStatus(PMU_clk_M) != NULL)
    {
        goto error_stop;
    }

    /* Process Step function */
	if(EqualTimeStep)
	   PMU_clk_step(PMU_clk_M); // no degradation mode : use exact inputs' values
	else
		{
		while(step_count_simulink* 5.0E-5 <= step_count* ucmTimeStep) // if tHYPERSIM >= t simulink ==> get inputs
		{		
			// Call Simulink step function with inputs at time tHYPERSIM
			PMU_clk_step(PMU_clk_M);   			
			step_count_simulink ++;
			if(step_count_simulink == 0){
				break;
			}
		}		
		}
	
	/* Indicate task complete */
	OverrunFlag = false;
   
    /* Output values
       ------------- */

#if 5 > 0
  
    /* output values now */


              /* outportid: 0, taskid: 1 */
                      phxabc_0 = pmu_clk_y.phxabc[0];
                      phxabc_1 = pmu_clk_y.phxabc[1];
                      phxabc_2 = pmu_clk_y.phxabc[2];
                      phxabc_3 = pmu_clk_y.phxabc[3];
                      phxabc_4 = pmu_clk_y.phxabc[4];
                      phxabc_5 = pmu_clk_y.phxabc[5];

              /* outportid: 1, taskid: 1 */
                      phx1_0 = pmu_clk_y.phx1[0];
                      phx1_1 = pmu_clk_y.phx1[1];

              /* outportid: 2, taskid: 1 */
                    freq_o = pmu_clk_y.freq;

              /* outportid: 3, taskid: 1 */
                    rocof_o = pmu_clk_y.rocof;

              /* outportid: 4, taskid: 1 */
                    timestamp_o = pmu_clk_y.timestamp;


#endif
  
    

  /*
   * Update step counter
   * -------------------
   */

  step_count += 1;

  return;

/*
 * Error exit!
 * -----------
 */

error_stop:			/* An error occurred */

  do_step = 0;
  PMU_clk_terminate(PMU_clk_M);

  return;


    /* <<<<<<<<<<<<<<< End of User Code */
}


/* Simulation Finalization Function */

void ucm_PMU_clk_terminate(HyUCMsimData *simData)
{

    /* Begin User code >>>>>>>>>>>>>>>> */

#ifdef UCM_TEST_COMPILATION
# line 822 "../ucm_PMU_clk.def"
#endif /* UCM_TEST_COMPILATION */
model_data_PMU_clk* model_data_PMU_clk_ = (model_data_PMU_clk*) ucmInitData;
if (model_data_PMU_clk_ == NULL)
   return;
PMU_clk_terminate(PMU_clk_M);
free(ucmInitData);

    /* <<<<<<<<<<<<<<< End of User Code */
}


/* End of file */

