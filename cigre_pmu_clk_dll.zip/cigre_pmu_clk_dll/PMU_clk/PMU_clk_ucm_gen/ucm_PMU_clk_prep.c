//-------------------------------------------------------------------------
// Preparation functions for model : PMU_clk
//
// Generated on : Mon Feb  3 11:46:33 EST 2020
//
// DO NOT EDIT !!!
//
// Hypersim (Ucm) : (c) Hydro-Quebec -- 2018
//-------------------------------------------------------------------------

#include "hyStruct.h"
#include "HyUCMprepData.h"
#include "ucm_PMU_clk_prep.h"

#ifdef __cplusplus
#  define EXTERN_C_DECLARATION extern "C"
#else
#  define EXTERN_C_DECLARATION
#endif // __cplusplus

#ifdef UCM_TEST_COMPILATION
# line 374 "../ucm_PMU_clk.def"
#endif /* UCM_TEST_COMPILATION */
/* 8.3.1.1 -- User includes */

/* 8.3.1.2 -- Definitions */

/* 8.3.1.3 -- Declarations */

/* 8.3.1.4 -- Local functions (static) */

// Preparation Function

EXTERN_C_DECLARATION void ucm_PMU_clk_prep(HyUCMprepData *prepData)
{

    // Begin User code >>>>>>>>>>>>>>>>

#ifdef UCM_TEST_COMPILATION
# line 392 "../ucm_PMU_clk.def"
#endif /* UCM_TEST_COMPILATION */
    // <<<<<<<<<<<<< End of User Code

}

//End of File
