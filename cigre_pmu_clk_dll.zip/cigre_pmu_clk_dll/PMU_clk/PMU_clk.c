/*
 * PMU_clk.c
 *
 * Third Party Support License -- for use only to support products
 * interfaced to MathWorks software under terms specified in your
 * company's restricted use license agreement.
 *
 * Code generation for model "PMU_clk".
 *
 * Model version              : 1.878
 * Simulink Coder version : 8.13 (R2017b) 24-Jul-2017
 * C source code generated on : Mon Feb  3 11:30:03 2020
 *
 * Target selection: hyperlink_grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->Unspecified (assume 32-bit Generic)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "PMU_clk.h"
#include "PMU_clk_private.h"

static void rate_scheduler(RT_MODEL_PMU_clk_T *const PMU_clk_M);
static
  uint32_T plook_u32d_binckan(real_T u, const real_T bp[], uint32_T maxIndex)
{
  uint32_T bpIndex;

  /* Prelookup - Index only
     Index Search method: 'binary'
     Interpolation method: 'Use nearest'
     Extrapolation method: 'Clip'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'on'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u <= bp[0U]) {
    bpIndex = 0U;
  } else if (u < bp[maxIndex]) {
    bpIndex = binsearch_u32d(u, bp, maxIndex >> 1U, maxIndex);
    if (bp[bpIndex + 1U] - u <= u - bp[bpIndex]) {
      bpIndex++;
    }
  } else {
    bpIndex = maxIndex;
  }

  return bpIndex;
}

static
  uint32_T binsearch_u32d(real_T u, const real_T bp[], uint32_T startIndex,
  uint32_T maxIndex)
{
  uint32_T bpIndex;
  uint32_T iRght;
  uint32_T bpIdx;

  /* Binary Search */
  bpIdx = startIndex;
  bpIndex = 0U;
  iRght = maxIndex;
  while (iRght - bpIndex > 1U) {
    if (u < bp[bpIdx]) {
      iRght = bpIdx;
    } else {
      bpIndex = bpIdx;
    }

    bpIdx = (iRght + bpIndex) >> 1U;
  }

  return bpIndex;
}

/*
 *   This function updates active task flag for each subrate.
 * The function is called at model base rate, hence the
 * generated code self-manages all its subrates.
 */
static void rate_scheduler(RT_MODEL_PMU_clk_T *const PMU_clk_M)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (PMU_clk_M->Timing.TaskCounters.TID[1])++;
  if ((PMU_clk_M->Timing.TaskCounters.TID[1]) > 19) {/* Sample time: [0.001s, 0.0s] */
    PMU_clk_M->Timing.TaskCounters.TID[1] = 0;
  }
}

static real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  int32_T u0_0;
  int32_T u1_0;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else if (rtIsInf(u0) && rtIsInf(u1)) {
    if (u0 > 0.0) {
      u0_0 = 1;
    } else {
      u0_0 = -1;
    }

    if (u1 > 0.0) {
      u1_0 = 1;
    } else {
      u1_0 = -1;
    }

    y = atan2(u0_0, u1_0);
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = atan2(u0, u1);
  }

  return y;
}

static real_T rt_hypotd_snf(real_T u0, real_T u1)
{
  real_T y;
  real_T a;
  a = fabs(u0);
  y = fabs(u1);
  if (a < y) {
    a /= y;
    y *= sqrt(a * a + 1.0);
  } else if (a > y) {
    y /= a;
    y = sqrt(y * y + 1.0) * a;
  } else {
    if (!rtIsNaN(y)) {
      y = a * 1.4142135623730951;
    }
  }

  return y;
}

/*
 * System initialize for action system:
 *    '<Root>/PMU_50Hz_P_25'
 *    '<Root>/PMU_50Hz_P_50'
 *    '<Root>/PMU_50Hz_P_100'
 */
void PMU_clk_PMU_50Hz_P_25_Init(DW_PMU_50Hz_P_25_PMU_clk_T *localDW)
{
  /* InitializeConditions for Buffer: '<S42>/Buffer1' */
  localDW->Buffer1_CircBufIdx = 0;

  /* InitializeConditions for Buffer: '<S42>/Buffer2' */
  localDW->Buffer2_CircBufIdx = 0;

  /* InitializeConditions for Buffer: '<S42>/Buffer1' */
  memset(&localDW->Buffer1_CircBuff[0], 0, 38U * sizeof(creal_T));

  /* InitializeConditions for Buffer: '<S42>/Buffer2' incorporates:
   *  Buffer: '<S42>/Buffer1'
   */
  memset(&localDW->Buffer2_CircBuff[0], 0, 38U * sizeof(creal_T));

  /* InitializeConditions for Buffer: '<S42>/Buffer3' incorporates:
   *  Buffer: '<S42>/Buffer1'
   */
  memset(&localDW->Buffer3_CircBuff[0], 0, 38U * sizeof(creal_T));
  localDW->Buffer3_CircBufIdx = 0;

  /* InitializeConditions for Delay: '<S42>/Delay' */
  localDW->Delay_DSTATE = 0.0;

  /* InitializeConditions for Delay: '<S42>/Delay1' */
  localDW->Delay1_DSTATE = 0.0;

  /* InitializeConditions for S-Function (sdspunwrap2): '<S42>/Unwrap' */
  localDW->Unwrap_FirstStep = true;
  localDW->Unwrap_Cumsum = 0.0;

  /* InitializeConditions for Delay: '<S43>/Delay' */
  memset(&localDW->Delay_DSTATE_p[0], 0, 1000U * sizeof(real_T));
}

/*
 * Output and update for action system:
 *    '<Root>/PMU_50Hz_P_25'
 *    '<Root>/PMU_50Hz_P_50'
 *    '<Root>/PMU_50Hz_P_100'
 */
void PMU_clk_PMU_50Hz_P_25(const real_T rtu_Xabc[3], real_T rtu_Clock, real_T
  rty_PhXabc[6], real_T rty_PhX1[2], real_T *rty_Freq, real_T *rty_ROCOF, real_T
  *rty_Timestamp, B_PMU_50Hz_P_25_PMU_clk_T *localB, const
  ConstB_PMU_50Hz_P_25_PMU_clk_T *localC, DW_PMU_50Hz_P_25_PMU_clk_T *localDW,
  P_PMU_clk_T *PMU_clk_P_e)
{
  int32_T i;
  int32_T yIdx;
  real_T rtb_tArg2_c;
  real_T rtb_Unwrap_c;
  real_T rtb_Bias_h;
  boolean_T rtb_Compare_fj;
  real_T rtb_tArg1_i;
  real_T rtb_Fcn2;
  creal_T rtb_Buffer3_gh[39];
  creal_T rtb_Product_b[39];
  real_T rtb_Divide_re;
  real_T rtb_Divide_im;
  real_T re;
  real_T im;
  real_T rtb_SumofElements_re;
  real_T rtb_SumofElements_im;
  real_T rtb_SumofElements_re_p;
  real_T rtb_SumofElements_im_l;

  /* Bias: '<S41>/Bias' incorporates:
   *  Constant: '<S41>/i2'
   *  Product: '<S41>/Divide2'
   */
  rtb_Bias_h = rtu_Clock * 1000.0 + 1.0;

  /* Product: '<S42>/Divide' */
  rtb_Divide_im = localC->Fcn1 * localC->RealImagtoComplex.im * rtu_Clock;

  /* Math: '<S42>/Math Function' incorporates:
   *  Product: '<S42>/Divide'
   *
   * About '<S42>/Math Function':
   *  Operator: exp
   */
  rtb_tArg2_c = exp(localC->Fcn1 * localC->RealImagtoComplex.re * rtu_Clock);
  if (rtb_Divide_im == 0.0) {
    rtb_Divide_re = rtb_tArg2_c;
    rtb_Divide_im = 0.0;
  } else {
    rtb_Divide_re = rtb_tArg2_c * cos(rtb_Divide_im);
    rtb_Divide_im = rtb_tArg2_c * sin(rtb_Divide_im);
  }

  /* End of Math: '<S42>/Math Function' */

  /* Product: '<S42>/Divide1' incorporates:
   *  Gain: '<S42>/Gain1'
   */
  localB->Divide1[0].re = 1.4142135623730951 * rtu_Xabc[0] * rtb_Divide_re;
  localB->Divide1[0].im = 1.4142135623730951 * rtu_Xabc[0] * rtb_Divide_im;
  localB->Divide1[1].re = 1.4142135623730951 * rtu_Xabc[1] * rtb_Divide_re;
  localB->Divide1[1].im = 1.4142135623730951 * rtu_Xabc[1] * rtb_Divide_im;
  localB->Divide1[2].re = 1.4142135623730951 * rtu_Xabc[2] * rtb_Divide_re;
  localB->Divide1[2].im = 1.4142135623730951 * rtu_Xabc[2] * rtb_Divide_im;

  /* Buffer: '<S42>/Buffer1' */
  for (i = 0; i < 38 - localDW->Buffer1_CircBufIdx; i++) {
    rtb_Product_b[i] = localDW->Buffer1_CircBuff[localDW->Buffer1_CircBufIdx + i];
  }

  yIdx = 38 - localDW->Buffer1_CircBufIdx;
  for (i = 0; i < localDW->Buffer1_CircBufIdx; i++) {
    rtb_Product_b[yIdx + i] = localDW->Buffer1_CircBuff[i];
  }

  yIdx += localDW->Buffer1_CircBufIdx;
  rtb_Product_b[yIdx] = localB->Divide1[0];
  localDW->Buffer1_CircBuff[localDW->Buffer1_CircBufIdx] = localB->Divide1[0];
  localDW->Buffer1_CircBufIdx++;
  if (localDW->Buffer1_CircBufIdx >= 38) {
    localDW->Buffer1_CircBufIdx -= 38;
  }

  /* End of Buffer: '<S42>/Buffer1' */

  /* Sum: '<S44>/Sum of Elements' */
  re = -0.0;
  im = 0.0;
  for (i = 0; i < 39; i++) {
    /* Product: '<S44>/Product' incorporates:
     *  Constant: '<S44>/i2'
     */
    rtb_Buffer3_gh[i].re = PMU_clk_ConstP.pooled1[i] * rtb_Product_b[i].re;
    rtb_Buffer3_gh[i].im = PMU_clk_ConstP.pooled1[i] * rtb_Product_b[i].im;

    /* Sum: '<S44>/Sum of Elements' incorporates:
     *  Product: '<S44>/Product'
     */
    re += rtb_Buffer3_gh[i].re;
    im += rtb_Buffer3_gh[i].im;
  }

  /* Sum: '<S44>/Sum of Elements' */
  rtb_SumofElements_re = re;
  rtb_SumofElements_im = im;

  /* Buffer: '<S42>/Buffer2' */
  for (i = 0; i < 38 - localDW->Buffer2_CircBufIdx; i++) {
    rtb_Buffer3_gh[i] = localDW->Buffer2_CircBuff[localDW->Buffer2_CircBufIdx +
      i];
  }

  yIdx = 38 - localDW->Buffer2_CircBufIdx;
  for (i = 0; i < localDW->Buffer2_CircBufIdx; i++) {
    rtb_Buffer3_gh[yIdx + i] = localDW->Buffer2_CircBuff[i];
  }

  yIdx += localDW->Buffer2_CircBufIdx;
  rtb_Buffer3_gh[yIdx] = localB->Divide1[1];
  localDW->Buffer2_CircBuff[localDW->Buffer2_CircBufIdx] = localB->Divide1[1];
  localDW->Buffer2_CircBufIdx++;
  if (localDW->Buffer2_CircBufIdx >= 38) {
    localDW->Buffer2_CircBufIdx -= 38;
  }

  /* End of Buffer: '<S42>/Buffer2' */

  /* Sum: '<S45>/Sum of Elements' */
  re = -0.0;
  im = 0.0;
  for (i = 0; i < 39; i++) {
    /* Product: '<S45>/Product' incorporates:
     *  Constant: '<S45>/i2'
     */
    rtb_Product_b[i].re = PMU_clk_ConstP.pooled1[i] * rtb_Buffer3_gh[i].re;
    rtb_Product_b[i].im = PMU_clk_ConstP.pooled1[i] * rtb_Buffer3_gh[i].im;

    /* Sum: '<S45>/Sum of Elements' incorporates:
     *  Product: '<S45>/Product'
     */
    re += rtb_Product_b[i].re;
    im += rtb_Product_b[i].im;
  }

  /* Sum: '<S45>/Sum of Elements' */
  rtb_SumofElements_re_p = re;
  rtb_SumofElements_im_l = im;

  /* Buffer: '<S42>/Buffer3' */
  for (i = 0; i < 38 - localDW->Buffer3_CircBufIdx; i++) {
    rtb_Buffer3_gh[i] = localDW->Buffer3_CircBuff[localDW->Buffer3_CircBufIdx +
      i];
  }

  yIdx = 38 - localDW->Buffer3_CircBufIdx;
  for (i = 0; i < localDW->Buffer3_CircBufIdx; i++) {
    rtb_Buffer3_gh[yIdx + i] = localDW->Buffer3_CircBuff[i];
  }

  yIdx += localDW->Buffer3_CircBufIdx;
  rtb_Buffer3_gh[yIdx] = localB->Divide1[2];
  localDW->Buffer3_CircBuff[localDW->Buffer3_CircBufIdx] = localB->Divide1[2];
  localDW->Buffer3_CircBufIdx++;
  if (localDW->Buffer3_CircBufIdx >= 38) {
    localDW->Buffer3_CircBufIdx -= 38;
  }

  /* End of Buffer: '<S42>/Buffer3' */

  /* Sum: '<S46>/Sum of Elements' */
  re = -0.0;
  im = 0.0;
  for (i = 0; i < 39; i++) {
    /* Product: '<S46>/Product' incorporates:
     *  Constant: '<S46>/i2'
     */
    rtb_Product_b[i].re = PMU_clk_ConstP.pooled1[i] * rtb_Buffer3_gh[i].re;
    rtb_Product_b[i].im = PMU_clk_ConstP.pooled1[i] * rtb_Buffer3_gh[i].im;

    /* Sum: '<S46>/Sum of Elements' incorporates:
     *  Product: '<S46>/Product'
     */
    re += rtb_Product_b[i].re;
    im += rtb_Product_b[i].im;
  }

  /* Gain: '<S42>/Gain5' incorporates:
   *  Gain: '<S42>/Sequence Gain2'
   *  Gain: '<S42>/Sequence Gain3'
   *  Sum: '<S42>/Add'
   *  Sum: '<S46>/Sum of Elements'
   */
  rtb_Divide_re = (((-0.49999999999999978 * rtb_SumofElements_re_p -
                     0.86602540378443871 * rtb_SumofElements_im_l) +
                    rtb_SumofElements_re) + (-0.50000000000000033 * re -
    -0.86602540378443837 * im)) * 0.33333333333333331;
  rtb_Divide_im = (((-0.49999999999999978 * rtb_SumofElements_im_l +
                     0.86602540378443871 * rtb_SumofElements_re_p) +
                    rtb_SumofElements_im) + (-0.50000000000000033 * im +
    -0.86602540378443837 * re)) * 0.33333333333333331;

  /* ComplexToMagnitudeAngle: '<S42>/Complex to Magnitude-Angle' */
  rtb_tArg1_i = rt_atan2d_snf(rtb_Divide_im, rtb_Divide_re);

  /* Delay: '<S42>/Delay' */
  rtb_tArg2_c = localDW->Delay_DSTATE;

  /* S-Function (sdspunwrap2): '<S42>/Unwrap' */
  if (localDW->Unwrap_FirstStep) {
    localDW->Unwrap_Prev = rtb_tArg1_i;
    localDW->Unwrap_FirstStep = false;
  }

  rtb_Unwrap_c = rtb_tArg1_i - localDW->Unwrap_Prev;
  rtb_Fcn2 = rtb_Unwrap_c - floor((rtb_Unwrap_c + 3.1415926535897931) /
    6.2831853071795862) * 6.2831853071795862;
  if ((rtb_Fcn2 == -3.1415926535897931) && (rtb_Unwrap_c > 0.0)) {
    rtb_Fcn2 = 3.1415926535897931;
  }

  rtb_Unwrap_c = rtb_Fcn2 - rtb_Unwrap_c;
  if (fabs(rtb_Unwrap_c) > 3.1415926535897931) {
    localDW->Unwrap_Cumsum += rtb_Unwrap_c;
  }

  rtb_Unwrap_c = rtb_tArg1_i + localDW->Unwrap_Cumsum;
  localDW->Unwrap_Prev = rtb_tArg1_i;

  /* End of S-Function (sdspunwrap2): '<S42>/Unwrap' */

  /* Gain: '<S42>/Gain9' incorporates:
   *  Delay: '<S42>/Delay1'
   *  Sum: '<S42>/Subtract1'
   */
  rtb_tArg1_i = (rtb_Unwrap_c - localDW->Delay1_DSTATE) * 79.57747154594766;

  /* Switch: '<S42>/Switch1' */
  if (rtb_Bias_h >= 4.0) {
    /* Fcn: '<S42>/Fcn2' incorporates:
     *  Constant: '<S42>/i9'
     */
    rtb_Fcn2 = sin((1.625 * rtb_tArg1_i + 50.0) * 3.1415926535897931 / 100.0);

    /* Product: '<S42>/Divide6' incorporates:
     *  Sum: '<S46>/Sum of Elements'
     */
    if (rtb_SumofElements_im == 0.0) {
      rtb_SumofElements_re /= rtb_Fcn2;
      rtb_SumofElements_im = 0.0;
    } else if (rtb_SumofElements_re == 0.0) {
      rtb_SumofElements_re = 0.0;
      rtb_SumofElements_im /= rtb_Fcn2;
    } else {
      rtb_SumofElements_re /= rtb_Fcn2;
      rtb_SumofElements_im /= rtb_Fcn2;
    }

    if (rtb_SumofElements_im_l == 0.0) {
      rtb_SumofElements_re_p /= rtb_Fcn2;
      rtb_SumofElements_im_l = 0.0;
    } else if (rtb_SumofElements_re_p == 0.0) {
      rtb_SumofElements_re_p = 0.0;
      rtb_SumofElements_im_l /= rtb_Fcn2;
    } else {
      rtb_SumofElements_re_p /= rtb_Fcn2;
      rtb_SumofElements_im_l /= rtb_Fcn2;
    }

    if (im == 0.0) {
      re /= rtb_Fcn2;
      im = 0.0;
    } else if (re == 0.0) {
      re = 0.0;
      im /= rtb_Fcn2;
    } else {
      re /= rtb_Fcn2;
      im /= rtb_Fcn2;
    }

    if (rtb_Divide_im == 0.0) {
      rtb_Divide_re /= rtb_Fcn2;
      rtb_Divide_im = 0.0;
    } else if (rtb_Divide_re == 0.0) {
      rtb_Divide_re = 0.0;
      rtb_Divide_im /= rtb_Fcn2;
    } else {
      rtb_Divide_re /= rtb_Fcn2;
      rtb_Divide_im /= rtb_Fcn2;
    }

    /* End of Product: '<S42>/Divide6' */
  }

  /* End of Switch: '<S42>/Switch1' */

  /* ZeroOrderHold: '<S43>/Zero-Order Hold1' incorporates:
   *  Constant: '<S43>/i1'
   *  Delay: '<S43>/Delay'
   */
  *rty_Timestamp = localDW->Delay_DSTATE_p[981U];

  /* RelationalOperator: '<S47>/Compare' incorporates:
   *  Constant: '<S47>/Constant'
   */
  rtb_Compare_fj = (rtb_Bias_h >= 19.0);

  /* Bias: '<S43>/Bias' incorporates:
   *  Constant: '<S47>/Constant'
   *  DataTypeConversion: '<S43>/Data Type Conversion'
   *  Product: '<S43>/Product2'
   *  RelationalOperator: '<S47>/Compare'
   */
  *rty_Freq = (real_T)(rtb_Bias_h >= 19.0) * rtb_tArg1_i + 50.0;

  /* Switch: '<S43>/Switch2' incorporates:
   *  ComplexToMagnitudeAngle: '<S43>/Complex to Magnitude-Angle1'
   *  ComplexToMagnitudeAngle: '<S43>/Complex to Magnitude-Angle2'
   *  ComplexToRealImag: '<S43>/Complex to Real-Imag1'
   *  ComplexToRealImag: '<S43>/Complex to Real-Imag2'
   *  Constant: '<S41>/i1'
   *  Switch: '<S43>/Switch1'
   */
  if (PMU_clk_P_e->mode >= 1.0) {
    rty_PhXabc[0] = rt_hypotd_snf(rtb_SumofElements_re, rtb_SumofElements_im);
    rty_PhXabc[3] = rt_atan2d_snf(rtb_SumofElements_im, rtb_SumofElements_re);
    rty_PhXabc[1] = rt_hypotd_snf(rtb_SumofElements_re_p, rtb_SumofElements_im_l);
    rty_PhXabc[4] = rt_atan2d_snf(rtb_SumofElements_im_l, rtb_SumofElements_re_p);
    rty_PhXabc[2] = rt_hypotd_snf(re, im);
    rty_PhXabc[5] = rt_atan2d_snf(im, re);
    rty_PhX1[0] = rt_hypotd_snf(rtb_Divide_re, rtb_Divide_im);
    rty_PhX1[1] = rt_atan2d_snf(rtb_Divide_im, rtb_Divide_re);
  } else {
    rty_PhXabc[0] = rtb_SumofElements_re;
    rty_PhXabc[3] = rtb_SumofElements_im;
    rty_PhXabc[1] = rtb_SumofElements_re_p;
    rty_PhXabc[4] = rtb_SumofElements_im_l;
    rty_PhXabc[2] = re;
    rty_PhXabc[5] = im;
    rty_PhX1[0] = rtb_Divide_re;
    rty_PhX1[1] = rtb_Divide_im;
  }

  /* End of Switch: '<S43>/Switch2' */

  /* Product: '<S43>/Product' incorporates:
   *  DataTypeConversion: '<S43>/Data Type Conversion'
   */
  for (i = 0; i < 6; i++) {
    rty_PhXabc[i] *= (real_T)rtb_Compare_fj;
  }

  /* End of Product: '<S43>/Product' */

  /* Product: '<S43>/Product1' incorporates:
   *  DataTypeConversion: '<S43>/Data Type Conversion'
   */
  rty_PhX1[0] *= (real_T)rtb_Compare_fj;
  rty_PhX1[1] *= (real_T)rtb_Compare_fj;

  /* Product: '<S43>/Product3' incorporates:
   *  Constant: '<S42>/T'
   *  DataTypeConversion: '<S43>/Data Type Conversion'
   *  Delay: '<S42>/Delay'
   *  Delay: '<S42>/Delay1'
   *  Gain: '<S42>/Gain2'
   *  Product: '<S42>/Divide5'
   *  Sum: '<S42>/Subtract3'
   */
  *rty_ROCOF = ((localDW->Delay1_DSTATE + rtb_Unwrap_c) - 2.0 *
                localDW->Delay_DSTATE) / 6.2831853071795858E-6 * (real_T)
    rtb_Compare_fj;

  /* Update for Delay: '<S42>/Delay' */
  localDW->Delay_DSTATE = rtb_Unwrap_c;

  /* Update for Delay: '<S42>/Delay1' */
  localDW->Delay1_DSTATE = rtb_tArg2_c;

  /* Update for Delay: '<S43>/Delay' */
  for (i = 0; i < 999; i++) {
    localDW->Delay_DSTATE_p[i] = localDW->Delay_DSTATE_p[i + 1];
  }

  localDW->Delay_DSTATE_p[999] = rtu_Clock;

  /* End of Update for Delay: '<S43>/Delay' */
}

/*
 * Termination for action system:
 *    '<Root>/PMU_50Hz_P_25'
 *    '<Root>/PMU_50Hz_P_50'
 *    '<Root>/PMU_50Hz_P_100'
 */
void PMU_clk_PMU_50Hz_P_25_Term(void)
{
}

/*
 * System initialize for action system:
 *    '<Root>/PMU_60Hz_P_30'
 *    '<Root>/PMU_60Hz_P_60'
 *    '<Root>/PMU_60Hz_P_120'
 */
void PMU_clk_PMU_60Hz_P_30_Init(DW_PMU_60Hz_P_30_PMU_clk_T *localDW)
{
  /* InitializeConditions for Buffer: '<S84>/Buffer1' */
  localDW->Buffer1_CircBufIdx = 0;

  /* InitializeConditions for Buffer: '<S84>/Buffer2' */
  localDW->Buffer2_CircBufIdx = 0;

  /* InitializeConditions for Buffer: '<S84>/Buffer1' */
  memset(&localDW->Buffer1_CircBuff[0], 0, sizeof(creal_T) << 5U);

  /* InitializeConditions for Buffer: '<S84>/Buffer2' incorporates:
   *  Buffer: '<S84>/Buffer1'
   */
  memset(&localDW->Buffer2_CircBuff[0], 0, sizeof(creal_T) << 5U);

  /* InitializeConditions for Buffer: '<S84>/Buffer3' incorporates:
   *  Buffer: '<S84>/Buffer1'
   */
  memset(&localDW->Buffer3_CircBuff[0], 0, sizeof(creal_T) << 5U);
  localDW->Buffer3_CircBufIdx = 0;

  /* InitializeConditions for Delay: '<S84>/Delay' */
  localDW->Delay_DSTATE = 0.0;

  /* InitializeConditions for Delay: '<S84>/Delay1' */
  localDW->Delay1_DSTATE = 0.0;

  /* InitializeConditions for S-Function (sdspunwrap2): '<S84>/Unwrap' */
  localDW->Unwrap_FirstStep = true;
  localDW->Unwrap_Cumsum = 0.0;

  /* InitializeConditions for Delay: '<S85>/Delay' */
  memset(&localDW->Delay_DSTATE_f[0], 0, 1000U * sizeof(real_T));
}

/*
 * Output and update for action system:
 *    '<Root>/PMU_60Hz_P_30'
 *    '<Root>/PMU_60Hz_P_60'
 *    '<Root>/PMU_60Hz_P_120'
 */
void PMU_clk_PMU_60Hz_P_30(const real_T rtu_Xabc[3], real_T rtu_Clock, real_T
  rty_PhXabc[6], real_T rty_PhX1[2], real_T *rty_Freq, real_T *rty_ROCOF, real_T
  *rty_Timestamp, B_PMU_60Hz_P_30_PMU_clk_T *localB, const
  ConstB_PMU_60Hz_P_30_PMU_clk_T *localC, DW_PMU_60Hz_P_30_PMU_clk_T *localDW,
  P_PMU_clk_T *PMU_clk_P_e)
{
  int32_T i;
  int32_T yIdx;
  real_T rtb_tArg2_a;
  real_T rtb_Unwrap_n0;
  real_T rtb_Bias_gi;
  boolean_T rtb_Compare_n;
  real_T rtb_tArg1_l;
  real_T rtb_Fcn2;
  creal_T rtb_Buffer3_b[33];
  creal_T rtb_Product_m[33];
  real_T rtb_Divide_re;
  real_T rtb_Divide_im;
  real_T re;
  real_T im;
  real_T rtb_SumofElements_re;
  real_T rtb_SumofElements_im;
  real_T rtb_SumofElements_re_p;
  real_T rtb_SumofElements_im_a;

  /* Bias: '<S83>/Bias' incorporates:
   *  Constant: '<S83>/i2'
   *  Product: '<S83>/Divide2'
   */
  rtb_Bias_gi = rtu_Clock * 1000.0 + 1.0;

  /* Product: '<S84>/Divide' */
  rtb_Divide_im = localC->Fcn1 * localC->RealImagtoComplex.im * rtu_Clock;

  /* Math: '<S84>/Math Function' incorporates:
   *  Product: '<S84>/Divide'
   *
   * About '<S84>/Math Function':
   *  Operator: exp
   */
  rtb_tArg2_a = exp(localC->Fcn1 * localC->RealImagtoComplex.re * rtu_Clock);
  if (rtb_Divide_im == 0.0) {
    rtb_Divide_re = rtb_tArg2_a;
    rtb_Divide_im = 0.0;
  } else {
    rtb_Divide_re = rtb_tArg2_a * cos(rtb_Divide_im);
    rtb_Divide_im = rtb_tArg2_a * sin(rtb_Divide_im);
  }

  /* End of Math: '<S84>/Math Function' */

  /* Product: '<S84>/Divide1' incorporates:
   *  Gain: '<S84>/Gain1'
   */
  localB->Divide1[0].re = 1.4142135623730951 * rtu_Xabc[0] * rtb_Divide_re;
  localB->Divide1[0].im = 1.4142135623730951 * rtu_Xabc[0] * rtb_Divide_im;
  localB->Divide1[1].re = 1.4142135623730951 * rtu_Xabc[1] * rtb_Divide_re;
  localB->Divide1[1].im = 1.4142135623730951 * rtu_Xabc[1] * rtb_Divide_im;
  localB->Divide1[2].re = 1.4142135623730951 * rtu_Xabc[2] * rtb_Divide_re;
  localB->Divide1[2].im = 1.4142135623730951 * rtu_Xabc[2] * rtb_Divide_im;

  /* Buffer: '<S84>/Buffer1' */
  for (i = 0; i < 32 - localDW->Buffer1_CircBufIdx; i++) {
    rtb_Product_m[i] = localDW->Buffer1_CircBuff[localDW->Buffer1_CircBufIdx + i];
  }

  yIdx = 32 - localDW->Buffer1_CircBufIdx;
  for (i = 0; i < localDW->Buffer1_CircBufIdx; i++) {
    rtb_Product_m[yIdx + i] = localDW->Buffer1_CircBuff[i];
  }

  yIdx += localDW->Buffer1_CircBufIdx;
  rtb_Product_m[yIdx] = localB->Divide1[0];
  localDW->Buffer1_CircBuff[localDW->Buffer1_CircBufIdx] = localB->Divide1[0];
  localDW->Buffer1_CircBufIdx++;
  if (localDW->Buffer1_CircBufIdx >= 32) {
    localDW->Buffer1_CircBufIdx -= 32;
  }

  /* End of Buffer: '<S84>/Buffer1' */

  /* Sum: '<S86>/Sum of Elements' */
  re = -0.0;
  im = 0.0;
  for (i = 0; i < 33; i++) {
    /* Product: '<S86>/Product' incorporates:
     *  Constant: '<S86>/i2'
     */
    rtb_Buffer3_b[i].re = PMU_clk_ConstP.pooled21[i] * rtb_Product_m[i].re;
    rtb_Buffer3_b[i].im = PMU_clk_ConstP.pooled21[i] * rtb_Product_m[i].im;

    /* Sum: '<S86>/Sum of Elements' incorporates:
     *  Product: '<S86>/Product'
     */
    re += rtb_Buffer3_b[i].re;
    im += rtb_Buffer3_b[i].im;
  }

  /* Sum: '<S86>/Sum of Elements' */
  rtb_SumofElements_re = re;
  rtb_SumofElements_im = im;

  /* Buffer: '<S84>/Buffer2' */
  for (i = 0; i < 32 - localDW->Buffer2_CircBufIdx; i++) {
    rtb_Buffer3_b[i] = localDW->Buffer2_CircBuff[localDW->Buffer2_CircBufIdx + i];
  }

  yIdx = 32 - localDW->Buffer2_CircBufIdx;
  for (i = 0; i < localDW->Buffer2_CircBufIdx; i++) {
    rtb_Buffer3_b[yIdx + i] = localDW->Buffer2_CircBuff[i];
  }

  yIdx += localDW->Buffer2_CircBufIdx;
  rtb_Buffer3_b[yIdx] = localB->Divide1[1];
  localDW->Buffer2_CircBuff[localDW->Buffer2_CircBufIdx] = localB->Divide1[1];
  localDW->Buffer2_CircBufIdx++;
  if (localDW->Buffer2_CircBufIdx >= 32) {
    localDW->Buffer2_CircBufIdx -= 32;
  }

  /* End of Buffer: '<S84>/Buffer2' */

  /* Sum: '<S87>/Sum of Elements' */
  re = -0.0;
  im = 0.0;
  for (i = 0; i < 33; i++) {
    /* Product: '<S87>/Product' incorporates:
     *  Constant: '<S87>/i2'
     */
    rtb_Product_m[i].re = PMU_clk_ConstP.pooled21[i] * rtb_Buffer3_b[i].re;
    rtb_Product_m[i].im = PMU_clk_ConstP.pooled21[i] * rtb_Buffer3_b[i].im;

    /* Sum: '<S87>/Sum of Elements' incorporates:
     *  Product: '<S87>/Product'
     */
    re += rtb_Product_m[i].re;
    im += rtb_Product_m[i].im;
  }

  /* Sum: '<S87>/Sum of Elements' */
  rtb_SumofElements_re_p = re;
  rtb_SumofElements_im_a = im;

  /* Buffer: '<S84>/Buffer3' */
  for (i = 0; i < 32 - localDW->Buffer3_CircBufIdx; i++) {
    rtb_Buffer3_b[i] = localDW->Buffer3_CircBuff[localDW->Buffer3_CircBufIdx + i];
  }

  yIdx = 32 - localDW->Buffer3_CircBufIdx;
  for (i = 0; i < localDW->Buffer3_CircBufIdx; i++) {
    rtb_Buffer3_b[yIdx + i] = localDW->Buffer3_CircBuff[i];
  }

  yIdx += localDW->Buffer3_CircBufIdx;
  rtb_Buffer3_b[yIdx] = localB->Divide1[2];
  localDW->Buffer3_CircBuff[localDW->Buffer3_CircBufIdx] = localB->Divide1[2];
  localDW->Buffer3_CircBufIdx++;
  if (localDW->Buffer3_CircBufIdx >= 32) {
    localDW->Buffer3_CircBufIdx -= 32;
  }

  /* End of Buffer: '<S84>/Buffer3' */

  /* Sum: '<S88>/Sum of Elements' */
  re = -0.0;
  im = 0.0;
  for (i = 0; i < 33; i++) {
    /* Product: '<S88>/Product' incorporates:
     *  Constant: '<S88>/i2'
     */
    rtb_Product_m[i].re = PMU_clk_ConstP.pooled21[i] * rtb_Buffer3_b[i].re;
    rtb_Product_m[i].im = PMU_clk_ConstP.pooled21[i] * rtb_Buffer3_b[i].im;

    /* Sum: '<S88>/Sum of Elements' incorporates:
     *  Product: '<S88>/Product'
     */
    re += rtb_Product_m[i].re;
    im += rtb_Product_m[i].im;
  }

  /* Gain: '<S84>/Gain5' incorporates:
   *  Gain: '<S84>/Sequence Gain2'
   *  Gain: '<S84>/Sequence Gain3'
   *  Sum: '<S84>/Add'
   *  Sum: '<S88>/Sum of Elements'
   */
  rtb_Divide_re = (((-0.49999999999999978 * rtb_SumofElements_re_p -
                     0.86602540378443871 * rtb_SumofElements_im_a) +
                    rtb_SumofElements_re) + (-0.50000000000000033 * re -
    -0.86602540378443837 * im)) * 0.33333333333333331;
  rtb_Divide_im = (((-0.49999999999999978 * rtb_SumofElements_im_a +
                     0.86602540378443871 * rtb_SumofElements_re_p) +
                    rtb_SumofElements_im) + (-0.50000000000000033 * im +
    -0.86602540378443837 * re)) * 0.33333333333333331;

  /* ComplexToMagnitudeAngle: '<S84>/Complex to Magnitude-Angle' */
  rtb_tArg1_l = rt_atan2d_snf(rtb_Divide_im, rtb_Divide_re);

  /* Delay: '<S84>/Delay' */
  rtb_tArg2_a = localDW->Delay_DSTATE;

  /* S-Function (sdspunwrap2): '<S84>/Unwrap' */
  if (localDW->Unwrap_FirstStep) {
    localDW->Unwrap_Prev = rtb_tArg1_l;
    localDW->Unwrap_FirstStep = false;
  }

  rtb_Unwrap_n0 = rtb_tArg1_l - localDW->Unwrap_Prev;
  rtb_Fcn2 = rtb_Unwrap_n0 - floor((rtb_Unwrap_n0 + 3.1415926535897931) /
    6.2831853071795862) * 6.2831853071795862;
  if ((rtb_Fcn2 == -3.1415926535897931) && (rtb_Unwrap_n0 > 0.0)) {
    rtb_Fcn2 = 3.1415926535897931;
  }

  rtb_Unwrap_n0 = rtb_Fcn2 - rtb_Unwrap_n0;
  if (fabs(rtb_Unwrap_n0) > 3.1415926535897931) {
    localDW->Unwrap_Cumsum += rtb_Unwrap_n0;
  }

  rtb_Unwrap_n0 = rtb_tArg1_l + localDW->Unwrap_Cumsum;
  localDW->Unwrap_Prev = rtb_tArg1_l;

  /* End of S-Function (sdspunwrap2): '<S84>/Unwrap' */

  /* Gain: '<S84>/Gain9' incorporates:
   *  Delay: '<S84>/Delay1'
   *  Sum: '<S84>/Subtract1'
   */
  rtb_tArg1_l = (rtb_Unwrap_n0 - localDW->Delay1_DSTATE) * 79.57747154594766;

  /* Switch: '<S84>/Switch1' */
  if (rtb_Bias_gi >= 4.0) {
    /* Fcn: '<S84>/Fcn2' incorporates:
     *  Constant: '<S84>/i9'
     */
    rtb_Fcn2 = sin((1.625 * rtb_tArg1_l + 60.0) * 3.1415926535897931 / 120.0);

    /* Product: '<S84>/Divide6' incorporates:
     *  Sum: '<S88>/Sum of Elements'
     */
    if (rtb_SumofElements_im == 0.0) {
      rtb_SumofElements_re /= rtb_Fcn2;
      rtb_SumofElements_im = 0.0;
    } else if (rtb_SumofElements_re == 0.0) {
      rtb_SumofElements_re = 0.0;
      rtb_SumofElements_im /= rtb_Fcn2;
    } else {
      rtb_SumofElements_re /= rtb_Fcn2;
      rtb_SumofElements_im /= rtb_Fcn2;
    }

    if (rtb_SumofElements_im_a == 0.0) {
      rtb_SumofElements_re_p /= rtb_Fcn2;
      rtb_SumofElements_im_a = 0.0;
    } else if (rtb_SumofElements_re_p == 0.0) {
      rtb_SumofElements_re_p = 0.0;
      rtb_SumofElements_im_a /= rtb_Fcn2;
    } else {
      rtb_SumofElements_re_p /= rtb_Fcn2;
      rtb_SumofElements_im_a /= rtb_Fcn2;
    }

    if (im == 0.0) {
      re /= rtb_Fcn2;
      im = 0.0;
    } else if (re == 0.0) {
      re = 0.0;
      im /= rtb_Fcn2;
    } else {
      re /= rtb_Fcn2;
      im /= rtb_Fcn2;
    }

    if (rtb_Divide_im == 0.0) {
      rtb_Divide_re /= rtb_Fcn2;
      rtb_Divide_im = 0.0;
    } else if (rtb_Divide_re == 0.0) {
      rtb_Divide_re = 0.0;
      rtb_Divide_im /= rtb_Fcn2;
    } else {
      rtb_Divide_re /= rtb_Fcn2;
      rtb_Divide_im /= rtb_Fcn2;
    }

    /* End of Product: '<S84>/Divide6' */
  }

  /* End of Switch: '<S84>/Switch1' */

  /* ZeroOrderHold: '<S85>/Zero-Order Hold1' incorporates:
   *  Constant: '<S85>/i1'
   *  Delay: '<S85>/Delay'
   */
  *rty_Timestamp = localDW->Delay_DSTATE_f[984U];

  /* RelationalOperator: '<S89>/Compare' incorporates:
   *  Constant: '<S89>/Constant'
   */
  rtb_Compare_n = (rtb_Bias_gi >= 16.0);

  /* Bias: '<S85>/Bias' incorporates:
   *  Constant: '<S89>/Constant'
   *  DataTypeConversion: '<S85>/Data Type Conversion'
   *  Product: '<S85>/Product2'
   *  RelationalOperator: '<S89>/Compare'
   */
  *rty_Freq = (real_T)(rtb_Bias_gi >= 16.0) * rtb_tArg1_l + 60.0;

  /* Switch: '<S85>/Switch2' incorporates:
   *  ComplexToMagnitudeAngle: '<S85>/Complex to Magnitude-Angle1'
   *  ComplexToMagnitudeAngle: '<S85>/Complex to Magnitude-Angle2'
   *  ComplexToRealImag: '<S85>/Complex to Real-Imag1'
   *  ComplexToRealImag: '<S85>/Complex to Real-Imag2'
   *  Constant: '<S83>/i1'
   *  Switch: '<S85>/Switch1'
   */
  if (PMU_clk_P_e->mode >= 1.0) {
    rty_PhXabc[0] = rt_hypotd_snf(rtb_SumofElements_re, rtb_SumofElements_im);
    rty_PhXabc[3] = rt_atan2d_snf(rtb_SumofElements_im, rtb_SumofElements_re);
    rty_PhXabc[1] = rt_hypotd_snf(rtb_SumofElements_re_p, rtb_SumofElements_im_a);
    rty_PhXabc[4] = rt_atan2d_snf(rtb_SumofElements_im_a, rtb_SumofElements_re_p);
    rty_PhXabc[2] = rt_hypotd_snf(re, im);
    rty_PhXabc[5] = rt_atan2d_snf(im, re);
    rty_PhX1[0] = rt_hypotd_snf(rtb_Divide_re, rtb_Divide_im);
    rty_PhX1[1] = rt_atan2d_snf(rtb_Divide_im, rtb_Divide_re);
  } else {
    rty_PhXabc[0] = rtb_SumofElements_re;
    rty_PhXabc[3] = rtb_SumofElements_im;
    rty_PhXabc[1] = rtb_SumofElements_re_p;
    rty_PhXabc[4] = rtb_SumofElements_im_a;
    rty_PhXabc[2] = re;
    rty_PhXabc[5] = im;
    rty_PhX1[0] = rtb_Divide_re;
    rty_PhX1[1] = rtb_Divide_im;
  }

  /* End of Switch: '<S85>/Switch2' */

  /* Product: '<S85>/Product' incorporates:
   *  DataTypeConversion: '<S85>/Data Type Conversion'
   */
  for (i = 0; i < 6; i++) {
    rty_PhXabc[i] *= (real_T)rtb_Compare_n;
  }

  /* End of Product: '<S85>/Product' */

  /* Product: '<S85>/Product1' incorporates:
   *  DataTypeConversion: '<S85>/Data Type Conversion'
   */
  rty_PhX1[0] *= (real_T)rtb_Compare_n;
  rty_PhX1[1] *= (real_T)rtb_Compare_n;

  /* Product: '<S85>/Product3' incorporates:
   *  Constant: '<S84>/T'
   *  DataTypeConversion: '<S85>/Data Type Conversion'
   *  Delay: '<S84>/Delay'
   *  Delay: '<S84>/Delay1'
   *  Gain: '<S84>/Gain2'
   *  Product: '<S84>/Divide5'
   *  Sum: '<S84>/Subtract3'
   */
  *rty_ROCOF = ((localDW->Delay1_DSTATE + rtb_Unwrap_n0) - 2.0 *
                localDW->Delay_DSTATE) / 6.2831853071795858E-6 * (real_T)
    rtb_Compare_n;

  /* Update for Delay: '<S84>/Delay' */
  localDW->Delay_DSTATE = rtb_Unwrap_n0;

  /* Update for Delay: '<S84>/Delay1' */
  localDW->Delay1_DSTATE = rtb_tArg2_a;

  /* Update for Delay: '<S85>/Delay' */
  for (i = 0; i < 999; i++) {
    localDW->Delay_DSTATE_f[i] = localDW->Delay_DSTATE_f[i + 1];
  }

  localDW->Delay_DSTATE_f[999] = rtu_Clock;

  /* End of Update for Delay: '<S85>/Delay' */
}

/*
 * Termination for action system:
 *    '<Root>/PMU_60Hz_P_30'
 *    '<Root>/PMU_60Hz_P_60'
 *    '<Root>/PMU_60Hz_P_120'
 */
void PMU_clk_PMU_60Hz_P_30_Term(void)
{
}

/* Model step function */
void PMU_clk_step(RT_MODEL_PMU_clk_T *const PMU_clk_M)
{
  P_PMU_clk_T *PMU_clk_P_e = ((P_PMU_clk_T *) PMU_clk_M->defaultParam);
  B_PMU_clk_T *PMU_clk_B = ((B_PMU_clk_T *) PMU_clk_M->blockIO);
  DW_PMU_clk_T *PMU_clk_DW = ((DW_PMU_clk_T *) PMU_clk_M->dwork);
  ExtU_PMU_clk_T *PMU_clk_U = (ExtU_PMU_clk_T *) PMU_clk_M->inputs;
  ExtY_PMU_clk_T *PMU_clk_Y = (ExtY_PMU_clk_T *) PMU_clk_M->outputs;
  int32_T i;
  int32_T yIdx;
  real_T dpShift;
  real_T rtb_Switch;
  real_T rtb_tArg2_c;
  real_T rtb_Unwrap_kb;
  boolean_T rtb_Compare_j0;
  real_T rtb_tArg1_o;
  creal_T rtb_Buffer3_d[149];
  creal_T rtb_Product_f[149];
  creal_T rtb_Buffer3_oj[71];
  creal_T rtb_Product_d[71];
  creal_T rtb_Buffer3_c[171];
  creal_T rtb_Product_ns[171];
  creal_T rtb_Buffer3[73];
  creal_T rtb_Product[73];
  real_T rtb_Divide_re;
  real_T rtb_Divide_im;
  real_T re;
  real_T im;
  real_T rtb_SumofElements_re;
  real_T rtb_SumofElements_im;
  real_T rtb_SumofElements_re_g;
  real_T rtb_SumofElements_im_d;
  if (PMU_clk_M->Timing.TaskCounters.TID[1] == 0) {
    /* RateTransition: '<Root>/Rate Transition' incorporates:
     *  Inport: '<Root>/Xabc'
     */
    PMU_clk_B->RateTransition[0] = PMU_clk_U->Xabc[0];
    PMU_clk_B->RateTransition[1] = PMU_clk_U->Xabc[1];
    PMU_clk_B->RateTransition[2] = PMU_clk_U->Xabc[2];

    /* Switch: '<Root>/Switch' incorporates:
     *  Constant: '<Root>/Constant'
     *  DigitalClock: '<Root>/Digital Clock'
     *  Inport: '<Root>/Clock'
     */
    if (PMU_clk_P_e->clk_choice >= 1.0) {
      rtb_Switch = PMU_clk_U->Clock;
    } else {
      rtb_Switch = (((PMU_clk_M->Timing.clockTick1+PMU_clk_M->Timing.clockTickH1*
                      4294967296.0)) * 0.001);
    }

    /* End of Switch: '<Root>/Switch' */

    /* SwitchCase: '<Root>/Switch Case' incorporates:
     *  Constant: '<Root>/Class'
     *  Constant: '<Root>/Frequency'
     *  Constant: '<Root>/Reporting_rate'
     *  Lookup_n-D: '<Root>/n-D Lookup Table'
     */
    if (PMU_clk_ConstP.nDLookupTable_tableData[((plook_u32d_binckan
          (PMU_clk_P_e->z, PMU_clk_ConstP.nDLookupTable_bp02Data, 2U) << 1) +
         plook_u32d_binckan(PMU_clk_P_e->bMclass,
                            PMU_clk_ConstP.nDLookupTable_bp01Data, 1U)) +
        plook_u32d_binckan(PMU_clk_P_e->rF0,
                           PMU_clk_ConstP.nDLookupTable_bp03Data, 1U) * 6U] <
        0.0) {
      re = ceil(PMU_clk_ConstP.nDLookupTable_tableData[((plook_u32d_binckan
                  (PMU_clk_P_e->z, PMU_clk_ConstP.nDLookupTable_bp02Data, 2U) <<
                  1) + plook_u32d_binckan(PMU_clk_P_e->bMclass,
                  PMU_clk_ConstP.nDLookupTable_bp01Data, 1U)) +
                plook_u32d_binckan(PMU_clk_P_e->rF0,
                 PMU_clk_ConstP.nDLookupTable_bp03Data, 1U) * 6U]);
    } else {
      re = floor(PMU_clk_ConstP.nDLookupTable_tableData[((plook_u32d_binckan
        (PMU_clk_P_e->z, PMU_clk_ConstP.nDLookupTable_bp02Data, 2U) << 1) +
                  plook_u32d_binckan(PMU_clk_P_e->bMclass,
        PMU_clk_ConstP.nDLookupTable_bp01Data, 1U)) + plook_u32d_binckan
                 (PMU_clk_P_e->rF0, PMU_clk_ConstP.nDLookupTable_bp03Data, 1U) *
                 6U]);
    }

    if (rtIsNaN(re) || rtIsInf(re)) {
      re = 0.0;
    } else {
      re = fmod(re, 4.294967296E+9);
    }

    switch (re < 0.0 ? -(int32_T)(uint32_T)-re : (int32_T)(uint32_T)re) {
     case 1:
      /* Outputs for IfAction SubSystem: '<Root>/PMU_50Hz_P_25' incorporates:
       *  ActionPort: '<S5>/Action Port'
       */
      PMU_clk_PMU_50Hz_P_25(PMU_clk_B->RateTransition, rtb_Switch,
                            PMU_clk_B->Merge4, PMU_clk_B->Merge1,
                            &PMU_clk_B->Merge2, &PMU_clk_B->Merge3,
                            &PMU_clk_B->Merge5, &PMU_clk_B->PMU_50Hz_P_25,
                            &PMU_clk_ConstB.PMU_50Hz_P_25,
                            &PMU_clk_DW->PMU_50Hz_P_25, PMU_clk_P_e);

      /* End of Outputs for SubSystem: '<Root>/PMU_50Hz_P_25' */
      break;

     case 2:
      /* Outputs for IfAction SubSystem: '<Root>/PMU_50Hz_P_50' incorporates:
       *  ActionPort: '<S6>/Action Port'
       */
      PMU_clk_PMU_50Hz_P_25(PMU_clk_B->RateTransition, rtb_Switch,
                            PMU_clk_B->Merge4, PMU_clk_B->Merge1,
                            &PMU_clk_B->Merge2, &PMU_clk_B->Merge3,
                            &PMU_clk_B->Merge5, &PMU_clk_B->PMU_50Hz_P_50,
                            &PMU_clk_ConstB.PMU_50Hz_P_50,
                            &PMU_clk_DW->PMU_50Hz_P_50, PMU_clk_P_e);

      /* End of Outputs for SubSystem: '<Root>/PMU_50Hz_P_50' */
      break;

     case 3:
      /* Outputs for IfAction SubSystem: '<Root>/PMU_50Hz_P_100' incorporates:
       *  ActionPort: '<S4>/Action Port'
       */
      PMU_clk_PMU_50Hz_P_25(PMU_clk_B->RateTransition, rtb_Switch,
                            PMU_clk_B->Merge4, PMU_clk_B->Merge1,
                            &PMU_clk_B->Merge2, &PMU_clk_B->Merge3,
                            &PMU_clk_B->Merge5, &PMU_clk_B->PMU_50Hz_P_100,
                            &PMU_clk_ConstB.PMU_50Hz_P_100,
                            &PMU_clk_DW->PMU_50Hz_P_100, PMU_clk_P_e);

      /* End of Outputs for SubSystem: '<Root>/PMU_50Hz_P_100' */
      break;

     case 4:
      /* Outputs for IfAction SubSystem: '<Root>/PMU_50Hz_M_25' incorporates:
       *  ActionPort: '<S2>/Action Port'
       */
      /* Product: '<S21>/Divide' */
      rtb_Divide_im = PMU_clk_ConstB.Fcn1_bp *
        PMU_clk_ConstB.RealImagtoComplex_h.im * rtb_Switch;

      /* Math: '<S21>/Math Function' incorporates:
       *  Product: '<S21>/Divide'
       *
       * About '<S21>/Math Function':
       *  Operator: exp
       */
      re = exp(PMU_clk_ConstB.Fcn1_bp * PMU_clk_ConstB.RealImagtoComplex_h.re *
               rtb_Switch);
      if (rtb_Divide_im == 0.0) {
        rtb_Divide_re = re;
        rtb_Divide_im = 0.0;
      } else {
        rtb_Divide_re = re * cos(rtb_Divide_im);
        rtb_Divide_im = re * sin(rtb_Divide_im);
      }

      /* End of Math: '<S21>/Math Function' */

      /* Product: '<S21>/Divide1' incorporates:
       *  Gain: '<S21>/Gain1'
       */
      PMU_clk_B->Divide1_f[0].re = 1.4142135623730951 *
        PMU_clk_B->RateTransition[0] * rtb_Divide_re;
      PMU_clk_B->Divide1_f[0].im = 1.4142135623730951 *
        PMU_clk_B->RateTransition[0] * rtb_Divide_im;
      PMU_clk_B->Divide1_f[1].re = 1.4142135623730951 *
        PMU_clk_B->RateTransition[1] * rtb_Divide_re;
      PMU_clk_B->Divide1_f[1].im = 1.4142135623730951 *
        PMU_clk_B->RateTransition[1] * rtb_Divide_im;
      PMU_clk_B->Divide1_f[2].re = 1.4142135623730951 *
        PMU_clk_B->RateTransition[2] * rtb_Divide_re;
      PMU_clk_B->Divide1_f[2].im = 1.4142135623730951 *
        PMU_clk_B->RateTransition[2] * rtb_Divide_im;

      /* Buffer: '<S21>/Buffer1' */
      for (i = 0; i < 352 - PMU_clk_DW->Buffer1_CircBufIdx_c5; i++) {
        PMU_clk_B->Product_e1[i] = PMU_clk_DW->Buffer1_CircBuff_j5
          [PMU_clk_DW->Buffer1_CircBufIdx_c5 + i];
      }

      yIdx = 352 - PMU_clk_DW->Buffer1_CircBufIdx_c5;
      for (i = 0; i < PMU_clk_DW->Buffer1_CircBufIdx_c5; i++) {
        PMU_clk_B->Product_e1[yIdx + i] = PMU_clk_DW->Buffer1_CircBuff_j5[i];
      }

      yIdx += PMU_clk_DW->Buffer1_CircBufIdx_c5;
      PMU_clk_B->Product_e1[yIdx] = PMU_clk_B->Divide1_f[0];
      PMU_clk_DW->Buffer1_CircBuff_j5[PMU_clk_DW->Buffer1_CircBufIdx_c5] =
        PMU_clk_B->Divide1_f[0];
      PMU_clk_DW->Buffer1_CircBufIdx_c5++;
      if (PMU_clk_DW->Buffer1_CircBufIdx_c5 >= 352) {
        PMU_clk_DW->Buffer1_CircBufIdx_c5 -= 352;
      }

      /* End of Buffer: '<S21>/Buffer1' */

      /* Sum: '<S23>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 353; i++) {
        /* Product: '<S23>/Product' incorporates:
         *  Constant: '<S23>/i2'
         */
        PMU_clk_B->Buffer3_h[i].re = PMU_clk_ConstP.pooled4[i] *
          PMU_clk_B->Product_e1[i].re;
        PMU_clk_B->Buffer3_h[i].im = PMU_clk_ConstP.pooled4[i] *
          PMU_clk_B->Product_e1[i].im;

        /* Sum: '<S23>/Sum of Elements' incorporates:
         *  Product: '<S23>/Product'
         */
        re += PMU_clk_B->Buffer3_h[i].re;
        im += PMU_clk_B->Buffer3_h[i].im;
      }

      /* Sum: '<S23>/Sum of Elements' */
      rtb_SumofElements_re = re;
      rtb_SumofElements_im = im;

      /* Buffer: '<S21>/Buffer2' */
      for (i = 0; i < 352 - PMU_clk_DW->Buffer2_CircBufIdx_o; i++) {
        PMU_clk_B->Buffer3_h[i] = PMU_clk_DW->Buffer2_CircBuff_k
          [PMU_clk_DW->Buffer2_CircBufIdx_o + i];
      }

      yIdx = 352 - PMU_clk_DW->Buffer2_CircBufIdx_o;
      for (i = 0; i < PMU_clk_DW->Buffer2_CircBufIdx_o; i++) {
        PMU_clk_B->Buffer3_h[yIdx + i] = PMU_clk_DW->Buffer2_CircBuff_k[i];
      }

      yIdx += PMU_clk_DW->Buffer2_CircBufIdx_o;
      PMU_clk_B->Buffer3_h[yIdx] = PMU_clk_B->Divide1_f[1];
      PMU_clk_DW->Buffer2_CircBuff_k[PMU_clk_DW->Buffer2_CircBufIdx_o] =
        PMU_clk_B->Divide1_f[1];
      PMU_clk_DW->Buffer2_CircBufIdx_o++;
      if (PMU_clk_DW->Buffer2_CircBufIdx_o >= 352) {
        PMU_clk_DW->Buffer2_CircBufIdx_o -= 352;
      }

      /* End of Buffer: '<S21>/Buffer2' */

      /* Sum: '<S24>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 353; i++) {
        /* Product: '<S24>/Product' incorporates:
         *  Constant: '<S24>/i2'
         */
        PMU_clk_B->Product_e1[i].re = PMU_clk_ConstP.pooled4[i] *
          PMU_clk_B->Buffer3_h[i].re;
        PMU_clk_B->Product_e1[i].im = PMU_clk_ConstP.pooled4[i] *
          PMU_clk_B->Buffer3_h[i].im;

        /* Sum: '<S24>/Sum of Elements' incorporates:
         *  Product: '<S24>/Product'
         */
        re += PMU_clk_B->Product_e1[i].re;
        im += PMU_clk_B->Product_e1[i].im;
      }

      /* Sum: '<S24>/Sum of Elements' */
      rtb_SumofElements_re_g = re;
      rtb_SumofElements_im_d = im;

      /* Buffer: '<S21>/Buffer3' */
      for (i = 0; i < 352 - PMU_clk_DW->Buffer3_CircBufIdx_g; i++) {
        PMU_clk_B->Buffer3_h[i] = PMU_clk_DW->Buffer3_CircBuff_h
          [PMU_clk_DW->Buffer3_CircBufIdx_g + i];
      }

      yIdx = 352 - PMU_clk_DW->Buffer3_CircBufIdx_g;
      for (i = 0; i < PMU_clk_DW->Buffer3_CircBufIdx_g; i++) {
        PMU_clk_B->Buffer3_h[yIdx + i] = PMU_clk_DW->Buffer3_CircBuff_h[i];
      }

      yIdx += PMU_clk_DW->Buffer3_CircBufIdx_g;
      PMU_clk_B->Buffer3_h[yIdx] = PMU_clk_B->Divide1_f[2];
      PMU_clk_DW->Buffer3_CircBuff_h[PMU_clk_DW->Buffer3_CircBufIdx_g] =
        PMU_clk_B->Divide1_f[2];
      PMU_clk_DW->Buffer3_CircBufIdx_g++;
      if (PMU_clk_DW->Buffer3_CircBufIdx_g >= 352) {
        PMU_clk_DW->Buffer3_CircBufIdx_g -= 352;
      }

      /* End of Buffer: '<S21>/Buffer3' */

      /* Sum: '<S25>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 353; i++) {
        /* Product: '<S25>/Product' incorporates:
         *  Constant: '<S25>/i2'
         */
        PMU_clk_B->Product_e1[i].re = PMU_clk_ConstP.pooled4[i] *
          PMU_clk_B->Buffer3_h[i].re;
        PMU_clk_B->Product_e1[i].im = PMU_clk_ConstP.pooled4[i] *
          PMU_clk_B->Buffer3_h[i].im;

        /* Sum: '<S25>/Sum of Elements' incorporates:
         *  Product: '<S25>/Product'
         */
        re += PMU_clk_B->Product_e1[i].re;
        im += PMU_clk_B->Product_e1[i].im;
      }

      /* Gain: '<S21>/Gain5' incorporates:
       *  Gain: '<S21>/Sequence Gain2'
       *  Gain: '<S21>/Sequence Gain3'
       *  Sum: '<S21>/Add'
       *  Sum: '<S25>/Sum of Elements'
       */
      rtb_Divide_re = (((-0.49999999999999978 * rtb_SumofElements_re_g -
                         0.86602540378443871 * rtb_SumofElements_im_d) +
                        rtb_SumofElements_re) + (-0.50000000000000033 * re -
        -0.86602540378443837 * im)) * 0.33333333333333331;
      rtb_Divide_im = (((-0.49999999999999978 * rtb_SumofElements_im_d +
                         0.86602540378443871 * rtb_SumofElements_re_g) +
                        rtb_SumofElements_im) + (-0.50000000000000033 * im +
        -0.86602540378443837 * re)) * 0.33333333333333331;

      /* ComplexToMagnitudeAngle: '<S21>/Complex to Magnitude-Angle' */
      rtb_tArg1_o = rt_atan2d_snf(rtb_Divide_im, rtb_Divide_re);

      /* Delay: '<S21>/Delay' */
      rtb_tArg2_c = PMU_clk_DW->Delay_DSTATE_h;

      /* S-Function (sdspunwrap2): '<S21>/Unwrap' */
      if (PMU_clk_DW->Unwrap_FirstStep_a) {
        PMU_clk_DW->Unwrap_Prev_b = rtb_tArg1_o;
        PMU_clk_DW->Unwrap_FirstStep_a = false;
      }

      rtb_Unwrap_kb = rtb_tArg1_o - PMU_clk_DW->Unwrap_Prev_b;
      dpShift = rtb_Unwrap_kb - floor((rtb_Unwrap_kb + 3.1415926535897931) /
        6.2831853071795862) * 6.2831853071795862;
      if ((dpShift == -3.1415926535897931) && (rtb_Unwrap_kb > 0.0)) {
        dpShift = 3.1415926535897931;
      }

      rtb_Unwrap_kb = dpShift - rtb_Unwrap_kb;
      if (fabs(rtb_Unwrap_kb) > 3.1415926535897931) {
        PMU_clk_DW->Unwrap_Cumsum_e += rtb_Unwrap_kb;
      }

      rtb_Unwrap_kb = rtb_tArg1_o + PMU_clk_DW->Unwrap_Cumsum_e;
      PMU_clk_DW->Unwrap_Prev_b = rtb_tArg1_o;

      /* End of S-Function (sdspunwrap2): '<S21>/Unwrap' */

      /* ZeroOrderHold: '<S22>/Zero-Order Hold1' incorporates:
       *  Constant: '<S22>/i1'
       *  Delay: '<S22>/Delay'
       */
      PMU_clk_B->Merge5 = PMU_clk_DW->Delay_DSTATE_a[824U];

      /* Bias: '<S20>/Bias' incorporates:
       *  Constant: '<S20>/i2'
       *  Product: '<S20>/Divide2'
       */
      dpShift = rtb_Switch * 1000.0 + 1.0;

      /* RelationalOperator: '<S26>/Compare' incorporates:
       *  Bias: '<S20>/Bias'
       *  Constant: '<S26>/Constant'
       */
      rtb_Compare_j0 = (dpShift >= 176.0);

      /* Bias: '<S22>/Bias' incorporates:
       *  Constant: '<S26>/Constant'
       *  DataTypeConversion: '<S22>/Data Type Conversion'
       *  Delay: '<S21>/Delay1'
       *  Gain: '<S21>/Gain9'
       *  Product: '<S22>/Product2'
       *  RelationalOperator: '<S26>/Compare'
       *  Sum: '<S21>/Subtract1'
       */
      PMU_clk_B->Merge2 = (real_T)(dpShift >= 176.0) * ((rtb_Unwrap_kb -
        PMU_clk_DW->Delay1_DSTATE_lc) * 79.57747154594766) + 50.0;

      /* Switch: '<S22>/Switch2' incorporates:
       *  ComplexToMagnitudeAngle: '<S22>/Complex to Magnitude-Angle1'
       *  ComplexToMagnitudeAngle: '<S22>/Complex to Magnitude-Angle2'
       *  ComplexToRealImag: '<S22>/Complex to Real-Imag1'
       *  ComplexToRealImag: '<S22>/Complex to Real-Imag2'
       *  Constant: '<S20>/i1'
       *  Sum: '<S25>/Sum of Elements'
       *  Switch: '<S22>/Switch1'
       */
      if (PMU_clk_P_e->mode >= 1.0) {
        PMU_clk_B->Merge4[0] = rt_hypotd_snf(rtb_SumofElements_re,
          rtb_SumofElements_im);
        PMU_clk_B->Merge4[1] = rt_hypotd_snf(rtb_SumofElements_re_g,
          rtb_SumofElements_im_d);
        PMU_clk_B->Merge4[2] = rt_hypotd_snf(re, im);
        PMU_clk_B->Merge4[3] = rt_atan2d_snf(rtb_SumofElements_im,
          rtb_SumofElements_re);
        PMU_clk_B->Merge4[4] = rt_atan2d_snf(rtb_SumofElements_im_d,
          rtb_SumofElements_re_g);
        PMU_clk_B->Merge4[5] = rt_atan2d_snf(im, re);
        PMU_clk_B->Merge1[0] = rt_hypotd_snf(rtb_Divide_re, rtb_Divide_im);
        PMU_clk_B->Merge1[1] = rt_atan2d_snf(rtb_Divide_im, rtb_Divide_re);
      } else {
        PMU_clk_B->Merge4[0] = rtb_SumofElements_re;
        PMU_clk_B->Merge4[1] = rtb_SumofElements_re_g;
        PMU_clk_B->Merge4[2] = re;
        PMU_clk_B->Merge4[3] = rtb_SumofElements_im;
        PMU_clk_B->Merge4[4] = rtb_SumofElements_im_d;
        PMU_clk_B->Merge4[5] = im;
        PMU_clk_B->Merge1[0] = rtb_Divide_re;
        PMU_clk_B->Merge1[1] = rtb_Divide_im;
      }

      /* End of Switch: '<S22>/Switch2' */

      /* Product: '<S22>/Product' incorporates:
       *  DataTypeConversion: '<S22>/Data Type Conversion'
       */
      for (i = 0; i < 6; i++) {
        PMU_clk_B->Merge4[i] *= (real_T)rtb_Compare_j0;
      }

      /* End of Product: '<S22>/Product' */

      /* Product: '<S22>/Product1' incorporates:
       *  DataTypeConversion: '<S22>/Data Type Conversion'
       */
      PMU_clk_B->Merge1[0] *= (real_T)rtb_Compare_j0;
      PMU_clk_B->Merge1[1] *= (real_T)rtb_Compare_j0;

      /* Product: '<S22>/Product3' incorporates:
       *  Constant: '<S21>/T'
       *  DataTypeConversion: '<S22>/Data Type Conversion'
       *  Delay: '<S21>/Delay'
       *  Delay: '<S21>/Delay1'
       *  Gain: '<S21>/Gain2'
       *  Product: '<S21>/Divide5'
       *  Sum: '<S21>/Subtract3'
       */
      PMU_clk_B->Merge3 = ((PMU_clk_DW->Delay1_DSTATE_lc + rtb_Unwrap_kb) - 2.0 *
                           PMU_clk_DW->Delay_DSTATE_h) / 6.2831853071795858E-6 *
        (real_T)rtb_Compare_j0;

      /* Update for Delay: '<S21>/Delay' */
      PMU_clk_DW->Delay_DSTATE_h = rtb_Unwrap_kb;

      /* Update for Delay: '<S21>/Delay1' */
      PMU_clk_DW->Delay1_DSTATE_lc = rtb_tArg2_c;

      /* Update for Delay: '<S22>/Delay' */
      for (i = 0; i < 999; i++) {
        PMU_clk_DW->Delay_DSTATE_a[i] = PMU_clk_DW->Delay_DSTATE_a[i + 1];
      }

      PMU_clk_DW->Delay_DSTATE_a[999] = rtb_Switch;

      /* End of Update for Delay: '<S22>/Delay' */
      /* End of Outputs for SubSystem: '<Root>/PMU_50Hz_M_25' */
      break;

     case 5:
      /* Outputs for IfAction SubSystem: '<Root>/PMU_50Hz_M_50' incorporates:
       *  ActionPort: '<S3>/Action Port'
       */
      /* Product: '<S28>/Divide' */
      rtb_Divide_im = PMU_clk_ConstB.Fcn1_d *
        PMU_clk_ConstB.RealImagtoComplex_j.im * rtb_Switch;

      /* Math: '<S28>/Math Function' incorporates:
       *  Product: '<S28>/Divide'
       *
       * About '<S28>/Math Function':
       *  Operator: exp
       */
      re = exp(PMU_clk_ConstB.Fcn1_d * PMU_clk_ConstB.RealImagtoComplex_j.re *
               rtb_Switch);
      if (rtb_Divide_im == 0.0) {
        rtb_Divide_re = re;
        rtb_Divide_im = 0.0;
      } else {
        rtb_Divide_re = re * cos(rtb_Divide_im);
        rtb_Divide_im = re * sin(rtb_Divide_im);
      }

      /* End of Math: '<S28>/Math Function' */

      /* Product: '<S28>/Divide1' incorporates:
       *  Gain: '<S28>/Gain1'
       */
      PMU_clk_B->Divide1_c[0].re = 1.4142135623730951 *
        PMU_clk_B->RateTransition[0] * rtb_Divide_re;
      PMU_clk_B->Divide1_c[0].im = 1.4142135623730951 *
        PMU_clk_B->RateTransition[0] * rtb_Divide_im;
      PMU_clk_B->Divide1_c[1].re = 1.4142135623730951 *
        PMU_clk_B->RateTransition[1] * rtb_Divide_re;
      PMU_clk_B->Divide1_c[1].im = 1.4142135623730951 *
        PMU_clk_B->RateTransition[1] * rtb_Divide_im;
      PMU_clk_B->Divide1_c[2].re = 1.4142135623730951 *
        PMU_clk_B->RateTransition[2] * rtb_Divide_re;
      PMU_clk_B->Divide1_c[2].im = 1.4142135623730951 *
        PMU_clk_B->RateTransition[2] * rtb_Divide_im;

      /* Buffer: '<S28>/Buffer1' */
      for (i = 0; i < 148 - PMU_clk_DW->Buffer1_CircBufIdx_e; i++) {
        rtb_Product_f[i] = PMU_clk_DW->Buffer1_CircBuff_m
          [PMU_clk_DW->Buffer1_CircBufIdx_e + i];
      }

      yIdx = 148 - PMU_clk_DW->Buffer1_CircBufIdx_e;
      for (i = 0; i < PMU_clk_DW->Buffer1_CircBufIdx_e; i++) {
        rtb_Product_f[yIdx + i] = PMU_clk_DW->Buffer1_CircBuff_m[i];
      }

      yIdx += PMU_clk_DW->Buffer1_CircBufIdx_e;
      rtb_Product_f[yIdx] = PMU_clk_B->Divide1_c[0];
      PMU_clk_DW->Buffer1_CircBuff_m[PMU_clk_DW->Buffer1_CircBufIdx_e] =
        PMU_clk_B->Divide1_c[0];
      PMU_clk_DW->Buffer1_CircBufIdx_e++;
      if (PMU_clk_DW->Buffer1_CircBufIdx_e >= 148) {
        PMU_clk_DW->Buffer1_CircBufIdx_e -= 148;
      }

      /* End of Buffer: '<S28>/Buffer1' */

      /* Sum: '<S30>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 149; i++) {
        /* Product: '<S30>/Product' incorporates:
         *  Constant: '<S30>/i2'
         */
        rtb_Buffer3_d[i].re = PMU_clk_ConstP.pooled6[i] * rtb_Product_f[i].re;
        rtb_Buffer3_d[i].im = PMU_clk_ConstP.pooled6[i] * rtb_Product_f[i].im;

        /* Sum: '<S30>/Sum of Elements' incorporates:
         *  Product: '<S30>/Product'
         */
        re += rtb_Buffer3_d[i].re;
        im += rtb_Buffer3_d[i].im;
      }

      /* Sum: '<S30>/Sum of Elements' */
      rtb_SumofElements_re = re;
      rtb_SumofElements_im = im;

      /* Buffer: '<S28>/Buffer2' */
      for (i = 0; i < 148 - PMU_clk_DW->Buffer2_CircBufIdx_e; i++) {
        rtb_Buffer3_d[i] = PMU_clk_DW->Buffer2_CircBuff_n
          [PMU_clk_DW->Buffer2_CircBufIdx_e + i];
      }

      yIdx = 148 - PMU_clk_DW->Buffer2_CircBufIdx_e;
      for (i = 0; i < PMU_clk_DW->Buffer2_CircBufIdx_e; i++) {
        rtb_Buffer3_d[yIdx + i] = PMU_clk_DW->Buffer2_CircBuff_n[i];
      }

      yIdx += PMU_clk_DW->Buffer2_CircBufIdx_e;
      rtb_Buffer3_d[yIdx] = PMU_clk_B->Divide1_c[1];
      PMU_clk_DW->Buffer2_CircBuff_n[PMU_clk_DW->Buffer2_CircBufIdx_e] =
        PMU_clk_B->Divide1_c[1];
      PMU_clk_DW->Buffer2_CircBufIdx_e++;
      if (PMU_clk_DW->Buffer2_CircBufIdx_e >= 148) {
        PMU_clk_DW->Buffer2_CircBufIdx_e -= 148;
      }

      /* End of Buffer: '<S28>/Buffer2' */

      /* Sum: '<S31>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 149; i++) {
        /* Product: '<S31>/Product' incorporates:
         *  Constant: '<S31>/i2'
         */
        rtb_Product_f[i].re = PMU_clk_ConstP.pooled6[i] * rtb_Buffer3_d[i].re;
        rtb_Product_f[i].im = PMU_clk_ConstP.pooled6[i] * rtb_Buffer3_d[i].im;

        /* Sum: '<S31>/Sum of Elements' incorporates:
         *  Product: '<S31>/Product'
         */
        re += rtb_Product_f[i].re;
        im += rtb_Product_f[i].im;
      }

      /* Sum: '<S31>/Sum of Elements' */
      rtb_SumofElements_re_g = re;
      rtb_SumofElements_im_d = im;

      /* Buffer: '<S28>/Buffer3' */
      for (i = 0; i < 148 - PMU_clk_DW->Buffer3_CircBufIdx_fl; i++) {
        rtb_Buffer3_d[i] = PMU_clk_DW->Buffer3_CircBuff_b
          [PMU_clk_DW->Buffer3_CircBufIdx_fl + i];
      }

      yIdx = 148 - PMU_clk_DW->Buffer3_CircBufIdx_fl;
      for (i = 0; i < PMU_clk_DW->Buffer3_CircBufIdx_fl; i++) {
        rtb_Buffer3_d[yIdx + i] = PMU_clk_DW->Buffer3_CircBuff_b[i];
      }

      yIdx += PMU_clk_DW->Buffer3_CircBufIdx_fl;
      rtb_Buffer3_d[yIdx] = PMU_clk_B->Divide1_c[2];
      PMU_clk_DW->Buffer3_CircBuff_b[PMU_clk_DW->Buffer3_CircBufIdx_fl] =
        PMU_clk_B->Divide1_c[2];
      PMU_clk_DW->Buffer3_CircBufIdx_fl++;
      if (PMU_clk_DW->Buffer3_CircBufIdx_fl >= 148) {
        PMU_clk_DW->Buffer3_CircBufIdx_fl -= 148;
      }

      /* End of Buffer: '<S28>/Buffer3' */

      /* Sum: '<S32>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 149; i++) {
        /* Product: '<S32>/Product' incorporates:
         *  Constant: '<S32>/i2'
         */
        rtb_Product_f[i].re = PMU_clk_ConstP.pooled6[i] * rtb_Buffer3_d[i].re;
        rtb_Product_f[i].im = PMU_clk_ConstP.pooled6[i] * rtb_Buffer3_d[i].im;

        /* Sum: '<S32>/Sum of Elements' incorporates:
         *  Product: '<S32>/Product'
         */
        re += rtb_Product_f[i].re;
        im += rtb_Product_f[i].im;
      }

      /* Gain: '<S28>/Gain5' incorporates:
       *  Gain: '<S28>/Sequence Gain2'
       *  Gain: '<S28>/Sequence Gain3'
       *  Sum: '<S28>/Add'
       *  Sum: '<S32>/Sum of Elements'
       */
      rtb_Divide_re = (((-0.49999999999999978 * rtb_SumofElements_re_g -
                         0.86602540378443871 * rtb_SumofElements_im_d) +
                        rtb_SumofElements_re) + (-0.50000000000000033 * re -
        -0.86602540378443837 * im)) * 0.33333333333333331;
      rtb_Divide_im = (((-0.49999999999999978 * rtb_SumofElements_im_d +
                         0.86602540378443871 * rtb_SumofElements_re_g) +
                        rtb_SumofElements_im) + (-0.50000000000000033 * im +
        -0.86602540378443837 * re)) * 0.33333333333333331;

      /* ComplexToMagnitudeAngle: '<S28>/Complex to Magnitude-Angle' */
      rtb_tArg1_o = rt_atan2d_snf(rtb_Divide_im, rtb_Divide_re);

      /* Delay: '<S28>/Delay' */
      rtb_tArg2_c = PMU_clk_DW->Delay_DSTATE_br;

      /* S-Function (sdspunwrap2): '<S28>/Unwrap' */
      if (PMU_clk_DW->Unwrap_FirstStep_j) {
        PMU_clk_DW->Unwrap_Prev_n = rtb_tArg1_o;
        PMU_clk_DW->Unwrap_FirstStep_j = false;
      }

      rtb_Unwrap_kb = rtb_tArg1_o - PMU_clk_DW->Unwrap_Prev_n;
      dpShift = rtb_Unwrap_kb - floor((rtb_Unwrap_kb + 3.1415926535897931) /
        6.2831853071795862) * 6.2831853071795862;
      if ((dpShift == -3.1415926535897931) && (rtb_Unwrap_kb > 0.0)) {
        dpShift = 3.1415926535897931;
      }

      rtb_Unwrap_kb = dpShift - rtb_Unwrap_kb;
      if (fabs(rtb_Unwrap_kb) > 3.1415926535897931) {
        PMU_clk_DW->Unwrap_Cumsum_n += rtb_Unwrap_kb;
      }

      rtb_Unwrap_kb = rtb_tArg1_o + PMU_clk_DW->Unwrap_Cumsum_n;
      PMU_clk_DW->Unwrap_Prev_n = rtb_tArg1_o;

      /* End of S-Function (sdspunwrap2): '<S28>/Unwrap' */

      /* ZeroOrderHold: '<S29>/Zero-Order Hold1' incorporates:
       *  Constant: '<S29>/i1'
       *  Delay: '<S29>/Delay'
       */
      PMU_clk_B->Merge5 = PMU_clk_DW->Delay_DSTATE_dv[926U];

      /* RelationalOperator: '<S33>/Compare' incorporates:
       *  Bias: '<S27>/Bias'
       *  Constant: '<S27>/i2'
       *  Constant: '<S33>/Constant'
       *  Product: '<S27>/Divide2'
       */
      rtb_Compare_j0 = (rtb_Switch * 1000.0 + 1.0 >= 74.0);

      /* Bias: '<S29>/Bias' incorporates:
       *  Bias: '<S27>/Bias'
       *  Constant: '<S27>/i2'
       *  Constant: '<S33>/Constant'
       *  DataTypeConversion: '<S29>/Data Type Conversion'
       *  Delay: '<S28>/Delay1'
       *  Gain: '<S28>/Gain9'
       *  Product: '<S27>/Divide2'
       *  Product: '<S29>/Product2'
       *  RelationalOperator: '<S33>/Compare'
       *  Sum: '<S28>/Subtract1'
       */
      PMU_clk_B->Merge2 = (real_T)(rtb_Switch * 1000.0 + 1.0 >= 74.0) *
        ((rtb_Unwrap_kb - PMU_clk_DW->Delay1_DSTATE_j) * 79.57747154594766) +
        50.0;

      /* Switch: '<S29>/Switch2' incorporates:
       *  ComplexToMagnitudeAngle: '<S29>/Complex to Magnitude-Angle1'
       *  ComplexToMagnitudeAngle: '<S29>/Complex to Magnitude-Angle2'
       *  ComplexToRealImag: '<S29>/Complex to Real-Imag1'
       *  ComplexToRealImag: '<S29>/Complex to Real-Imag2'
       *  Constant: '<S27>/i1'
       *  Sum: '<S32>/Sum of Elements'
       *  Switch: '<S29>/Switch1'
       */
      if (PMU_clk_P_e->mode >= 1.0) {
        PMU_clk_B->Merge4[0] = rt_hypotd_snf(rtb_SumofElements_re,
          rtb_SumofElements_im);
        PMU_clk_B->Merge4[1] = rt_hypotd_snf(rtb_SumofElements_re_g,
          rtb_SumofElements_im_d);
        PMU_clk_B->Merge4[2] = rt_hypotd_snf(re, im);
        PMU_clk_B->Merge4[3] = rt_atan2d_snf(rtb_SumofElements_im,
          rtb_SumofElements_re);
        PMU_clk_B->Merge4[4] = rt_atan2d_snf(rtb_SumofElements_im_d,
          rtb_SumofElements_re_g);
        PMU_clk_B->Merge4[5] = rt_atan2d_snf(im, re);
        PMU_clk_B->Merge1[0] = rt_hypotd_snf(rtb_Divide_re, rtb_Divide_im);
        PMU_clk_B->Merge1[1] = rt_atan2d_snf(rtb_Divide_im, rtb_Divide_re);
      } else {
        PMU_clk_B->Merge4[0] = rtb_SumofElements_re;
        PMU_clk_B->Merge4[1] = rtb_SumofElements_re_g;
        PMU_clk_B->Merge4[2] = re;
        PMU_clk_B->Merge4[3] = rtb_SumofElements_im;
        PMU_clk_B->Merge4[4] = rtb_SumofElements_im_d;
        PMU_clk_B->Merge4[5] = im;
        PMU_clk_B->Merge1[0] = rtb_Divide_re;
        PMU_clk_B->Merge1[1] = rtb_Divide_im;
      }

      /* End of Switch: '<S29>/Switch2' */

      /* Product: '<S29>/Product' incorporates:
       *  DataTypeConversion: '<S29>/Data Type Conversion'
       */
      for (i = 0; i < 6; i++) {
        PMU_clk_B->Merge4[i] *= (real_T)rtb_Compare_j0;
      }

      /* End of Product: '<S29>/Product' */

      /* Product: '<S29>/Product1' incorporates:
       *  DataTypeConversion: '<S29>/Data Type Conversion'
       */
      PMU_clk_B->Merge1[0] *= (real_T)rtb_Compare_j0;
      PMU_clk_B->Merge1[1] *= (real_T)rtb_Compare_j0;

      /* Product: '<S29>/Product3' incorporates:
       *  Constant: '<S28>/T'
       *  DataTypeConversion: '<S29>/Data Type Conversion'
       *  Delay: '<S28>/Delay'
       *  Delay: '<S28>/Delay1'
       *  Gain: '<S28>/Gain2'
       *  Product: '<S28>/Divide5'
       *  Sum: '<S28>/Subtract3'
       */
      PMU_clk_B->Merge3 = ((PMU_clk_DW->Delay1_DSTATE_j + rtb_Unwrap_kb) - 2.0 *
                           PMU_clk_DW->Delay_DSTATE_br) / 6.2831853071795858E-6 *
        (real_T)rtb_Compare_j0;

      /* Update for Delay: '<S28>/Delay' */
      PMU_clk_DW->Delay_DSTATE_br = rtb_Unwrap_kb;

      /* Update for Delay: '<S28>/Delay1' */
      PMU_clk_DW->Delay1_DSTATE_j = rtb_tArg2_c;

      /* Update for Delay: '<S29>/Delay' */
      for (i = 0; i < 999; i++) {
        PMU_clk_DW->Delay_DSTATE_dv[i] = PMU_clk_DW->Delay_DSTATE_dv[i + 1];
      }

      PMU_clk_DW->Delay_DSTATE_dv[999] = rtb_Switch;

      /* End of Update for Delay: '<S29>/Delay' */
      /* End of Outputs for SubSystem: '<Root>/PMU_50Hz_M_50' */
      break;

     case 6:
      /* Outputs for IfAction SubSystem: '<Root>/PMU_50Hz_M_100' incorporates:
       *  ActionPort: '<S1>/Action Port'
       */
      /* Product: '<S14>/Divide' */
      rtb_Divide_im = PMU_clk_ConstB.Fcn1_i *
        PMU_clk_ConstB.RealImagtoComplex_o.im * rtb_Switch;

      /* Math: '<S14>/Math Function' incorporates:
       *  Product: '<S14>/Divide'
       *
       * About '<S14>/Math Function':
       *  Operator: exp
       */
      re = exp(PMU_clk_ConstB.Fcn1_i * PMU_clk_ConstB.RealImagtoComplex_o.re *
               rtb_Switch);
      if (rtb_Divide_im == 0.0) {
        rtb_Divide_re = re;
        rtb_Divide_im = 0.0;
      } else {
        rtb_Divide_re = re * cos(rtb_Divide_im);
        rtb_Divide_im = re * sin(rtb_Divide_im);
      }

      /* End of Math: '<S14>/Math Function' */

      /* Product: '<S14>/Divide1' incorporates:
       *  Gain: '<S14>/Gain1'
       */
      PMU_clk_B->Divide1_a[0].re = 1.4142135623730951 *
        PMU_clk_B->RateTransition[0] * rtb_Divide_re;
      PMU_clk_B->Divide1_a[0].im = 1.4142135623730951 *
        PMU_clk_B->RateTransition[0] * rtb_Divide_im;
      PMU_clk_B->Divide1_a[1].re = 1.4142135623730951 *
        PMU_clk_B->RateTransition[1] * rtb_Divide_re;
      PMU_clk_B->Divide1_a[1].im = 1.4142135623730951 *
        PMU_clk_B->RateTransition[1] * rtb_Divide_im;
      PMU_clk_B->Divide1_a[2].re = 1.4142135623730951 *
        PMU_clk_B->RateTransition[2] * rtb_Divide_re;
      PMU_clk_B->Divide1_a[2].im = 1.4142135623730951 *
        PMU_clk_B->RateTransition[2] * rtb_Divide_im;

      /* Buffer: '<S14>/Buffer1' */
      for (i = 0; i < 70 - PMU_clk_DW->Buffer1_CircBufIdx_b; i++) {
        rtb_Product_d[i] = PMU_clk_DW->Buffer1_CircBuff_j
          [PMU_clk_DW->Buffer1_CircBufIdx_b + i];
      }

      yIdx = 70 - PMU_clk_DW->Buffer1_CircBufIdx_b;
      for (i = 0; i < PMU_clk_DW->Buffer1_CircBufIdx_b; i++) {
        rtb_Product_d[yIdx + i] = PMU_clk_DW->Buffer1_CircBuff_j[i];
      }

      yIdx += PMU_clk_DW->Buffer1_CircBufIdx_b;
      rtb_Product_d[yIdx] = PMU_clk_B->Divide1_a[0];
      PMU_clk_DW->Buffer1_CircBuff_j[PMU_clk_DW->Buffer1_CircBufIdx_b] =
        PMU_clk_B->Divide1_a[0];
      PMU_clk_DW->Buffer1_CircBufIdx_b++;
      if (PMU_clk_DW->Buffer1_CircBufIdx_b >= 70) {
        PMU_clk_DW->Buffer1_CircBufIdx_b -= 70;
      }

      /* End of Buffer: '<S14>/Buffer1' */

      /* Sum: '<S16>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 71; i++) {
        /* Product: '<S16>/Product' incorporates:
         *  Constant: '<S16>/i2'
         */
        rtb_Buffer3_oj[i].re = PMU_clk_ConstP.pooled10[i] * rtb_Product_d[i].re;
        rtb_Buffer3_oj[i].im = PMU_clk_ConstP.pooled10[i] * rtb_Product_d[i].im;

        /* Sum: '<S16>/Sum of Elements' incorporates:
         *  Product: '<S16>/Product'
         */
        re += rtb_Buffer3_oj[i].re;
        im += rtb_Buffer3_oj[i].im;
      }

      /* Sum: '<S16>/Sum of Elements' */
      rtb_SumofElements_re = re;
      rtb_SumofElements_im = im;

      /* Buffer: '<S14>/Buffer2' */
      for (i = 0; i < 70 - PMU_clk_DW->Buffer2_CircBufIdx_i; i++) {
        rtb_Buffer3_oj[i] = PMU_clk_DW->Buffer2_CircBuff_o
          [PMU_clk_DW->Buffer2_CircBufIdx_i + i];
      }

      yIdx = 70 - PMU_clk_DW->Buffer2_CircBufIdx_i;
      for (i = 0; i < PMU_clk_DW->Buffer2_CircBufIdx_i; i++) {
        rtb_Buffer3_oj[yIdx + i] = PMU_clk_DW->Buffer2_CircBuff_o[i];
      }

      yIdx += PMU_clk_DW->Buffer2_CircBufIdx_i;
      rtb_Buffer3_oj[yIdx] = PMU_clk_B->Divide1_a[1];
      PMU_clk_DW->Buffer2_CircBuff_o[PMU_clk_DW->Buffer2_CircBufIdx_i] =
        PMU_clk_B->Divide1_a[1];
      PMU_clk_DW->Buffer2_CircBufIdx_i++;
      if (PMU_clk_DW->Buffer2_CircBufIdx_i >= 70) {
        PMU_clk_DW->Buffer2_CircBufIdx_i -= 70;
      }

      /* End of Buffer: '<S14>/Buffer2' */

      /* Sum: '<S17>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 71; i++) {
        /* Product: '<S17>/Product' incorporates:
         *  Constant: '<S17>/i2'
         */
        rtb_Product_d[i].re = PMU_clk_ConstP.pooled10[i] * rtb_Buffer3_oj[i].re;
        rtb_Product_d[i].im = PMU_clk_ConstP.pooled10[i] * rtb_Buffer3_oj[i].im;

        /* Sum: '<S17>/Sum of Elements' incorporates:
         *  Product: '<S17>/Product'
         */
        re += rtb_Product_d[i].re;
        im += rtb_Product_d[i].im;
      }

      /* Sum: '<S17>/Sum of Elements' */
      rtb_SumofElements_re_g = re;
      rtb_SumofElements_im_d = im;

      /* Buffer: '<S14>/Buffer3' */
      for (i = 0; i < 70 - PMU_clk_DW->Buffer3_CircBufIdx_f; i++) {
        rtb_Buffer3_oj[i] = PMU_clk_DW->Buffer3_CircBuff_pn
          [PMU_clk_DW->Buffer3_CircBufIdx_f + i];
      }

      yIdx = 70 - PMU_clk_DW->Buffer3_CircBufIdx_f;
      for (i = 0; i < PMU_clk_DW->Buffer3_CircBufIdx_f; i++) {
        rtb_Buffer3_oj[yIdx + i] = PMU_clk_DW->Buffer3_CircBuff_pn[i];
      }

      yIdx += PMU_clk_DW->Buffer3_CircBufIdx_f;
      rtb_Buffer3_oj[yIdx] = PMU_clk_B->Divide1_a[2];
      PMU_clk_DW->Buffer3_CircBuff_pn[PMU_clk_DW->Buffer3_CircBufIdx_f] =
        PMU_clk_B->Divide1_a[2];
      PMU_clk_DW->Buffer3_CircBufIdx_f++;
      if (PMU_clk_DW->Buffer3_CircBufIdx_f >= 70) {
        PMU_clk_DW->Buffer3_CircBufIdx_f -= 70;
      }

      /* End of Buffer: '<S14>/Buffer3' */

      /* Sum: '<S18>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 71; i++) {
        /* Product: '<S18>/Product' incorporates:
         *  Constant: '<S18>/i2'
         */
        rtb_Product_d[i].re = PMU_clk_ConstP.pooled10[i] * rtb_Buffer3_oj[i].re;
        rtb_Product_d[i].im = PMU_clk_ConstP.pooled10[i] * rtb_Buffer3_oj[i].im;

        /* Sum: '<S18>/Sum of Elements' incorporates:
         *  Product: '<S18>/Product'
         */
        re += rtb_Product_d[i].re;
        im += rtb_Product_d[i].im;
      }

      /* Gain: '<S14>/Gain5' incorporates:
       *  Gain: '<S14>/Sequence Gain2'
       *  Gain: '<S14>/Sequence Gain3'
       *  Sum: '<S14>/Add'
       *  Sum: '<S18>/Sum of Elements'
       */
      rtb_Divide_re = (((-0.49999999999999978 * rtb_SumofElements_re_g -
                         0.86602540378443871 * rtb_SumofElements_im_d) +
                        rtb_SumofElements_re) + (-0.50000000000000033 * re -
        -0.86602540378443837 * im)) * 0.33333333333333331;
      rtb_Divide_im = (((-0.49999999999999978 * rtb_SumofElements_im_d +
                         0.86602540378443871 * rtb_SumofElements_re_g) +
                        rtb_SumofElements_im) + (-0.50000000000000033 * im +
        -0.86602540378443837 * re)) * 0.33333333333333331;

      /* ComplexToMagnitudeAngle: '<S14>/Complex to Magnitude-Angle' */
      rtb_tArg1_o = rt_atan2d_snf(rtb_Divide_im, rtb_Divide_re);

      /* Delay: '<S14>/Delay' */
      rtb_tArg2_c = PMU_clk_DW->Delay_DSTATE_f;

      /* S-Function (sdspunwrap2): '<S14>/Unwrap' */
      if (PMU_clk_DW->Unwrap_FirstStep_m) {
        PMU_clk_DW->Unwrap_Prev_h = rtb_tArg1_o;
        PMU_clk_DW->Unwrap_FirstStep_m = false;
      }

      rtb_Unwrap_kb = rtb_tArg1_o - PMU_clk_DW->Unwrap_Prev_h;
      dpShift = rtb_Unwrap_kb - floor((rtb_Unwrap_kb + 3.1415926535897931) /
        6.2831853071795862) * 6.2831853071795862;
      if ((dpShift == -3.1415926535897931) && (rtb_Unwrap_kb > 0.0)) {
        dpShift = 3.1415926535897931;
      }

      rtb_Unwrap_kb = dpShift - rtb_Unwrap_kb;
      if (fabs(rtb_Unwrap_kb) > 3.1415926535897931) {
        PMU_clk_DW->Unwrap_Cumsum_f += rtb_Unwrap_kb;
      }

      rtb_Unwrap_kb = rtb_tArg1_o + PMU_clk_DW->Unwrap_Cumsum_f;
      PMU_clk_DW->Unwrap_Prev_h = rtb_tArg1_o;

      /* End of S-Function (sdspunwrap2): '<S14>/Unwrap' */

      /* ZeroOrderHold: '<S15>/Zero-Order Hold1' incorporates:
       *  Constant: '<S15>/i1'
       *  Delay: '<S15>/Delay'
       */
      PMU_clk_B->Merge5 = PMU_clk_DW->Delay_DSTATE_d[965U];

      /* RelationalOperator: '<S19>/Compare' incorporates:
       *  Bias: '<S13>/Bias'
       *  Constant: '<S13>/i2'
       *  Constant: '<S19>/Constant'
       *  Product: '<S13>/Divide2'
       */
      rtb_Compare_j0 = (rtb_Switch * 1000.0 + 1.0 >= 35.5);

      /* Bias: '<S15>/Bias' incorporates:
       *  Bias: '<S13>/Bias'
       *  Constant: '<S13>/i2'
       *  Constant: '<S19>/Constant'
       *  DataTypeConversion: '<S15>/Data Type Conversion'
       *  Delay: '<S14>/Delay1'
       *  Gain: '<S14>/Gain9'
       *  Product: '<S13>/Divide2'
       *  Product: '<S15>/Product2'
       *  RelationalOperator: '<S19>/Compare'
       *  Sum: '<S14>/Subtract1'
       */
      PMU_clk_B->Merge2 = (real_T)(rtb_Switch * 1000.0 + 1.0 >= 35.5) *
        ((rtb_Unwrap_kb - PMU_clk_DW->Delay1_DSTATE_or) * 79.57747154594766) +
        50.0;

      /* Switch: '<S15>/Switch2' incorporates:
       *  ComplexToMagnitudeAngle: '<S15>/Complex to Magnitude-Angle1'
       *  ComplexToMagnitudeAngle: '<S15>/Complex to Magnitude-Angle2'
       *  ComplexToRealImag: '<S15>/Complex to Real-Imag1'
       *  ComplexToRealImag: '<S15>/Complex to Real-Imag2'
       *  Constant: '<S13>/i1'
       *  Sum: '<S18>/Sum of Elements'
       *  Switch: '<S15>/Switch1'
       */
      if (PMU_clk_P_e->mode >= 1.0) {
        PMU_clk_B->Merge4[0] = rt_hypotd_snf(rtb_SumofElements_re,
          rtb_SumofElements_im);
        PMU_clk_B->Merge4[1] = rt_hypotd_snf(rtb_SumofElements_re_g,
          rtb_SumofElements_im_d);
        PMU_clk_B->Merge4[2] = rt_hypotd_snf(re, im);
        PMU_clk_B->Merge4[3] = rt_atan2d_snf(rtb_SumofElements_im,
          rtb_SumofElements_re);
        PMU_clk_B->Merge4[4] = rt_atan2d_snf(rtb_SumofElements_im_d,
          rtb_SumofElements_re_g);
        PMU_clk_B->Merge4[5] = rt_atan2d_snf(im, re);
        PMU_clk_B->Merge1[0] = rt_hypotd_snf(rtb_Divide_re, rtb_Divide_im);
        PMU_clk_B->Merge1[1] = rt_atan2d_snf(rtb_Divide_im, rtb_Divide_re);
      } else {
        PMU_clk_B->Merge4[0] = rtb_SumofElements_re;
        PMU_clk_B->Merge4[1] = rtb_SumofElements_re_g;
        PMU_clk_B->Merge4[2] = re;
        PMU_clk_B->Merge4[3] = rtb_SumofElements_im;
        PMU_clk_B->Merge4[4] = rtb_SumofElements_im_d;
        PMU_clk_B->Merge4[5] = im;
        PMU_clk_B->Merge1[0] = rtb_Divide_re;
        PMU_clk_B->Merge1[1] = rtb_Divide_im;
      }

      /* End of Switch: '<S15>/Switch2' */

      /* Product: '<S15>/Product' incorporates:
       *  DataTypeConversion: '<S15>/Data Type Conversion'
       */
      for (i = 0; i < 6; i++) {
        PMU_clk_B->Merge4[i] *= (real_T)rtb_Compare_j0;
      }

      /* End of Product: '<S15>/Product' */

      /* Product: '<S15>/Product1' incorporates:
       *  DataTypeConversion: '<S15>/Data Type Conversion'
       */
      PMU_clk_B->Merge1[0] *= (real_T)rtb_Compare_j0;
      PMU_clk_B->Merge1[1] *= (real_T)rtb_Compare_j0;

      /* Product: '<S15>/Product3' incorporates:
       *  Constant: '<S14>/T'
       *  DataTypeConversion: '<S15>/Data Type Conversion'
       *  Delay: '<S14>/Delay'
       *  Delay: '<S14>/Delay1'
       *  Gain: '<S14>/Gain2'
       *  Product: '<S14>/Divide5'
       *  Sum: '<S14>/Subtract3'
       */
      PMU_clk_B->Merge3 = ((PMU_clk_DW->Delay1_DSTATE_or + rtb_Unwrap_kb) - 2.0 *
                           PMU_clk_DW->Delay_DSTATE_f) / 6.2831853071795858E-6 *
        (real_T)rtb_Compare_j0;

      /* Update for Delay: '<S14>/Delay' */
      PMU_clk_DW->Delay_DSTATE_f = rtb_Unwrap_kb;

      /* Update for Delay: '<S14>/Delay1' */
      PMU_clk_DW->Delay1_DSTATE_or = rtb_tArg2_c;

      /* Update for Delay: '<S15>/Delay' */
      for (i = 0; i < 999; i++) {
        PMU_clk_DW->Delay_DSTATE_d[i] = PMU_clk_DW->Delay_DSTATE_d[i + 1];
      }

      PMU_clk_DW->Delay_DSTATE_d[999] = rtb_Switch;

      /* End of Update for Delay: '<S15>/Delay' */
      /* End of Outputs for SubSystem: '<Root>/PMU_50Hz_M_100' */
      break;

     case 7:
      /* Outputs for IfAction SubSystem: '<Root>/PMU_60Hz_P_30' incorporates:
       *  ActionPort: '<S11>/Action Port'
       */
      PMU_clk_PMU_60Hz_P_30(PMU_clk_B->RateTransition, rtb_Switch,
                            PMU_clk_B->Merge4, PMU_clk_B->Merge1,
                            &PMU_clk_B->Merge2, &PMU_clk_B->Merge3,
                            &PMU_clk_B->Merge5, &PMU_clk_B->PMU_60Hz_P_30,
                            &PMU_clk_ConstB.PMU_60Hz_P_30,
                            &PMU_clk_DW->PMU_60Hz_P_30, PMU_clk_P_e);

      /* End of Outputs for SubSystem: '<Root>/PMU_60Hz_P_30' */
      break;

     case 8:
      /* Outputs for IfAction SubSystem: '<Root>/PMU_60Hz_P_60' incorporates:
       *  ActionPort: '<S12>/Action Port'
       */
      PMU_clk_PMU_60Hz_P_30(PMU_clk_B->RateTransition, rtb_Switch,
                            PMU_clk_B->Merge4, PMU_clk_B->Merge1,
                            &PMU_clk_B->Merge2, &PMU_clk_B->Merge3,
                            &PMU_clk_B->Merge5, &PMU_clk_B->PMU_60Hz_P_60,
                            &PMU_clk_ConstB.PMU_60Hz_P_60,
                            &PMU_clk_DW->PMU_60Hz_P_60, PMU_clk_P_e);

      /* End of Outputs for SubSystem: '<Root>/PMU_60Hz_P_60' */
      break;

     case 9:
      /* Outputs for IfAction SubSystem: '<Root>/PMU_60Hz_P_120' incorporates:
       *  ActionPort: '<S10>/Action Port'
       */
      PMU_clk_PMU_60Hz_P_30(PMU_clk_B->RateTransition, rtb_Switch,
                            PMU_clk_B->Merge4, PMU_clk_B->Merge1,
                            &PMU_clk_B->Merge2, &PMU_clk_B->Merge3,
                            &PMU_clk_B->Merge5, &PMU_clk_B->PMU_60Hz_P_120,
                            &PMU_clk_ConstB.PMU_60Hz_P_120,
                            &PMU_clk_DW->PMU_60Hz_P_120, PMU_clk_P_e);

      /* End of Outputs for SubSystem: '<Root>/PMU_60Hz_P_120' */
      break;

     case 10:
      /* Outputs for IfAction SubSystem: '<Root>/PMU_60Hz_M_30' incorporates:
       *  ActionPort: '<S8>/Action Port'
       */
      /* Product: '<S63>/Divide' */
      rtb_Divide_im = PMU_clk_ConstB.Fcn1_b *
        PMU_clk_ConstB.RealImagtoComplex_c.im * rtb_Switch;

      /* Math: '<S63>/Math Function' incorporates:
       *  Product: '<S63>/Divide'
       *
       * About '<S63>/Math Function':
       *  Operator: exp
       */
      re = exp(PMU_clk_ConstB.Fcn1_b * PMU_clk_ConstB.RealImagtoComplex_c.re *
               rtb_Switch);
      if (rtb_Divide_im == 0.0) {
        rtb_Divide_re = re;
        rtb_Divide_im = 0.0;
      } else {
        rtb_Divide_re = re * cos(rtb_Divide_im);
        rtb_Divide_im = re * sin(rtb_Divide_im);
      }

      /* End of Math: '<S63>/Math Function' */

      /* Product: '<S63>/Divide1' incorporates:
       *  Gain: '<S63>/Gain1'
       */
      PMU_clk_B->Divide1_l[0].re = 1.4142135623730951 *
        PMU_clk_B->RateTransition[0] * rtb_Divide_re;
      PMU_clk_B->Divide1_l[0].im = 1.4142135623730951 *
        PMU_clk_B->RateTransition[0] * rtb_Divide_im;
      PMU_clk_B->Divide1_l[1].re = 1.4142135623730951 *
        PMU_clk_B->RateTransition[1] * rtb_Divide_re;
      PMU_clk_B->Divide1_l[1].im = 1.4142135623730951 *
        PMU_clk_B->RateTransition[1] * rtb_Divide_im;
      PMU_clk_B->Divide1_l[2].re = 1.4142135623730951 *
        PMU_clk_B->RateTransition[2] * rtb_Divide_re;
      PMU_clk_B->Divide1_l[2].im = 1.4142135623730951 *
        PMU_clk_B->RateTransition[2] * rtb_Divide_im;

      /* Buffer: '<S63>/Buffer1' */
      for (i = 0; i < 318 - PMU_clk_DW->Buffer1_CircBufIdx_g; i++) {
        PMU_clk_B->Product_i[i] = PMU_clk_DW->Buffer1_CircBuff_i
          [PMU_clk_DW->Buffer1_CircBufIdx_g + i];
      }

      yIdx = 318 - PMU_clk_DW->Buffer1_CircBufIdx_g;
      for (i = 0; i < PMU_clk_DW->Buffer1_CircBufIdx_g; i++) {
        PMU_clk_B->Product_i[yIdx + i] = PMU_clk_DW->Buffer1_CircBuff_i[i];
      }

      yIdx += PMU_clk_DW->Buffer1_CircBufIdx_g;
      PMU_clk_B->Product_i[yIdx] = PMU_clk_B->Divide1_l[0];
      PMU_clk_DW->Buffer1_CircBuff_i[PMU_clk_DW->Buffer1_CircBufIdx_g] =
        PMU_clk_B->Divide1_l[0];
      PMU_clk_DW->Buffer1_CircBufIdx_g++;
      if (PMU_clk_DW->Buffer1_CircBufIdx_g >= 318) {
        PMU_clk_DW->Buffer1_CircBufIdx_g -= 318;
      }

      /* End of Buffer: '<S63>/Buffer1' */

      /* Sum: '<S65>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 319; i++) {
        /* Product: '<S65>/Product' incorporates:
         *  Constant: '<S65>/i2'
         */
        PMU_clk_B->Buffer3_p[i].re = PMU_clk_ConstP.pooled23[i] *
          PMU_clk_B->Product_i[i].re;
        PMU_clk_B->Buffer3_p[i].im = PMU_clk_ConstP.pooled23[i] *
          PMU_clk_B->Product_i[i].im;

        /* Sum: '<S65>/Sum of Elements' incorporates:
         *  Product: '<S65>/Product'
         */
        re += PMU_clk_B->Buffer3_p[i].re;
        im += PMU_clk_B->Buffer3_p[i].im;
      }

      /* Sum: '<S65>/Sum of Elements' */
      rtb_SumofElements_re = re;
      rtb_SumofElements_im = im;

      /* Buffer: '<S63>/Buffer2' */
      for (i = 0; i < 318 - PMU_clk_DW->Buffer2_CircBufIdx_n; i++) {
        PMU_clk_B->Buffer3_p[i] = PMU_clk_DW->Buffer2_CircBuff_b
          [PMU_clk_DW->Buffer2_CircBufIdx_n + i];
      }

      yIdx = 318 - PMU_clk_DW->Buffer2_CircBufIdx_n;
      for (i = 0; i < PMU_clk_DW->Buffer2_CircBufIdx_n; i++) {
        PMU_clk_B->Buffer3_p[yIdx + i] = PMU_clk_DW->Buffer2_CircBuff_b[i];
      }

      yIdx += PMU_clk_DW->Buffer2_CircBufIdx_n;
      PMU_clk_B->Buffer3_p[yIdx] = PMU_clk_B->Divide1_l[1];
      PMU_clk_DW->Buffer2_CircBuff_b[PMU_clk_DW->Buffer2_CircBufIdx_n] =
        PMU_clk_B->Divide1_l[1];
      PMU_clk_DW->Buffer2_CircBufIdx_n++;
      if (PMU_clk_DW->Buffer2_CircBufIdx_n >= 318) {
        PMU_clk_DW->Buffer2_CircBufIdx_n -= 318;
      }

      /* End of Buffer: '<S63>/Buffer2' */

      /* Sum: '<S66>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 319; i++) {
        /* Product: '<S66>/Product' incorporates:
         *  Constant: '<S66>/i2'
         */
        PMU_clk_B->Product_i[i].re = PMU_clk_ConstP.pooled23[i] *
          PMU_clk_B->Buffer3_p[i].re;
        PMU_clk_B->Product_i[i].im = PMU_clk_ConstP.pooled23[i] *
          PMU_clk_B->Buffer3_p[i].im;

        /* Sum: '<S66>/Sum of Elements' incorporates:
         *  Product: '<S66>/Product'
         */
        re += PMU_clk_B->Product_i[i].re;
        im += PMU_clk_B->Product_i[i].im;
      }

      /* Sum: '<S66>/Sum of Elements' */
      rtb_SumofElements_re_g = re;
      rtb_SumofElements_im_d = im;

      /* Buffer: '<S63>/Buffer3' */
      for (i = 0; i < 318 - PMU_clk_DW->Buffer3_CircBufIdx_j; i++) {
        PMU_clk_B->Buffer3_p[i] = PMU_clk_DW->Buffer3_CircBuff_g
          [PMU_clk_DW->Buffer3_CircBufIdx_j + i];
      }

      yIdx = 318 - PMU_clk_DW->Buffer3_CircBufIdx_j;
      for (i = 0; i < PMU_clk_DW->Buffer3_CircBufIdx_j; i++) {
        PMU_clk_B->Buffer3_p[yIdx + i] = PMU_clk_DW->Buffer3_CircBuff_g[i];
      }

      yIdx += PMU_clk_DW->Buffer3_CircBufIdx_j;
      PMU_clk_B->Buffer3_p[yIdx] = PMU_clk_B->Divide1_l[2];
      PMU_clk_DW->Buffer3_CircBuff_g[PMU_clk_DW->Buffer3_CircBufIdx_j] =
        PMU_clk_B->Divide1_l[2];
      PMU_clk_DW->Buffer3_CircBufIdx_j++;
      if (PMU_clk_DW->Buffer3_CircBufIdx_j >= 318) {
        PMU_clk_DW->Buffer3_CircBufIdx_j -= 318;
      }

      /* End of Buffer: '<S63>/Buffer3' */

      /* Sum: '<S67>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 319; i++) {
        /* Product: '<S67>/Product' incorporates:
         *  Constant: '<S67>/i2'
         */
        PMU_clk_B->Product_i[i].re = PMU_clk_ConstP.pooled23[i] *
          PMU_clk_B->Buffer3_p[i].re;
        PMU_clk_B->Product_i[i].im = PMU_clk_ConstP.pooled23[i] *
          PMU_clk_B->Buffer3_p[i].im;

        /* Sum: '<S67>/Sum of Elements' incorporates:
         *  Product: '<S67>/Product'
         */
        re += PMU_clk_B->Product_i[i].re;
        im += PMU_clk_B->Product_i[i].im;
      }

      /* Gain: '<S63>/Gain5' incorporates:
       *  Gain: '<S63>/Sequence Gain2'
       *  Gain: '<S63>/Sequence Gain3'
       *  Sum: '<S63>/Add'
       *  Sum: '<S67>/Sum of Elements'
       */
      rtb_Divide_re = (((-0.49999999999999978 * rtb_SumofElements_re_g -
                         0.86602540378443871 * rtb_SumofElements_im_d) +
                        rtb_SumofElements_re) + (-0.50000000000000033 * re -
        -0.86602540378443837 * im)) * 0.33333333333333331;
      rtb_Divide_im = (((-0.49999999999999978 * rtb_SumofElements_im_d +
                         0.86602540378443871 * rtb_SumofElements_re_g) +
                        rtb_SumofElements_im) + (-0.50000000000000033 * im +
        -0.86602540378443837 * re)) * 0.33333333333333331;

      /* ComplexToMagnitudeAngle: '<S63>/Complex to Magnitude-Angle' */
      rtb_tArg1_o = rt_atan2d_snf(rtb_Divide_im, rtb_Divide_re);

      /* Delay: '<S63>/Delay' */
      rtb_tArg2_c = PMU_clk_DW->Delay_DSTATE_e;

      /* S-Function (sdspunwrap2): '<S63>/Unwrap' */
      if (PMU_clk_DW->Unwrap_FirstStep_o) {
        PMU_clk_DW->Unwrap_Prev_l = rtb_tArg1_o;
        PMU_clk_DW->Unwrap_FirstStep_o = false;
      }

      rtb_Unwrap_kb = rtb_tArg1_o - PMU_clk_DW->Unwrap_Prev_l;
      dpShift = rtb_Unwrap_kb - floor((rtb_Unwrap_kb + 3.1415926535897931) /
        6.2831853071795862) * 6.2831853071795862;
      if ((dpShift == -3.1415926535897931) && (rtb_Unwrap_kb > 0.0)) {
        dpShift = 3.1415926535897931;
      }

      rtb_Unwrap_kb = dpShift - rtb_Unwrap_kb;
      if (fabs(rtb_Unwrap_kb) > 3.1415926535897931) {
        PMU_clk_DW->Unwrap_Cumsum_l += rtb_Unwrap_kb;
      }

      rtb_Unwrap_kb = rtb_tArg1_o + PMU_clk_DW->Unwrap_Cumsum_l;
      PMU_clk_DW->Unwrap_Prev_l = rtb_tArg1_o;

      /* End of S-Function (sdspunwrap2): '<S63>/Unwrap' */

      /* ZeroOrderHold: '<S64>/Zero-Order Hold1' incorporates:
       *  Constant: '<S64>/i1'
       *  Delay: '<S64>/Delay'
       */
      PMU_clk_B->Merge5 = PMU_clk_DW->Delay_DSTATE_g[841U];

      /* RelationalOperator: '<S68>/Compare' incorporates:
       *  Bias: '<S62>/Bias'
       *  Constant: '<S62>/i2'
       *  Constant: '<S68>/Constant'
       *  Product: '<S62>/Divide2'
       */
      rtb_Compare_j0 = (rtb_Switch * 1000.0 + 1.0 >= 159.0);

      /* Bias: '<S64>/Bias' incorporates:
       *  Bias: '<S62>/Bias'
       *  Constant: '<S62>/i2'
       *  Constant: '<S68>/Constant'
       *  DataTypeConversion: '<S64>/Data Type Conversion'
       *  Delay: '<S63>/Delay1'
       *  Gain: '<S63>/Gain9'
       *  Product: '<S62>/Divide2'
       *  Product: '<S64>/Product2'
       *  RelationalOperator: '<S68>/Compare'
       *  Sum: '<S63>/Subtract1'
       */
      PMU_clk_B->Merge2 = (real_T)(rtb_Switch * 1000.0 + 1.0 >= 159.0) *
        ((rtb_Unwrap_kb - PMU_clk_DW->Delay1_DSTATE_l) * 79.57747154594766) +
        60.0;

      /* Switch: '<S64>/Switch2' incorporates:
       *  ComplexToMagnitudeAngle: '<S64>/Complex to Magnitude-Angle1'
       *  ComplexToMagnitudeAngle: '<S64>/Complex to Magnitude-Angle2'
       *  ComplexToRealImag: '<S64>/Complex to Real-Imag1'
       *  ComplexToRealImag: '<S64>/Complex to Real-Imag2'
       *  Constant: '<S62>/i1'
       *  Sum: '<S67>/Sum of Elements'
       *  Switch: '<S64>/Switch1'
       */
      if (PMU_clk_P_e->mode >= 1.0) {
        PMU_clk_B->Merge4[0] = rt_hypotd_snf(rtb_SumofElements_re,
          rtb_SumofElements_im);
        PMU_clk_B->Merge4[1] = rt_hypotd_snf(rtb_SumofElements_re_g,
          rtb_SumofElements_im_d);
        PMU_clk_B->Merge4[2] = rt_hypotd_snf(re, im);
        PMU_clk_B->Merge4[3] = rt_atan2d_snf(rtb_SumofElements_im,
          rtb_SumofElements_re);
        PMU_clk_B->Merge4[4] = rt_atan2d_snf(rtb_SumofElements_im_d,
          rtb_SumofElements_re_g);
        PMU_clk_B->Merge4[5] = rt_atan2d_snf(im, re);
        PMU_clk_B->Merge1[0] = rt_hypotd_snf(rtb_Divide_re, rtb_Divide_im);
        PMU_clk_B->Merge1[1] = rt_atan2d_snf(rtb_Divide_im, rtb_Divide_re);
      } else {
        PMU_clk_B->Merge4[0] = rtb_SumofElements_re;
        PMU_clk_B->Merge4[1] = rtb_SumofElements_re_g;
        PMU_clk_B->Merge4[2] = re;
        PMU_clk_B->Merge4[3] = rtb_SumofElements_im;
        PMU_clk_B->Merge4[4] = rtb_SumofElements_im_d;
        PMU_clk_B->Merge4[5] = im;
        PMU_clk_B->Merge1[0] = rtb_Divide_re;
        PMU_clk_B->Merge1[1] = rtb_Divide_im;
      }

      /* End of Switch: '<S64>/Switch2' */

      /* Product: '<S64>/Product' incorporates:
       *  DataTypeConversion: '<S64>/Data Type Conversion'
       */
      for (i = 0; i < 6; i++) {
        PMU_clk_B->Merge4[i] *= (real_T)rtb_Compare_j0;
      }

      /* End of Product: '<S64>/Product' */

      /* Product: '<S64>/Product1' incorporates:
       *  DataTypeConversion: '<S64>/Data Type Conversion'
       */
      PMU_clk_B->Merge1[0] *= (real_T)rtb_Compare_j0;
      PMU_clk_B->Merge1[1] *= (real_T)rtb_Compare_j0;

      /* Product: '<S64>/Product3' incorporates:
       *  Constant: '<S63>/T'
       *  DataTypeConversion: '<S64>/Data Type Conversion'
       *  Delay: '<S63>/Delay'
       *  Delay: '<S63>/Delay1'
       *  Gain: '<S63>/Gain2'
       *  Product: '<S63>/Divide5'
       *  Sum: '<S63>/Subtract3'
       */
      PMU_clk_B->Merge3 = ((PMU_clk_DW->Delay1_DSTATE_l + rtb_Unwrap_kb) - 2.0 *
                           PMU_clk_DW->Delay_DSTATE_e) / 6.2831853071795858E-6 *
        (real_T)rtb_Compare_j0;

      /* Update for Delay: '<S63>/Delay' */
      PMU_clk_DW->Delay_DSTATE_e = rtb_Unwrap_kb;

      /* Update for Delay: '<S63>/Delay1' */
      PMU_clk_DW->Delay1_DSTATE_l = rtb_tArg2_c;

      /* Update for Delay: '<S64>/Delay' */
      for (i = 0; i < 999; i++) {
        PMU_clk_DW->Delay_DSTATE_g[i] = PMU_clk_DW->Delay_DSTATE_g[i + 1];
      }

      PMU_clk_DW->Delay_DSTATE_g[999] = rtb_Switch;

      /* End of Update for Delay: '<S64>/Delay' */
      /* End of Outputs for SubSystem: '<Root>/PMU_60Hz_M_30' */
      break;

     case 11:
      /* Outputs for IfAction SubSystem: '<Root>/PMU_60Hz_M_60' incorporates:
       *  ActionPort: '<S9>/Action Port'
       */
      /* Product: '<S70>/Divide' */
      rtb_Divide_im = PMU_clk_ConstB.Fcn1_p *
        PMU_clk_ConstB.RealImagtoComplex_f.im * rtb_Switch;

      /* Math: '<S70>/Math Function' incorporates:
       *  Product: '<S70>/Divide'
       *
       * About '<S70>/Math Function':
       *  Operator: exp
       */
      re = exp(PMU_clk_ConstB.Fcn1_p * PMU_clk_ConstB.RealImagtoComplex_f.re *
               rtb_Switch);
      if (rtb_Divide_im == 0.0) {
        rtb_Divide_re = re;
        rtb_Divide_im = 0.0;
      } else {
        rtb_Divide_re = re * cos(rtb_Divide_im);
        rtb_Divide_im = re * sin(rtb_Divide_im);
      }

      /* End of Math: '<S70>/Math Function' */

      /* Product: '<S70>/Divide1' incorporates:
       *  Gain: '<S70>/Gain1'
       */
      PMU_clk_B->Divide1_p[0].re = 1.4142135623730951 *
        PMU_clk_B->RateTransition[0] * rtb_Divide_re;
      PMU_clk_B->Divide1_p[0].im = 1.4142135623730951 *
        PMU_clk_B->RateTransition[0] * rtb_Divide_im;
      PMU_clk_B->Divide1_p[1].re = 1.4142135623730951 *
        PMU_clk_B->RateTransition[1] * rtb_Divide_re;
      PMU_clk_B->Divide1_p[1].im = 1.4142135623730951 *
        PMU_clk_B->RateTransition[1] * rtb_Divide_im;
      PMU_clk_B->Divide1_p[2].re = 1.4142135623730951 *
        PMU_clk_B->RateTransition[2] * rtb_Divide_re;
      PMU_clk_B->Divide1_p[2].im = 1.4142135623730951 *
        PMU_clk_B->RateTransition[2] * rtb_Divide_im;

      /* Buffer: '<S70>/Buffer1' */
      for (i = 0; i < 170 - PMU_clk_DW->Buffer1_CircBufIdx_c; i++) {
        rtb_Product_ns[i] = PMU_clk_DW->Buffer1_CircBuff_e
          [PMU_clk_DW->Buffer1_CircBufIdx_c + i];
      }

      yIdx = 170 - PMU_clk_DW->Buffer1_CircBufIdx_c;
      for (i = 0; i < PMU_clk_DW->Buffer1_CircBufIdx_c; i++) {
        rtb_Product_ns[yIdx + i] = PMU_clk_DW->Buffer1_CircBuff_e[i];
      }

      yIdx += PMU_clk_DW->Buffer1_CircBufIdx_c;
      rtb_Product_ns[yIdx] = PMU_clk_B->Divide1_p[0];
      PMU_clk_DW->Buffer1_CircBuff_e[PMU_clk_DW->Buffer1_CircBufIdx_c] =
        PMU_clk_B->Divide1_p[0];
      PMU_clk_DW->Buffer1_CircBufIdx_c++;
      if (PMU_clk_DW->Buffer1_CircBufIdx_c >= 170) {
        PMU_clk_DW->Buffer1_CircBufIdx_c -= 170;
      }

      /* End of Buffer: '<S70>/Buffer1' */

      /* Sum: '<S72>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 171; i++) {
        /* Product: '<S72>/Product' incorporates:
         *  Constant: '<S72>/i2'
         */
        rtb_Buffer3_c[i].re = PMU_clk_ConstP.pooled25[i] * rtb_Product_ns[i].re;
        rtb_Buffer3_c[i].im = PMU_clk_ConstP.pooled25[i] * rtb_Product_ns[i].im;

        /* Sum: '<S72>/Sum of Elements' incorporates:
         *  Product: '<S72>/Product'
         */
        re += rtb_Buffer3_c[i].re;
        im += rtb_Buffer3_c[i].im;
      }

      /* Sum: '<S72>/Sum of Elements' */
      rtb_SumofElements_re = re;
      rtb_SumofElements_im = im;

      /* Buffer: '<S70>/Buffer2' */
      for (i = 0; i < 170 - PMU_clk_DW->Buffer2_CircBufIdx_l; i++) {
        rtb_Buffer3_c[i] = PMU_clk_DW->Buffer2_CircBuff_p
          [PMU_clk_DW->Buffer2_CircBufIdx_l + i];
      }

      yIdx = 170 - PMU_clk_DW->Buffer2_CircBufIdx_l;
      for (i = 0; i < PMU_clk_DW->Buffer2_CircBufIdx_l; i++) {
        rtb_Buffer3_c[yIdx + i] = PMU_clk_DW->Buffer2_CircBuff_p[i];
      }

      yIdx += PMU_clk_DW->Buffer2_CircBufIdx_l;
      rtb_Buffer3_c[yIdx] = PMU_clk_B->Divide1_p[1];
      PMU_clk_DW->Buffer2_CircBuff_p[PMU_clk_DW->Buffer2_CircBufIdx_l] =
        PMU_clk_B->Divide1_p[1];
      PMU_clk_DW->Buffer2_CircBufIdx_l++;
      if (PMU_clk_DW->Buffer2_CircBufIdx_l >= 170) {
        PMU_clk_DW->Buffer2_CircBufIdx_l -= 170;
      }

      /* End of Buffer: '<S70>/Buffer2' */

      /* Sum: '<S73>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 171; i++) {
        /* Product: '<S73>/Product' incorporates:
         *  Constant: '<S73>/i2'
         */
        rtb_Product_ns[i].re = PMU_clk_ConstP.pooled25[i] * rtb_Buffer3_c[i].re;
        rtb_Product_ns[i].im = PMU_clk_ConstP.pooled25[i] * rtb_Buffer3_c[i].im;

        /* Sum: '<S73>/Sum of Elements' incorporates:
         *  Product: '<S73>/Product'
         */
        re += rtb_Product_ns[i].re;
        im += rtb_Product_ns[i].im;
      }

      /* Sum: '<S73>/Sum of Elements' */
      rtb_SumofElements_re_g = re;
      rtb_SumofElements_im_d = im;

      /* Buffer: '<S70>/Buffer3' */
      for (i = 0; i < 170 - PMU_clk_DW->Buffer3_CircBufIdx_l; i++) {
        rtb_Buffer3_c[i] = PMU_clk_DW->Buffer3_CircBuff_p
          [PMU_clk_DW->Buffer3_CircBufIdx_l + i];
      }

      yIdx = 170 - PMU_clk_DW->Buffer3_CircBufIdx_l;
      for (i = 0; i < PMU_clk_DW->Buffer3_CircBufIdx_l; i++) {
        rtb_Buffer3_c[yIdx + i] = PMU_clk_DW->Buffer3_CircBuff_p[i];
      }

      yIdx += PMU_clk_DW->Buffer3_CircBufIdx_l;
      rtb_Buffer3_c[yIdx] = PMU_clk_B->Divide1_p[2];
      PMU_clk_DW->Buffer3_CircBuff_p[PMU_clk_DW->Buffer3_CircBufIdx_l] =
        PMU_clk_B->Divide1_p[2];
      PMU_clk_DW->Buffer3_CircBufIdx_l++;
      if (PMU_clk_DW->Buffer3_CircBufIdx_l >= 170) {
        PMU_clk_DW->Buffer3_CircBufIdx_l -= 170;
      }

      /* End of Buffer: '<S70>/Buffer3' */

      /* Sum: '<S74>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 171; i++) {
        /* Product: '<S74>/Product' incorporates:
         *  Constant: '<S74>/i2'
         */
        rtb_Product_ns[i].re = PMU_clk_ConstP.pooled25[i] * rtb_Buffer3_c[i].re;
        rtb_Product_ns[i].im = PMU_clk_ConstP.pooled25[i] * rtb_Buffer3_c[i].im;

        /* Sum: '<S74>/Sum of Elements' incorporates:
         *  Product: '<S74>/Product'
         */
        re += rtb_Product_ns[i].re;
        im += rtb_Product_ns[i].im;
      }

      /* Gain: '<S70>/Gain5' incorporates:
       *  Gain: '<S70>/Sequence Gain2'
       *  Gain: '<S70>/Sequence Gain3'
       *  Sum: '<S70>/Add'
       *  Sum: '<S74>/Sum of Elements'
       */
      rtb_Divide_re = (((-0.49999999999999978 * rtb_SumofElements_re_g -
                         0.86602540378443871 * rtb_SumofElements_im_d) +
                        rtb_SumofElements_re) + (-0.50000000000000033 * re -
        -0.86602540378443837 * im)) * 0.33333333333333331;
      rtb_Divide_im = (((-0.49999999999999978 * rtb_SumofElements_im_d +
                         0.86602540378443871 * rtb_SumofElements_re_g) +
                        rtb_SumofElements_im) + (-0.50000000000000033 * im +
        -0.86602540378443837 * re)) * 0.33333333333333331;

      /* ComplexToMagnitudeAngle: '<S70>/Complex to Magnitude-Angle' */
      rtb_tArg1_o = rt_atan2d_snf(rtb_Divide_im, rtb_Divide_re);

      /* Delay: '<S70>/Delay' */
      rtb_tArg2_c = PMU_clk_DW->Delay_DSTATE_b;

      /* S-Function (sdspunwrap2): '<S70>/Unwrap' */
      if (PMU_clk_DW->Unwrap_FirstStep_n) {
        PMU_clk_DW->Unwrap_Prev_i = rtb_tArg1_o;
        PMU_clk_DW->Unwrap_FirstStep_n = false;
      }

      rtb_Unwrap_kb = rtb_tArg1_o - PMU_clk_DW->Unwrap_Prev_i;
      dpShift = rtb_Unwrap_kb - floor((rtb_Unwrap_kb + 3.1415926535897931) /
        6.2831853071795862) * 6.2831853071795862;
      if ((dpShift == -3.1415926535897931) && (rtb_Unwrap_kb > 0.0)) {
        dpShift = 3.1415926535897931;
      }

      rtb_Unwrap_kb = dpShift - rtb_Unwrap_kb;
      if (fabs(rtb_Unwrap_kb) > 3.1415926535897931) {
        PMU_clk_DW->Unwrap_Cumsum_h += rtb_Unwrap_kb;
      }

      rtb_Unwrap_kb = rtb_tArg1_o + PMU_clk_DW->Unwrap_Cumsum_h;
      PMU_clk_DW->Unwrap_Prev_i = rtb_tArg1_o;

      /* End of S-Function (sdspunwrap2): '<S70>/Unwrap' */

      /* ZeroOrderHold: '<S71>/Zero-Order Hold1' incorporates:
       *  Constant: '<S71>/i1'
       *  Delay: '<S71>/Delay'
       */
      PMU_clk_B->Merge5 = PMU_clk_DW->Delay_DSTATE_l[915U];

      /* RelationalOperator: '<S75>/Compare' incorporates:
       *  Bias: '<S69>/Bias'
       *  Constant: '<S69>/i2'
       *  Constant: '<S75>/Constant'
       *  Product: '<S69>/Divide2'
       */
      rtb_Compare_j0 = (rtb_Switch * 1000.0 + 1.0 >= 85.0);

      /* Bias: '<S71>/Bias' incorporates:
       *  Bias: '<S69>/Bias'
       *  Constant: '<S69>/i2'
       *  Constant: '<S75>/Constant'
       *  DataTypeConversion: '<S71>/Data Type Conversion'
       *  Delay: '<S70>/Delay1'
       *  Gain: '<S70>/Gain9'
       *  Product: '<S69>/Divide2'
       *  Product: '<S71>/Product2'
       *  RelationalOperator: '<S75>/Compare'
       *  Sum: '<S70>/Subtract1'
       */
      PMU_clk_B->Merge2 = (real_T)(rtb_Switch * 1000.0 + 1.0 >= 85.0) *
        ((rtb_Unwrap_kb - PMU_clk_DW->Delay1_DSTATE_o) * 79.57747154594766) +
        60.0;

      /* Switch: '<S71>/Switch2' incorporates:
       *  ComplexToMagnitudeAngle: '<S71>/Complex to Magnitude-Angle1'
       *  ComplexToMagnitudeAngle: '<S71>/Complex to Magnitude-Angle2'
       *  ComplexToRealImag: '<S71>/Complex to Real-Imag1'
       *  ComplexToRealImag: '<S71>/Complex to Real-Imag2'
       *  Constant: '<S69>/i1'
       *  Sum: '<S74>/Sum of Elements'
       *  Switch: '<S71>/Switch1'
       */
      if (PMU_clk_P_e->mode >= 1.0) {
        PMU_clk_B->Merge4[0] = rt_hypotd_snf(rtb_SumofElements_re,
          rtb_SumofElements_im);
        PMU_clk_B->Merge4[1] = rt_hypotd_snf(rtb_SumofElements_re_g,
          rtb_SumofElements_im_d);
        PMU_clk_B->Merge4[2] = rt_hypotd_snf(re, im);
        PMU_clk_B->Merge4[3] = rt_atan2d_snf(rtb_SumofElements_im,
          rtb_SumofElements_re);
        PMU_clk_B->Merge4[4] = rt_atan2d_snf(rtb_SumofElements_im_d,
          rtb_SumofElements_re_g);
        PMU_clk_B->Merge4[5] = rt_atan2d_snf(im, re);
        PMU_clk_B->Merge1[0] = rt_hypotd_snf(rtb_Divide_re, rtb_Divide_im);
        PMU_clk_B->Merge1[1] = rt_atan2d_snf(rtb_Divide_im, rtb_Divide_re);
      } else {
        PMU_clk_B->Merge4[0] = rtb_SumofElements_re;
        PMU_clk_B->Merge4[1] = rtb_SumofElements_re_g;
        PMU_clk_B->Merge4[2] = re;
        PMU_clk_B->Merge4[3] = rtb_SumofElements_im;
        PMU_clk_B->Merge4[4] = rtb_SumofElements_im_d;
        PMU_clk_B->Merge4[5] = im;
        PMU_clk_B->Merge1[0] = rtb_Divide_re;
        PMU_clk_B->Merge1[1] = rtb_Divide_im;
      }

      /* End of Switch: '<S71>/Switch2' */

      /* Product: '<S71>/Product' incorporates:
       *  DataTypeConversion: '<S71>/Data Type Conversion'
       */
      for (i = 0; i < 6; i++) {
        PMU_clk_B->Merge4[i] *= (real_T)rtb_Compare_j0;
      }

      /* End of Product: '<S71>/Product' */

      /* Product: '<S71>/Product1' incorporates:
       *  DataTypeConversion: '<S71>/Data Type Conversion'
       */
      PMU_clk_B->Merge1[0] *= (real_T)rtb_Compare_j0;
      PMU_clk_B->Merge1[1] *= (real_T)rtb_Compare_j0;

      /* Product: '<S71>/Product3' incorporates:
       *  Constant: '<S70>/T'
       *  DataTypeConversion: '<S71>/Data Type Conversion'
       *  Delay: '<S70>/Delay'
       *  Delay: '<S70>/Delay1'
       *  Gain: '<S70>/Gain2'
       *  Product: '<S70>/Divide5'
       *  Sum: '<S70>/Subtract3'
       */
      PMU_clk_B->Merge3 = ((PMU_clk_DW->Delay1_DSTATE_o + rtb_Unwrap_kb) - 2.0 *
                           PMU_clk_DW->Delay_DSTATE_b) / 6.2831853071795858E-6 *
        (real_T)rtb_Compare_j0;

      /* Update for Delay: '<S70>/Delay' */
      PMU_clk_DW->Delay_DSTATE_b = rtb_Unwrap_kb;

      /* Update for Delay: '<S70>/Delay1' */
      PMU_clk_DW->Delay1_DSTATE_o = rtb_tArg2_c;

      /* Update for Delay: '<S71>/Delay' */
      for (i = 0; i < 999; i++) {
        PMU_clk_DW->Delay_DSTATE_l[i] = PMU_clk_DW->Delay_DSTATE_l[i + 1];
      }

      PMU_clk_DW->Delay_DSTATE_l[999] = rtb_Switch;

      /* End of Update for Delay: '<S71>/Delay' */
      /* End of Outputs for SubSystem: '<Root>/PMU_60Hz_M_60' */
      break;

     case 12:
      /* Outputs for IfAction SubSystem: '<Root>/PMU_60Hz_M_120' incorporates:
       *  ActionPort: '<S7>/Action Port'
       */
      /* Product: '<S56>/Divide' */
      rtb_Divide_im = PMU_clk_ConstB.Fcn1 * PMU_clk_ConstB.RealImagtoComplex.im *
        rtb_Switch;

      /* Math: '<S56>/Math Function' incorporates:
       *  Product: '<S56>/Divide'
       *
       * About '<S56>/Math Function':
       *  Operator: exp
       */
      re = exp(PMU_clk_ConstB.Fcn1 * PMU_clk_ConstB.RealImagtoComplex.re *
               rtb_Switch);
      if (rtb_Divide_im == 0.0) {
        rtb_Divide_re = re;
        rtb_Divide_im = 0.0;
      } else {
        rtb_Divide_re = re * cos(rtb_Divide_im);
        rtb_Divide_im = re * sin(rtb_Divide_im);
      }

      /* End of Math: '<S56>/Math Function' */

      /* Product: '<S56>/Divide1' incorporates:
       *  Gain: '<S56>/Gain1'
       */
      PMU_clk_B->Divide1[0].re = 1.4142135623730951 * PMU_clk_B->RateTransition
        [0] * rtb_Divide_re;
      PMU_clk_B->Divide1[0].im = 1.4142135623730951 * PMU_clk_B->RateTransition
        [0] * rtb_Divide_im;
      PMU_clk_B->Divide1[1].re = 1.4142135623730951 * PMU_clk_B->RateTransition
        [1] * rtb_Divide_re;
      PMU_clk_B->Divide1[1].im = 1.4142135623730951 * PMU_clk_B->RateTransition
        [1] * rtb_Divide_im;
      PMU_clk_B->Divide1[2].re = 1.4142135623730951 * PMU_clk_B->RateTransition
        [2] * rtb_Divide_re;
      PMU_clk_B->Divide1[2].im = 1.4142135623730951 * PMU_clk_B->RateTransition
        [2] * rtb_Divide_im;

      /* Buffer: '<S56>/Buffer1' */
      for (i = 0; i < 72 - PMU_clk_DW->Buffer1_CircBufIdx; i++) {
        rtb_Product[i] = PMU_clk_DW->Buffer1_CircBuff
          [PMU_clk_DW->Buffer1_CircBufIdx + i];
      }

      yIdx = 72 - PMU_clk_DW->Buffer1_CircBufIdx;
      for (i = 0; i < PMU_clk_DW->Buffer1_CircBufIdx; i++) {
        rtb_Product[yIdx + i] = PMU_clk_DW->Buffer1_CircBuff[i];
      }

      yIdx += PMU_clk_DW->Buffer1_CircBufIdx;
      rtb_Product[yIdx] = PMU_clk_B->Divide1[0];
      PMU_clk_DW->Buffer1_CircBuff[PMU_clk_DW->Buffer1_CircBufIdx] =
        PMU_clk_B->Divide1[0];
      PMU_clk_DW->Buffer1_CircBufIdx++;
      if (PMU_clk_DW->Buffer1_CircBufIdx >= 72) {
        PMU_clk_DW->Buffer1_CircBufIdx -= 72;
      }

      /* End of Buffer: '<S56>/Buffer1' */

      /* Sum: '<S58>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 73; i++) {
        /* Product: '<S58>/Product' incorporates:
         *  Constant: '<S58>/i2'
         */
        rtb_Buffer3[i].re = PMU_clk_ConstP.pooled27[i] * rtb_Product[i].re;
        rtb_Buffer3[i].im = PMU_clk_ConstP.pooled27[i] * rtb_Product[i].im;

        /* Sum: '<S58>/Sum of Elements' incorporates:
         *  Product: '<S58>/Product'
         */
        re += rtb_Buffer3[i].re;
        im += rtb_Buffer3[i].im;
      }

      /* Sum: '<S58>/Sum of Elements' */
      rtb_SumofElements_re = re;
      rtb_SumofElements_im = im;

      /* Buffer: '<S56>/Buffer2' */
      for (i = 0; i < 72 - PMU_clk_DW->Buffer2_CircBufIdx; i++) {
        rtb_Buffer3[i] = PMU_clk_DW->Buffer2_CircBuff
          [PMU_clk_DW->Buffer2_CircBufIdx + i];
      }

      yIdx = 72 - PMU_clk_DW->Buffer2_CircBufIdx;
      for (i = 0; i < PMU_clk_DW->Buffer2_CircBufIdx; i++) {
        rtb_Buffer3[yIdx + i] = PMU_clk_DW->Buffer2_CircBuff[i];
      }

      yIdx += PMU_clk_DW->Buffer2_CircBufIdx;
      rtb_Buffer3[yIdx] = PMU_clk_B->Divide1[1];
      PMU_clk_DW->Buffer2_CircBuff[PMU_clk_DW->Buffer2_CircBufIdx] =
        PMU_clk_B->Divide1[1];
      PMU_clk_DW->Buffer2_CircBufIdx++;
      if (PMU_clk_DW->Buffer2_CircBufIdx >= 72) {
        PMU_clk_DW->Buffer2_CircBufIdx -= 72;
      }

      /* End of Buffer: '<S56>/Buffer2' */

      /* Sum: '<S59>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 73; i++) {
        /* Product: '<S59>/Product' incorporates:
         *  Constant: '<S59>/i2'
         */
        rtb_Product[i].re = PMU_clk_ConstP.pooled27[i] * rtb_Buffer3[i].re;
        rtb_Product[i].im = PMU_clk_ConstP.pooled27[i] * rtb_Buffer3[i].im;

        /* Sum: '<S59>/Sum of Elements' incorporates:
         *  Product: '<S59>/Product'
         */
        re += rtb_Product[i].re;
        im += rtb_Product[i].im;
      }

      /* Sum: '<S59>/Sum of Elements' */
      rtb_SumofElements_re_g = re;
      rtb_SumofElements_im_d = im;

      /* Buffer: '<S56>/Buffer3' */
      for (i = 0; i < 72 - PMU_clk_DW->Buffer3_CircBufIdx; i++) {
        rtb_Buffer3[i] = PMU_clk_DW->Buffer3_CircBuff
          [PMU_clk_DW->Buffer3_CircBufIdx + i];
      }

      yIdx = 72 - PMU_clk_DW->Buffer3_CircBufIdx;
      for (i = 0; i < PMU_clk_DW->Buffer3_CircBufIdx; i++) {
        rtb_Buffer3[yIdx + i] = PMU_clk_DW->Buffer3_CircBuff[i];
      }

      yIdx += PMU_clk_DW->Buffer3_CircBufIdx;
      rtb_Buffer3[yIdx] = PMU_clk_B->Divide1[2];
      PMU_clk_DW->Buffer3_CircBuff[PMU_clk_DW->Buffer3_CircBufIdx] =
        PMU_clk_B->Divide1[2];
      PMU_clk_DW->Buffer3_CircBufIdx++;
      if (PMU_clk_DW->Buffer3_CircBufIdx >= 72) {
        PMU_clk_DW->Buffer3_CircBufIdx -= 72;
      }

      /* End of Buffer: '<S56>/Buffer3' */

      /* Sum: '<S60>/Sum of Elements' */
      re = -0.0;
      im = 0.0;
      for (i = 0; i < 73; i++) {
        /* Product: '<S60>/Product' incorporates:
         *  Constant: '<S60>/i2'
         */
        rtb_Product[i].re = PMU_clk_ConstP.pooled27[i] * rtb_Buffer3[i].re;
        rtb_Product[i].im = PMU_clk_ConstP.pooled27[i] * rtb_Buffer3[i].im;

        /* Sum: '<S60>/Sum of Elements' incorporates:
         *  Product: '<S60>/Product'
         */
        re += rtb_Product[i].re;
        im += rtb_Product[i].im;
      }

      /* Gain: '<S56>/Gain5' incorporates:
       *  Gain: '<S56>/Sequence Gain2'
       *  Gain: '<S56>/Sequence Gain3'
       *  Sum: '<S56>/Add'
       *  Sum: '<S60>/Sum of Elements'
       */
      rtb_Divide_re = (((-0.49999999999999978 * rtb_SumofElements_re_g -
                         0.86602540378443871 * rtb_SumofElements_im_d) +
                        rtb_SumofElements_re) + (-0.50000000000000033 * re -
        -0.86602540378443837 * im)) * 0.33333333333333331;
      rtb_Divide_im = (((-0.49999999999999978 * rtb_SumofElements_im_d +
                         0.86602540378443871 * rtb_SumofElements_re_g) +
                        rtb_SumofElements_im) + (-0.50000000000000033 * im +
        -0.86602540378443837 * re)) * 0.33333333333333331;

      /* ComplexToMagnitudeAngle: '<S56>/Complex to Magnitude-Angle' */
      rtb_tArg1_o = rt_atan2d_snf(rtb_Divide_im, rtb_Divide_re);

      /* Delay: '<S56>/Delay' */
      rtb_tArg2_c = PMU_clk_DW->Delay_DSTATE;

      /* S-Function (sdspunwrap2): '<S56>/Unwrap' */
      if (PMU_clk_DW->Unwrap_FirstStep) {
        PMU_clk_DW->Unwrap_Prev = rtb_tArg1_o;
        PMU_clk_DW->Unwrap_FirstStep = false;
      }

      rtb_Unwrap_kb = rtb_tArg1_o - PMU_clk_DW->Unwrap_Prev;
      dpShift = rtb_Unwrap_kb - floor((rtb_Unwrap_kb + 3.1415926535897931) /
        6.2831853071795862) * 6.2831853071795862;
      if ((dpShift == -3.1415926535897931) && (rtb_Unwrap_kb > 0.0)) {
        dpShift = 3.1415926535897931;
      }

      rtb_Unwrap_kb = dpShift - rtb_Unwrap_kb;
      if (fabs(rtb_Unwrap_kb) > 3.1415926535897931) {
        PMU_clk_DW->Unwrap_Cumsum += rtb_Unwrap_kb;
      }

      rtb_Unwrap_kb = rtb_tArg1_o + PMU_clk_DW->Unwrap_Cumsum;
      PMU_clk_DW->Unwrap_Prev = rtb_tArg1_o;

      /* End of S-Function (sdspunwrap2): '<S56>/Unwrap' */

      /* ZeroOrderHold: '<S57>/Zero-Order Hold1' incorporates:
       *  Constant: '<S57>/i1'
       *  Delay: '<S57>/Delay'
       */
      PMU_clk_B->Merge5 = PMU_clk_DW->Delay_DSTATE_j[964U];

      /* RelationalOperator: '<S61>/Compare' incorporates:
       *  Bias: '<S55>/Bias'
       *  Constant: '<S55>/i2'
       *  Constant: '<S61>/Constant'
       *  Product: '<S55>/Divide2'
       */
      rtb_Compare_j0 = (rtb_Switch * 1000.0 + 1.0 >= 36.0);

      /* Bias: '<S57>/Bias' incorporates:
       *  Bias: '<S55>/Bias'
       *  Constant: '<S55>/i2'
       *  Constant: '<S61>/Constant'
       *  DataTypeConversion: '<S57>/Data Type Conversion'
       *  Delay: '<S56>/Delay1'
       *  Gain: '<S56>/Gain9'
       *  Product: '<S55>/Divide2'
       *  Product: '<S57>/Product2'
       *  RelationalOperator: '<S61>/Compare'
       *  Sum: '<S56>/Subtract1'
       */
      PMU_clk_B->Merge2 = (real_T)(rtb_Switch * 1000.0 + 1.0 >= 36.0) *
        ((rtb_Unwrap_kb - PMU_clk_DW->Delay1_DSTATE) * 79.57747154594766) + 60.0;

      /* Switch: '<S57>/Switch2' incorporates:
       *  ComplexToMagnitudeAngle: '<S57>/Complex to Magnitude-Angle1'
       *  ComplexToMagnitudeAngle: '<S57>/Complex to Magnitude-Angle2'
       *  ComplexToRealImag: '<S57>/Complex to Real-Imag1'
       *  ComplexToRealImag: '<S57>/Complex to Real-Imag2'
       *  Constant: '<S55>/i1'
       *  Sum: '<S60>/Sum of Elements'
       *  Switch: '<S57>/Switch1'
       */
      if (PMU_clk_P_e->mode >= 1.0) {
        PMU_clk_B->Merge4[0] = rt_hypotd_snf(rtb_SumofElements_re,
          rtb_SumofElements_im);
        PMU_clk_B->Merge4[1] = rt_hypotd_snf(rtb_SumofElements_re_g,
          rtb_SumofElements_im_d);
        PMU_clk_B->Merge4[2] = rt_hypotd_snf(re, im);
        PMU_clk_B->Merge4[3] = rt_atan2d_snf(rtb_SumofElements_im,
          rtb_SumofElements_re);
        PMU_clk_B->Merge4[4] = rt_atan2d_snf(rtb_SumofElements_im_d,
          rtb_SumofElements_re_g);
        PMU_clk_B->Merge4[5] = rt_atan2d_snf(im, re);
        PMU_clk_B->Merge1[0] = rt_hypotd_snf(rtb_Divide_re, rtb_Divide_im);
        PMU_clk_B->Merge1[1] = rt_atan2d_snf(rtb_Divide_im, rtb_Divide_re);
      } else {
        PMU_clk_B->Merge4[0] = rtb_SumofElements_re;
        PMU_clk_B->Merge4[1] = rtb_SumofElements_re_g;
        PMU_clk_B->Merge4[2] = re;
        PMU_clk_B->Merge4[3] = rtb_SumofElements_im;
        PMU_clk_B->Merge4[4] = rtb_SumofElements_im_d;
        PMU_clk_B->Merge4[5] = im;
        PMU_clk_B->Merge1[0] = rtb_Divide_re;
        PMU_clk_B->Merge1[1] = rtb_Divide_im;
      }

      /* End of Switch: '<S57>/Switch2' */

      /* Product: '<S57>/Product' incorporates:
       *  DataTypeConversion: '<S57>/Data Type Conversion'
       */
      for (i = 0; i < 6; i++) {
        PMU_clk_B->Merge4[i] *= (real_T)rtb_Compare_j0;
      }

      /* End of Product: '<S57>/Product' */

      /* Product: '<S57>/Product1' incorporates:
       *  DataTypeConversion: '<S57>/Data Type Conversion'
       */
      PMU_clk_B->Merge1[0] *= (real_T)rtb_Compare_j0;
      PMU_clk_B->Merge1[1] *= (real_T)rtb_Compare_j0;

      /* Product: '<S57>/Product3' incorporates:
       *  Constant: '<S56>/T'
       *  DataTypeConversion: '<S57>/Data Type Conversion'
       *  Delay: '<S56>/Delay'
       *  Delay: '<S56>/Delay1'
       *  Gain: '<S56>/Gain2'
       *  Product: '<S56>/Divide5'
       *  Sum: '<S56>/Subtract3'
       */
      PMU_clk_B->Merge3 = ((PMU_clk_DW->Delay1_DSTATE + rtb_Unwrap_kb) - 2.0 *
                           PMU_clk_DW->Delay_DSTATE) / 6.2831853071795858E-6 *
        (real_T)rtb_Compare_j0;

      /* Update for Delay: '<S56>/Delay' */
      PMU_clk_DW->Delay_DSTATE = rtb_Unwrap_kb;

      /* Update for Delay: '<S56>/Delay1' */
      PMU_clk_DW->Delay1_DSTATE = rtb_tArg2_c;

      /* Update for Delay: '<S57>/Delay' */
      for (i = 0; i < 999; i++) {
        PMU_clk_DW->Delay_DSTATE_j[i] = PMU_clk_DW->Delay_DSTATE_j[i + 1];
      }

      PMU_clk_DW->Delay_DSTATE_j[999] = rtb_Switch;

      /* End of Update for Delay: '<S57>/Delay' */
      /* End of Outputs for SubSystem: '<Root>/PMU_60Hz_M_120' */
      break;
    }

    /* End of SwitchCase: '<Root>/Switch Case' */

    /* Outport: '<Root>/PhXabc' */
    for (i = 0; i < 6; i++) {
      PMU_clk_Y->PhXabc[i] = PMU_clk_B->Merge4[i];
    }

    /* End of Outport: '<Root>/PhXabc' */

    /* Outport: '<Root>/PhX1' */
    PMU_clk_Y->PhX1[0] = PMU_clk_B->Merge1[0];
    PMU_clk_Y->PhX1[1] = PMU_clk_B->Merge1[1];

    /* Outport: '<Root>/Freq' */
    PMU_clk_Y->Freq = PMU_clk_B->Merge2;

    /* Outport: '<Root>/ROCOF' */
    PMU_clk_Y->ROCOF = PMU_clk_B->Merge3;

    /* Outport: '<Root>/Timestamp' */
    PMU_clk_Y->Timestamp = PMU_clk_B->Merge5;
  }

  if (PMU_clk_M->Timing.TaskCounters.TID[1] == 0) {
    /* Update absolute timer for sample time: [0.001s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.001, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    PMU_clk_M->Timing.clockTick1++;
    if (!PMU_clk_M->Timing.clockTick1) {
      PMU_clk_M->Timing.clockTickH1++;
    }
  }

  rate_scheduler(PMU_clk_M);
}

/* Model initialize function */
void PMU_clk_initialize(RT_MODEL_PMU_clk_T *const PMU_clk_M)
{
  DW_PMU_clk_T *PMU_clk_DW = ((DW_PMU_clk_T *) PMU_clk_M->dwork);

  /* SystemInitialize for IfAction SubSystem: '<Root>/PMU_50Hz_P_25' */
  PMU_clk_PMU_50Hz_P_25_Init(&PMU_clk_DW->PMU_50Hz_P_25);

  /* End of SystemInitialize for SubSystem: '<Root>/PMU_50Hz_P_25' */

  /* SystemInitialize for IfAction SubSystem: '<Root>/PMU_50Hz_P_50' */
  PMU_clk_PMU_50Hz_P_25_Init(&PMU_clk_DW->PMU_50Hz_P_50);

  /* End of SystemInitialize for SubSystem: '<Root>/PMU_50Hz_P_50' */

  /* SystemInitialize for IfAction SubSystem: '<Root>/PMU_50Hz_P_100' */
  PMU_clk_PMU_50Hz_P_25_Init(&PMU_clk_DW->PMU_50Hz_P_100);

  /* End of SystemInitialize for SubSystem: '<Root>/PMU_50Hz_P_100' */

  /* SystemInitialize for IfAction SubSystem: '<Root>/PMU_50Hz_M_25' */
  /* InitializeConditions for Buffer: '<S21>/Buffer1' */
  PMU_clk_DW->Buffer1_CircBufIdx_c5 = 0;

  /* InitializeConditions for Buffer: '<S21>/Buffer2' */
  PMU_clk_DW->Buffer2_CircBufIdx_o = 0;

  /* InitializeConditions for Buffer: '<S21>/Buffer1' */
  memset(&PMU_clk_DW->Buffer1_CircBuff_j5[0], 0, 352U * sizeof(creal_T));

  /* InitializeConditions for Buffer: '<S21>/Buffer2' incorporates:
   *  Buffer: '<S21>/Buffer1'
   */
  memset(&PMU_clk_DW->Buffer2_CircBuff_k[0], 0, 352U * sizeof(creal_T));

  /* InitializeConditions for Buffer: '<S21>/Buffer3' incorporates:
   *  Buffer: '<S21>/Buffer1'
   */
  memset(&PMU_clk_DW->Buffer3_CircBuff_h[0], 0, 352U * sizeof(creal_T));
  PMU_clk_DW->Buffer3_CircBufIdx_g = 0;

  /* InitializeConditions for Delay: '<S21>/Delay' */
  PMU_clk_DW->Delay_DSTATE_h = 0.0;

  /* InitializeConditions for Delay: '<S21>/Delay1' */
  PMU_clk_DW->Delay1_DSTATE_lc = 0.0;

  /* InitializeConditions for S-Function (sdspunwrap2): '<S21>/Unwrap' */
  PMU_clk_DW->Unwrap_FirstStep_a = true;
  PMU_clk_DW->Unwrap_Cumsum_e = 0.0;

  /* InitializeConditions for Delay: '<S22>/Delay' */
  memset(&PMU_clk_DW->Delay_DSTATE_a[0], 0, 1000U * sizeof(real_T));

  /* End of SystemInitialize for SubSystem: '<Root>/PMU_50Hz_M_25' */

  /* SystemInitialize for IfAction SubSystem: '<Root>/PMU_50Hz_M_50' */
  /* InitializeConditions for Buffer: '<S28>/Buffer1' */
  PMU_clk_DW->Buffer1_CircBufIdx_e = 0;

  /* InitializeConditions for Buffer: '<S28>/Buffer2' */
  PMU_clk_DW->Buffer2_CircBufIdx_e = 0;

  /* InitializeConditions for Buffer: '<S28>/Buffer1' */
  memset(&PMU_clk_DW->Buffer1_CircBuff_m[0], 0, 148U * sizeof(creal_T));

  /* InitializeConditions for Buffer: '<S28>/Buffer2' incorporates:
   *  Buffer: '<S28>/Buffer1'
   */
  memset(&PMU_clk_DW->Buffer2_CircBuff_n[0], 0, 148U * sizeof(creal_T));

  /* InitializeConditions for Buffer: '<S28>/Buffer3' incorporates:
   *  Buffer: '<S28>/Buffer1'
   */
  memset(&PMU_clk_DW->Buffer3_CircBuff_b[0], 0, 148U * sizeof(creal_T));
  PMU_clk_DW->Buffer3_CircBufIdx_fl = 0;

  /* InitializeConditions for Delay: '<S28>/Delay' */
  PMU_clk_DW->Delay_DSTATE_br = 0.0;

  /* InitializeConditions for Delay: '<S28>/Delay1' */
  PMU_clk_DW->Delay1_DSTATE_j = 0.0;

  /* InitializeConditions for S-Function (sdspunwrap2): '<S28>/Unwrap' */
  PMU_clk_DW->Unwrap_FirstStep_j = true;
  PMU_clk_DW->Unwrap_Cumsum_n = 0.0;

  /* InitializeConditions for Delay: '<S29>/Delay' */
  memset(&PMU_clk_DW->Delay_DSTATE_dv[0], 0, 1000U * sizeof(real_T));

  /* End of SystemInitialize for SubSystem: '<Root>/PMU_50Hz_M_50' */

  /* SystemInitialize for IfAction SubSystem: '<Root>/PMU_50Hz_M_100' */
  /* InitializeConditions for Buffer: '<S14>/Buffer1' */
  PMU_clk_DW->Buffer1_CircBufIdx_b = 0;

  /* InitializeConditions for Buffer: '<S14>/Buffer2' */
  PMU_clk_DW->Buffer2_CircBufIdx_i = 0;

  /* InitializeConditions for Buffer: '<S14>/Buffer1' */
  memset(&PMU_clk_DW->Buffer1_CircBuff_j[0], 0, 70U * sizeof(creal_T));

  /* InitializeConditions for Buffer: '<S14>/Buffer2' incorporates:
   *  Buffer: '<S14>/Buffer1'
   */
  memset(&PMU_clk_DW->Buffer2_CircBuff_o[0], 0, 70U * sizeof(creal_T));

  /* InitializeConditions for Buffer: '<S14>/Buffer3' incorporates:
   *  Buffer: '<S14>/Buffer1'
   */
  memset(&PMU_clk_DW->Buffer3_CircBuff_pn[0], 0, 70U * sizeof(creal_T));
  PMU_clk_DW->Buffer3_CircBufIdx_f = 0;

  /* InitializeConditions for Delay: '<S14>/Delay' */
  PMU_clk_DW->Delay_DSTATE_f = 0.0;

  /* InitializeConditions for Delay: '<S14>/Delay1' */
  PMU_clk_DW->Delay1_DSTATE_or = 0.0;

  /* InitializeConditions for S-Function (sdspunwrap2): '<S14>/Unwrap' */
  PMU_clk_DW->Unwrap_FirstStep_m = true;
  PMU_clk_DW->Unwrap_Cumsum_f = 0.0;

  /* InitializeConditions for Delay: '<S15>/Delay' */
  memset(&PMU_clk_DW->Delay_DSTATE_d[0], 0, 1000U * sizeof(real_T));

  /* End of SystemInitialize for SubSystem: '<Root>/PMU_50Hz_M_100' */

  /* SystemInitialize for IfAction SubSystem: '<Root>/PMU_60Hz_P_30' */
  PMU_clk_PMU_60Hz_P_30_Init(&PMU_clk_DW->PMU_60Hz_P_30);

  /* End of SystemInitialize for SubSystem: '<Root>/PMU_60Hz_P_30' */

  /* SystemInitialize for IfAction SubSystem: '<Root>/PMU_60Hz_P_60' */
  PMU_clk_PMU_60Hz_P_30_Init(&PMU_clk_DW->PMU_60Hz_P_60);

  /* End of SystemInitialize for SubSystem: '<Root>/PMU_60Hz_P_60' */

  /* SystemInitialize for IfAction SubSystem: '<Root>/PMU_60Hz_P_120' */
  PMU_clk_PMU_60Hz_P_30_Init(&PMU_clk_DW->PMU_60Hz_P_120);

  /* End of SystemInitialize for SubSystem: '<Root>/PMU_60Hz_P_120' */

  /* SystemInitialize for IfAction SubSystem: '<Root>/PMU_60Hz_M_30' */
  /* InitializeConditions for Buffer: '<S63>/Buffer1' */
  PMU_clk_DW->Buffer1_CircBufIdx_g = 0;

  /* InitializeConditions for Buffer: '<S63>/Buffer2' */
  PMU_clk_DW->Buffer2_CircBufIdx_n = 0;

  /* InitializeConditions for Buffer: '<S63>/Buffer1' */
  memset(&PMU_clk_DW->Buffer1_CircBuff_i[0], 0, 318U * sizeof(creal_T));

  /* InitializeConditions for Buffer: '<S63>/Buffer2' incorporates:
   *  Buffer: '<S63>/Buffer1'
   */
  memset(&PMU_clk_DW->Buffer2_CircBuff_b[0], 0, 318U * sizeof(creal_T));

  /* InitializeConditions for Buffer: '<S63>/Buffer3' incorporates:
   *  Buffer: '<S63>/Buffer1'
   */
  memset(&PMU_clk_DW->Buffer3_CircBuff_g[0], 0, 318U * sizeof(creal_T));
  PMU_clk_DW->Buffer3_CircBufIdx_j = 0;

  /* InitializeConditions for Delay: '<S63>/Delay' */
  PMU_clk_DW->Delay_DSTATE_e = 0.0;

  /* InitializeConditions for Delay: '<S63>/Delay1' */
  PMU_clk_DW->Delay1_DSTATE_l = 0.0;

  /* InitializeConditions for S-Function (sdspunwrap2): '<S63>/Unwrap' */
  PMU_clk_DW->Unwrap_FirstStep_o = true;
  PMU_clk_DW->Unwrap_Cumsum_l = 0.0;

  /* InitializeConditions for Delay: '<S64>/Delay' */
  memset(&PMU_clk_DW->Delay_DSTATE_g[0], 0, 1000U * sizeof(real_T));

  /* End of SystemInitialize for SubSystem: '<Root>/PMU_60Hz_M_30' */

  /* SystemInitialize for IfAction SubSystem: '<Root>/PMU_60Hz_M_60' */
  /* InitializeConditions for Buffer: '<S70>/Buffer1' */
  PMU_clk_DW->Buffer1_CircBufIdx_c = 0;

  /* InitializeConditions for Buffer: '<S70>/Buffer2' */
  PMU_clk_DW->Buffer2_CircBufIdx_l = 0;

  /* InitializeConditions for Buffer: '<S70>/Buffer1' */
  memset(&PMU_clk_DW->Buffer1_CircBuff_e[0], 0, 170U * sizeof(creal_T));

  /* InitializeConditions for Buffer: '<S70>/Buffer2' incorporates:
   *  Buffer: '<S70>/Buffer1'
   */
  memset(&PMU_clk_DW->Buffer2_CircBuff_p[0], 0, 170U * sizeof(creal_T));

  /* InitializeConditions for Buffer: '<S70>/Buffer3' incorporates:
   *  Buffer: '<S70>/Buffer1'
   */
  memset(&PMU_clk_DW->Buffer3_CircBuff_p[0], 0, 170U * sizeof(creal_T));
  PMU_clk_DW->Buffer3_CircBufIdx_l = 0;

  /* InitializeConditions for Delay: '<S70>/Delay' */
  PMU_clk_DW->Delay_DSTATE_b = 0.0;

  /* InitializeConditions for Delay: '<S70>/Delay1' */
  PMU_clk_DW->Delay1_DSTATE_o = 0.0;

  /* InitializeConditions for S-Function (sdspunwrap2): '<S70>/Unwrap' */
  PMU_clk_DW->Unwrap_FirstStep_n = true;
  PMU_clk_DW->Unwrap_Cumsum_h = 0.0;

  /* InitializeConditions for Delay: '<S71>/Delay' */
  memset(&PMU_clk_DW->Delay_DSTATE_l[0], 0, 1000U * sizeof(real_T));

  /* End of SystemInitialize for SubSystem: '<Root>/PMU_60Hz_M_60' */

  /* SystemInitialize for IfAction SubSystem: '<Root>/PMU_60Hz_M_120' */
  /* InitializeConditions for Buffer: '<S56>/Buffer1' */
  PMU_clk_DW->Buffer1_CircBufIdx = 0;

  /* InitializeConditions for Buffer: '<S56>/Buffer2' */
  PMU_clk_DW->Buffer2_CircBufIdx = 0;

  /* InitializeConditions for Buffer: '<S56>/Buffer1' */
  memset(&PMU_clk_DW->Buffer1_CircBuff[0], 0, 72U * sizeof(creal_T));

  /* InitializeConditions for Buffer: '<S56>/Buffer2' incorporates:
   *  Buffer: '<S56>/Buffer1'
   */
  memset(&PMU_clk_DW->Buffer2_CircBuff[0], 0, 72U * sizeof(creal_T));

  /* InitializeConditions for Buffer: '<S56>/Buffer3' incorporates:
   *  Buffer: '<S56>/Buffer1'
   */
  memset(&PMU_clk_DW->Buffer3_CircBuff[0], 0, 72U * sizeof(creal_T));
  PMU_clk_DW->Buffer3_CircBufIdx = 0;

  /* InitializeConditions for Delay: '<S56>/Delay' */
  PMU_clk_DW->Delay_DSTATE = 0.0;

  /* InitializeConditions for Delay: '<S56>/Delay1' */
  PMU_clk_DW->Delay1_DSTATE = 0.0;

  /* InitializeConditions for S-Function (sdspunwrap2): '<S56>/Unwrap' */
  PMU_clk_DW->Unwrap_FirstStep = true;
  PMU_clk_DW->Unwrap_Cumsum = 0.0;

  /* InitializeConditions for Delay: '<S57>/Delay' */
  memset(&PMU_clk_DW->Delay_DSTATE_j[0], 0, 1000U * sizeof(real_T));

  /* End of SystemInitialize for SubSystem: '<Root>/PMU_60Hz_M_120' */
}

/* Model terminate function */
void PMU_clk_terminate(RT_MODEL_PMU_clk_T * PMU_clk_M)
{
  /* model code */
  rt_FREE(PMU_clk_M->blockIO);
  rt_FREE(PMU_clk_M->inputs);
  rt_FREE(PMU_clk_M->outputs);
  if (PMU_clk_M->paramIsMalloced) {
    rt_FREE(PMU_clk_M->defaultParam);
  }

  rt_FREE(PMU_clk_M->dwork);
  rt_FREE(PMU_clk_M);
}

/* Model data allocation function */
RT_MODEL_PMU_clk_T *PMU_clk(void)
{
  RT_MODEL_PMU_clk_T *PMU_clk_M;
  PMU_clk_M = (RT_MODEL_PMU_clk_T *) malloc(sizeof(RT_MODEL_PMU_clk_T));
  if (PMU_clk_M == NULL) {
    return NULL;
  }

  (void) memset((char *)PMU_clk_M, 0,
                sizeof(RT_MODEL_PMU_clk_T));

  /* block I/O */
  {
    B_PMU_clk_T *b = (B_PMU_clk_T *) malloc(sizeof(B_PMU_clk_T));
    rt_VALIDATE_MEMORY(PMU_clk_M,b);
    PMU_clk_M->blockIO = (b);
  }

  /* parameters */
  {
    P_PMU_clk_T *p;
    static int_T pSeen = 0;

    /* only malloc on multiple model instantiation */
    if (pSeen == 1 ) {
      p = (P_PMU_clk_T *) malloc(sizeof(P_PMU_clk_T));
      rt_VALIDATE_MEMORY(PMU_clk_M,p);
      (void) memcpy(p, &PMU_clk_P,
                    sizeof(P_PMU_clk_T));
      PMU_clk_M->paramIsMalloced = (true);
    } else {
      p = &PMU_clk_P;
      PMU_clk_M->paramIsMalloced = (false);
      pSeen = 1;
    }

    PMU_clk_M->defaultParam = (p);
  }

  /* states (dwork) */
  {
    DW_PMU_clk_T *dwork = (DW_PMU_clk_T *) malloc(sizeof(DW_PMU_clk_T));
    rt_VALIDATE_MEMORY(PMU_clk_M,dwork);
    PMU_clk_M->dwork = (dwork);
  }

  /* external inputs */
  {
    ExtU_PMU_clk_T *PMU_clk_U = (ExtU_PMU_clk_T *) malloc(sizeof(ExtU_PMU_clk_T));
    rt_VALIDATE_MEMORY(PMU_clk_M,PMU_clk_U);
    PMU_clk_M->inputs = (((ExtU_PMU_clk_T *) PMU_clk_U));
  }

  /* external outputs */
  {
    ExtY_PMU_clk_T *PMU_clk_Y = (ExtY_PMU_clk_T *) malloc(sizeof(ExtY_PMU_clk_T));
    rt_VALIDATE_MEMORY(PMU_clk_M,PMU_clk_Y);
    PMU_clk_M->outputs = (PMU_clk_Y);
  }

  {
    B_PMU_clk_T *PMU_clk_B = ((B_PMU_clk_T *) PMU_clk_M->blockIO);
    DW_PMU_clk_T *PMU_clk_DW = ((DW_PMU_clk_T *) PMU_clk_M->dwork);
    ExtU_PMU_clk_T *PMU_clk_U = (ExtU_PMU_clk_T *) PMU_clk_M->inputs;
    ExtY_PMU_clk_T *PMU_clk_Y = (ExtY_PMU_clk_T *) PMU_clk_M->outputs;

    /* initialize non-finites */
    rt_InitInfAndNaN(sizeof(real_T));

    /* block I/O */
    (void) memset(((void *) PMU_clk_B), 0,
                  sizeof(B_PMU_clk_T));

    /* states (dwork) */
    (void) memset((void *)PMU_clk_DW, 0,
                  sizeof(DW_PMU_clk_T));

    /* external inputs */
    (void)memset((void *)PMU_clk_U, 0, sizeof(ExtU_PMU_clk_T));

    /* external outputs */
    (void) memset((void *)PMU_clk_Y, 0,
                  sizeof(ExtY_PMU_clk_T));
  }

  return PMU_clk_M;
}
