/*
 * PMU_clk_types.h
 *
 * Third Party Support License -- for use only to support products
 * interfaced to MathWorks software under terms specified in your
 * company's restricted use license agreement.
 *
 * Code generation for model "PMU_clk".
 *
 * Model version              : 1.878
 * Simulink Coder version : 8.13 (R2017b) 24-Jul-2017
 * C source code generated on : Mon Feb  3 11:30:03 2020
 *
 * Target selection: hyperlink_grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->Unspecified (assume 32-bit Generic)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_PMU_clk_types_h_
#define RTW_HEADER_PMU_clk_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Parameters (auto storage) */
typedef struct P_PMU_clk_T_ P_PMU_clk_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_PMU_clk_T RT_MODEL_PMU_clk_T;

#endif                                 /* RTW_HEADER_PMU_clk_types_h_ */
