/*
 * PMU_clk_private.h
 *
 * Third Party Support License -- for use only to support products
 * interfaced to MathWorks software under terms specified in your
 * company's restricted use license agreement.
 *
 * Code generation for model "PMU_clk".
 *
 * Model version              : 1.878
 * Simulink Coder version : 8.13 (R2017b) 24-Jul-2017
 * C source code generated on : Mon Feb  3 11:30:03 2020
 *
 * Target selection: hyperlink_grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->Unspecified (assume 32-bit Generic)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_PMU_clk_private_h_
#define RTW_HEADER_PMU_clk_private_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#include "PMU_clk.h"
#if !defined(rt_VALIDATE_MEMORY)
#define rt_VALIDATE_MEMORY(S, ptr)     if(!(ptr)) {\
 rtmSetErrorStatus(PMU_clk_M, RT_MEMORY_ALLOCATION_ERROR);\
 }
#endif

#if !defined(rt_FREE)
#if !defined(_WIN32)
#define rt_FREE(ptr)                   if((ptr) != (NULL)) {\
 free((ptr));\
 (ptr) = (NULL);\
 }
#else

/* Visual and other windows compilers declare free without const */
#define rt_FREE(ptr)                   if((ptr) != (NULL)) {\
 free((void *)(ptr));\
 (ptr) = (NULL);\
 }
#endif
#endif

static real_T rt_atan2d_snf(real_T u0, real_T u1);
static real_T rt_hypotd_snf(real_T u0, real_T u1);
static uint32_T plook_u32d_binckan(real_T u, const real_T bp[], uint32_T
  maxIndex);
static uint32_T binsearch_u32d(real_T u, const real_T bp[], uint32_T startIndex,
  uint32_T maxIndex);
void PMU_clk_PMU_50Hz_P_25_Init(DW_PMU_50Hz_P_25_PMU_clk_T *localDW);
void PMU_clk_PMU_50Hz_P_25(const real_T rtu_Xabc[3], real_T rtu_Clock, real_T
  rty_PhXabc[6], real_T rty_PhX1[2], real_T *rty_Freq, real_T *rty_ROCOF, real_T
  *rty_Timestamp, B_PMU_50Hz_P_25_PMU_clk_T *localB, const
  ConstB_PMU_50Hz_P_25_PMU_clk_T *localC, DW_PMU_50Hz_P_25_PMU_clk_T *localDW,
  P_PMU_clk_T *PMU_clk_P_e);
void PMU_clk_PMU_60Hz_P_30_Init(DW_PMU_60Hz_P_30_PMU_clk_T *localDW);
void PMU_clk_PMU_60Hz_P_30(const real_T rtu_Xabc[3], real_T rtu_Clock, real_T
  rty_PhXabc[6], real_T rty_PhX1[2], real_T *rty_Freq, real_T *rty_ROCOF, real_T
  *rty_Timestamp, B_PMU_60Hz_P_30_PMU_clk_T *localB, const
  ConstB_PMU_60Hz_P_30_PMU_clk_T *localC, DW_PMU_60Hz_P_30_PMU_clk_T *localDW,
  P_PMU_clk_T *PMU_clk_P_e);

#endif                                 /* RTW_HEADER_PMU_clk_private_h_ */
