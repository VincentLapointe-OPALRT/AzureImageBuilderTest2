/*
 * PMU_clk.h
 *
 * Third Party Support License -- for use only to support products
 * interfaced to MathWorks software under terms specified in your
 * company's restricted use license agreement.
 *
 * Code generation for model "PMU_clk".
 *
 * Model version              : 1.878
 * Simulink Coder version : 8.13 (R2017b) 24-Jul-2017
 * C source code generated on : Mon Feb  3 11:30:03 2020
 *
 * Target selection: hyperlink_grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->Unspecified (assume 32-bit Generic)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_PMU_clk_h_
#define RTW_HEADER_PMU_clk_h_
#include <math.h>
#include <string.h>
#include <stddef.h>
#ifndef PMU_clk_COMMON_INCLUDES_
# define PMU_clk_COMMON_INCLUDES_
#include <stdlib.h>
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* PMU_clk_COMMON_INCLUDES_ */

#include "PMU_clk_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetBlockIO
# define rtmGetBlockIO(rtm)            ((rtm)->blockIO)
#endif

#ifndef rtmSetBlockIO
# define rtmSetBlockIO(rtm, val)       ((rtm)->blockIO = (val))
#endif

#ifndef rtmGetDefaultParam
# define rtmGetDefaultParam(rtm)       ((rtm)->defaultParam)
#endif

#ifndef rtmSetDefaultParam
# define rtmSetDefaultParam(rtm, val)  ((rtm)->defaultParam = (val))
#endif

#ifndef rtmGetParamIsMalloced
# define rtmGetParamIsMalloced(rtm)    ((rtm)->paramIsMalloced)
#endif

#ifndef rtmSetParamIsMalloced
# define rtmSetParamIsMalloced(rtm, val) ((rtm)->paramIsMalloced = (val))
#endif

#ifndef rtmGetRootDWork
# define rtmGetRootDWork(rtm)          ((rtm)->dwork)
#endif

#ifndef rtmSetRootDWork
# define rtmSetRootDWork(rtm, val)     ((rtm)->dwork = (val))
#endif

#ifndef rtmGetU
# define rtmGetU(rtm)                  ((rtm)->inputs)
#endif

#ifndef rtmSetU
# define rtmSetU(rtm, val)             ((rtm)->inputs = (val))
#endif

#ifndef rtmGetY
# define rtmGetY(rtm)                  ((rtm)->outputs)
#endif

#ifndef rtmSetY
# define rtmSetY(rtm, val)             ((rtm)->outputs = (val))
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#define PMU_clk_M_TYPE                 RT_MODEL_PMU_clk_T

/* Block signals for system '<Root>/PMU_50Hz_P_25' */
typedef struct {
  creal_T Divide1[3];                  /* '<S42>/Divide1' */
} B_PMU_50Hz_P_25_PMU_clk_T;

/* Block states (auto storage) for system '<Root>/PMU_50Hz_P_25' */
typedef struct {
  creal_T Buffer1_CircBuff[38];        /* '<S42>/Buffer1' */
  creal_T Buffer2_CircBuff[38];        /* '<S42>/Buffer2' */
  creal_T Buffer3_CircBuff[38];        /* '<S42>/Buffer3' */
  real_T Delay_DSTATE;                 /* '<S42>/Delay' */
  real_T Delay1_DSTATE;                /* '<S42>/Delay1' */
  real_T Delay_DSTATE_p[1000];         /* '<S43>/Delay' */
  real_T Unwrap_Prev;                  /* '<S42>/Unwrap' */
  real_T Unwrap_Cumsum;                /* '<S42>/Unwrap' */
  int32_T Buffer1_CircBufIdx;          /* '<S42>/Buffer1' */
  int32_T Buffer2_CircBufIdx;          /* '<S42>/Buffer2' */
  int32_T Buffer3_CircBufIdx;          /* '<S42>/Buffer3' */
  boolean_T Unwrap_FirstStep;          /* '<S42>/Unwrap' */
} DW_PMU_50Hz_P_25_PMU_clk_T;

/* Block signals for system '<Root>/PMU_60Hz_P_30' */
typedef struct {
  creal_T Divide1[3];                  /* '<S84>/Divide1' */
} B_PMU_60Hz_P_30_PMU_clk_T;

/* Block states (auto storage) for system '<Root>/PMU_60Hz_P_30' */
typedef struct {
  creal_T Buffer1_CircBuff[32];        /* '<S84>/Buffer1' */
  creal_T Buffer2_CircBuff[32];        /* '<S84>/Buffer2' */
  creal_T Buffer3_CircBuff[32];        /* '<S84>/Buffer3' */
  real_T Delay_DSTATE;                 /* '<S84>/Delay' */
  real_T Delay1_DSTATE;                /* '<S84>/Delay1' */
  real_T Delay_DSTATE_f[1000];         /* '<S85>/Delay' */
  real_T Unwrap_Prev;                  /* '<S84>/Unwrap' */
  real_T Unwrap_Cumsum;                /* '<S84>/Unwrap' */
  int32_T Buffer1_CircBufIdx;          /* '<S84>/Buffer1' */
  int32_T Buffer2_CircBufIdx;          /* '<S84>/Buffer2' */
  int32_T Buffer3_CircBufIdx;          /* '<S84>/Buffer3' */
  boolean_T Unwrap_FirstStep;          /* '<S84>/Unwrap' */
} DW_PMU_60Hz_P_30_PMU_clk_T;

/* Block signals (auto storage) */
typedef struct {
  creal_T Buffer3_h[353];              /* '<S21>/Buffer3' */
  creal_T Product_e1[353];             /* '<S25>/Product' */
  creal_T Buffer3_p[319];              /* '<S63>/Buffer3' */
  creal_T Product_i[319];              /* '<S67>/Product' */
  creal_T Divide1[3];                  /* '<S56>/Divide1' */
  creal_T Divide1_p[3];                /* '<S70>/Divide1' */
  creal_T Divide1_l[3];                /* '<S63>/Divide1' */
  creal_T Divide1_a[3];                /* '<S14>/Divide1' */
  creal_T Divide1_c[3];                /* '<S28>/Divide1' */
  creal_T Divide1_f[3];                /* '<S21>/Divide1' */
  real_T RateTransition[3];            /* '<Root>/Rate Transition' */
  real_T Merge4[6];                    /* '<Root>/Merge4' */
  real_T Merge1[2];                    /* '<Root>/Merge1' */
  real_T Merge2;                       /* '<Root>/Merge2' */
  real_T Merge3;                       /* '<Root>/Merge3' */
  real_T Merge5;                       /* '<Root>/Merge5' */
  B_PMU_60Hz_P_30_PMU_clk_T PMU_60Hz_P_120;/* '<Root>/PMU_60Hz_P_120' */
  B_PMU_60Hz_P_30_PMU_clk_T PMU_60Hz_P_60;/* '<Root>/PMU_60Hz_P_60' */
  B_PMU_60Hz_P_30_PMU_clk_T PMU_60Hz_P_30;/* '<Root>/PMU_60Hz_P_30' */
  B_PMU_50Hz_P_25_PMU_clk_T PMU_50Hz_P_100;/* '<Root>/PMU_50Hz_P_100' */
  B_PMU_50Hz_P_25_PMU_clk_T PMU_50Hz_P_50;/* '<Root>/PMU_50Hz_P_50' */
  B_PMU_50Hz_P_25_PMU_clk_T PMU_50Hz_P_25;/* '<Root>/PMU_50Hz_P_25' */
} B_PMU_clk_T;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  creal_T Buffer1_CircBuff[72];        /* '<S56>/Buffer1' */
  creal_T Buffer2_CircBuff[72];        /* '<S56>/Buffer2' */
  creal_T Buffer3_CircBuff[72];        /* '<S56>/Buffer3' */
  creal_T Buffer1_CircBuff_e[170];     /* '<S70>/Buffer1' */
  creal_T Buffer2_CircBuff_p[170];     /* '<S70>/Buffer2' */
  creal_T Buffer3_CircBuff_p[170];     /* '<S70>/Buffer3' */
  creal_T Buffer1_CircBuff_i[318];     /* '<S63>/Buffer1' */
  creal_T Buffer2_CircBuff_b[318];     /* '<S63>/Buffer2' */
  creal_T Buffer3_CircBuff_g[318];     /* '<S63>/Buffer3' */
  creal_T Buffer1_CircBuff_j[70];      /* '<S14>/Buffer1' */
  creal_T Buffer2_CircBuff_o[70];      /* '<S14>/Buffer2' */
  creal_T Buffer3_CircBuff_pn[70];     /* '<S14>/Buffer3' */
  creal_T Buffer1_CircBuff_m[148];     /* '<S28>/Buffer1' */
  creal_T Buffer2_CircBuff_n[148];     /* '<S28>/Buffer2' */
  creal_T Buffer3_CircBuff_b[148];     /* '<S28>/Buffer3' */
  creal_T Buffer1_CircBuff_j5[352];    /* '<S21>/Buffer1' */
  creal_T Buffer2_CircBuff_k[352];     /* '<S21>/Buffer2' */
  creal_T Buffer3_CircBuff_h[352];     /* '<S21>/Buffer3' */
  real_T Delay_DSTATE;                 /* '<S56>/Delay' */
  real_T Delay1_DSTATE;                /* '<S56>/Delay1' */
  real_T Delay_DSTATE_j[1000];         /* '<S57>/Delay' */
  real_T Delay_DSTATE_b;               /* '<S70>/Delay' */
  real_T Delay1_DSTATE_o;              /* '<S70>/Delay1' */
  real_T Delay_DSTATE_l[1000];         /* '<S71>/Delay' */
  real_T Delay_DSTATE_e;               /* '<S63>/Delay' */
  real_T Delay1_DSTATE_l;              /* '<S63>/Delay1' */
  real_T Delay_DSTATE_g[1000];         /* '<S64>/Delay' */
  real_T Delay_DSTATE_f;               /* '<S14>/Delay' */
  real_T Delay1_DSTATE_or;             /* '<S14>/Delay1' */
  real_T Delay_DSTATE_d[1000];         /* '<S15>/Delay' */
  real_T Delay_DSTATE_br;              /* '<S28>/Delay' */
  real_T Delay1_DSTATE_j;              /* '<S28>/Delay1' */
  real_T Delay_DSTATE_dv[1000];        /* '<S29>/Delay' */
  real_T Delay_DSTATE_h;               /* '<S21>/Delay' */
  real_T Delay1_DSTATE_lc;             /* '<S21>/Delay1' */
  real_T Delay_DSTATE_a[1000];         /* '<S22>/Delay' */
  real_T m_bpLambda[3];                /* '<Root>/n-D Lookup Table' */
  real_T Unwrap_Prev;                  /* '<S56>/Unwrap' */
  real_T Unwrap_Cumsum;                /* '<S56>/Unwrap' */
  real_T Unwrap_Prev_i;                /* '<S70>/Unwrap' */
  real_T Unwrap_Cumsum_h;              /* '<S70>/Unwrap' */
  real_T Unwrap_Prev_l;                /* '<S63>/Unwrap' */
  real_T Unwrap_Cumsum_l;              /* '<S63>/Unwrap' */
  real_T Unwrap_Prev_h;                /* '<S14>/Unwrap' */
  real_T Unwrap_Cumsum_f;              /* '<S14>/Unwrap' */
  real_T Unwrap_Prev_n;                /* '<S28>/Unwrap' */
  real_T Unwrap_Cumsum_n;              /* '<S28>/Unwrap' */
  real_T Unwrap_Prev_b;                /* '<S21>/Unwrap' */
  real_T Unwrap_Cumsum_e;              /* '<S21>/Unwrap' */
  int32_T Buffer1_CircBufIdx;          /* '<S56>/Buffer1' */
  int32_T Buffer2_CircBufIdx;          /* '<S56>/Buffer2' */
  int32_T Buffer3_CircBufIdx;          /* '<S56>/Buffer3' */
  int32_T Buffer1_CircBufIdx_c;        /* '<S70>/Buffer1' */
  int32_T Buffer2_CircBufIdx_l;        /* '<S70>/Buffer2' */
  int32_T Buffer3_CircBufIdx_l;        /* '<S70>/Buffer3' */
  int32_T Buffer1_CircBufIdx_g;        /* '<S63>/Buffer1' */
  int32_T Buffer2_CircBufIdx_n;        /* '<S63>/Buffer2' */
  int32_T Buffer3_CircBufIdx_j;        /* '<S63>/Buffer3' */
  int32_T Buffer1_CircBufIdx_b;        /* '<S14>/Buffer1' */
  int32_T Buffer2_CircBufIdx_i;        /* '<S14>/Buffer2' */
  int32_T Buffer3_CircBufIdx_f;        /* '<S14>/Buffer3' */
  int32_T Buffer1_CircBufIdx_e;        /* '<S28>/Buffer1' */
  int32_T Buffer2_CircBufIdx_e;        /* '<S28>/Buffer2' */
  int32_T Buffer3_CircBufIdx_fl;       /* '<S28>/Buffer3' */
  int32_T Buffer1_CircBufIdx_c5;       /* '<S21>/Buffer1' */
  int32_T Buffer2_CircBufIdx_o;        /* '<S21>/Buffer2' */
  int32_T Buffer3_CircBufIdx_g;        /* '<S21>/Buffer3' */
  uint32_T m_bpIndex[3];               /* '<Root>/n-D Lookup Table' */
  boolean_T Unwrap_FirstStep;          /* '<S56>/Unwrap' */
  boolean_T Unwrap_FirstStep_n;        /* '<S70>/Unwrap' */
  boolean_T Unwrap_FirstStep_o;        /* '<S63>/Unwrap' */
  boolean_T Unwrap_FirstStep_m;        /* '<S14>/Unwrap' */
  boolean_T Unwrap_FirstStep_j;        /* '<S28>/Unwrap' */
  boolean_T Unwrap_FirstStep_a;        /* '<S21>/Unwrap' */
  DW_PMU_60Hz_P_30_PMU_clk_T PMU_60Hz_P_120;/* '<Root>/PMU_60Hz_P_120' */
  DW_PMU_60Hz_P_30_PMU_clk_T PMU_60Hz_P_60;/* '<Root>/PMU_60Hz_P_60' */
  DW_PMU_60Hz_P_30_PMU_clk_T PMU_60Hz_P_30;/* '<Root>/PMU_60Hz_P_30' */
  DW_PMU_50Hz_P_25_PMU_clk_T PMU_50Hz_P_100;/* '<Root>/PMU_50Hz_P_100' */
  DW_PMU_50Hz_P_25_PMU_clk_T PMU_50Hz_P_50;/* '<Root>/PMU_50Hz_P_50' */
  DW_PMU_50Hz_P_25_PMU_clk_T PMU_50Hz_P_25;/* '<Root>/PMU_50Hz_P_25' */
} DW_PMU_clk_T;

/* Invariant block signals for system '<Root>/PMU_50Hz_P_25' */
typedef struct {
  const creal_T RealImagtoComplex;     /* '<S42>/Real-Imag to Complex' */
  const real_T Fcn1;                   /* '<S42>/Fcn1' */
} ConstB_PMU_50Hz_P_25_PMU_clk_T;

/* Invariant block signals for system '<Root>/PMU_60Hz_P_30' */
typedef struct {
  const creal_T RealImagtoComplex;     /* '<S84>/Real-Imag to Complex' */
  const real_T Fcn1;                   /* '<S84>/Fcn1' */
} ConstB_PMU_60Hz_P_30_PMU_clk_T;

/* Invariant block signals (auto storage) */
typedef struct {
  const creal_T RealImagtoComplex;     /* '<S56>/Real-Imag to Complex' */
  const creal_T RealImagtoComplex_f;   /* '<S70>/Real-Imag to Complex' */
  const creal_T RealImagtoComplex_c;   /* '<S63>/Real-Imag to Complex' */
  const creal_T RealImagtoComplex_o;   /* '<S14>/Real-Imag to Complex' */
  const creal_T RealImagtoComplex_j;   /* '<S28>/Real-Imag to Complex' */
  const creal_T RealImagtoComplex_h;   /* '<S21>/Real-Imag to Complex' */
  const real_T Fcn1;                   /* '<S56>/Fcn1' */
  const real_T Fcn1_p;                 /* '<S70>/Fcn1' */
  const real_T Fcn1_b;                 /* '<S63>/Fcn1' */
  const real_T Fcn1_i;                 /* '<S14>/Fcn1' */
  const real_T Fcn1_d;                 /* '<S28>/Fcn1' */
  const real_T Fcn1_bp;                /* '<S21>/Fcn1' */
  ConstB_PMU_60Hz_P_30_PMU_clk_T PMU_60Hz_P_120;/* '<Root>/PMU_60Hz_P_120' */
  ConstB_PMU_60Hz_P_30_PMU_clk_T PMU_60Hz_P_60;/* '<Root>/PMU_60Hz_P_60' */
  ConstB_PMU_60Hz_P_30_PMU_clk_T PMU_60Hz_P_30;/* '<Root>/PMU_60Hz_P_30' */
  ConstB_PMU_50Hz_P_25_PMU_clk_T PMU_50Hz_P_100;/* '<Root>/PMU_50Hz_P_100' */
  ConstB_PMU_50Hz_P_25_PMU_clk_T PMU_50Hz_P_50;/* '<Root>/PMU_50Hz_P_50' */
  ConstB_PMU_50Hz_P_25_PMU_clk_T PMU_50Hz_P_25;/* '<Root>/PMU_50Hz_P_25' */
} ConstB_PMU_clk_T;

/* Constant parameters (auto storage) */
typedef struct {
  /* Pooled Parameter (Expression: b)
   * Referenced by:
   *   '<S37>/i2'
   *   '<S38>/i2'
   *   '<S39>/i2'
   *   '<S44>/i2'
   *   '<S45>/i2'
   *   '<S46>/i2'
   *   '<S51>/i2'
   *   '<S52>/i2'
   *   '<S53>/i2'
   */
  real_T pooled1[39];

  /* Pooled Parameter (Expression: b)
   * Referenced by:
   *   '<S23>/i2'
   *   '<S24>/i2'
   *   '<S25>/i2'
   */
  real_T pooled4[353];

  /* Pooled Parameter (Expression: b)
   * Referenced by:
   *   '<S30>/i2'
   *   '<S31>/i2'
   *   '<S32>/i2'
   */
  real_T pooled6[149];

  /* Pooled Parameter (Expression: b)
   * Referenced by:
   *   '<S16>/i2'
   *   '<S17>/i2'
   *   '<S18>/i2'
   */
  real_T pooled10[71];

  /* Pooled Parameter (Expression: b)
   * Referenced by:
   *   '<S79>/i2'
   *   '<S80>/i2'
   *   '<S81>/i2'
   *   '<S86>/i2'
   *   '<S87>/i2'
   *   '<S88>/i2'
   *   '<S93>/i2'
   *   '<S94>/i2'
   *   '<S95>/i2'
   */
  real_T pooled21[33];

  /* Pooled Parameter (Expression: b)
   * Referenced by:
   *   '<S65>/i2'
   *   '<S66>/i2'
   *   '<S67>/i2'
   */
  real_T pooled23[319];

  /* Pooled Parameter (Expression: b)
   * Referenced by:
   *   '<S72>/i2'
   *   '<S73>/i2'
   *   '<S74>/i2'
   */
  real_T pooled25[171];

  /* Pooled Parameter (Expression: b)
   * Referenced by:
   *   '<S58>/i2'
   *   '<S59>/i2'
   *   '<S60>/i2'
   */
  real_T pooled27[73];

  /* Expression: index
   * Referenced by: '<Root>/n-D Lookup Table'
   */
  real_T nDLookupTable_tableData[12];

  /* Expression: [0,1]
   * Referenced by: '<Root>/n-D Lookup Table'
   */
  real_T nDLookupTable_bp01Data[2];

  /* Expression: [0.5,1,2]
   * Referenced by: '<Root>/n-D Lookup Table'
   */
  real_T nDLookupTable_bp02Data[3];

  /* Expression: [50,60]
   * Referenced by: '<Root>/n-D Lookup Table'
   */
  real_T nDLookupTable_bp03Data[2];
} ConstP_PMU_clk_T;

/* External inputs (root inport signals with auto storage) */
typedef struct {
  real_T Xabc[3];                      /* '<Root>/Xabc' */
  real_T Clock;                        /* '<Root>/Clock' */
} ExtU_PMU_clk_T;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  real_T PhXabc[6];                    /* '<Root>/PhXabc' */
  real_T PhX1[2];                      /* '<Root>/PhX1' */
  real_T Freq;                         /* '<Root>/Freq' */
  real_T ROCOF;                        /* '<Root>/ROCOF' */
  real_T Timestamp;                    /* '<Root>/Timestamp' */
} ExtY_PMU_clk_T;

/* Parameters (auto storage) */
struct P_PMU_clk_T_ {
  real_T bMclass;                      /* Variable: bMclass
                                        * Referenced by: '<Root>/Class'
                                        */
  real_T clk_choice;                   /* Variable: clk_choice
                                        * Referenced by: '<Root>/Constant'
                                        */
  real_T mode;                         /* Variable: mode
                                        * Referenced by:
                                        *   '<S13>/i1'
                                        *   '<S20>/i1'
                                        *   '<S27>/i1'
                                        *   '<S34>/i1'
                                        *   '<S41>/i1'
                                        *   '<S48>/i1'
                                        *   '<S55>/i1'
                                        *   '<S62>/i1'
                                        *   '<S69>/i1'
                                        *   '<S76>/i1'
                                        *   '<S83>/i1'
                                        *   '<S90>/i1'
                                        */
  real_T rF0;                          /* Variable: rF0
                                        * Referenced by: '<Root>/Frequency'
                                        */
  real_T z;                            /* Variable: z
                                        * Referenced by: '<Root>/Reporting_rate'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_PMU_clk_T {
  const char_T *errorStatus;
  B_PMU_clk_T *blockIO;
  P_PMU_clk_T *defaultParam;
  ExtU_PMU_clk_T *inputs;
  ExtY_PMU_clk_T *outputs;
  boolean_T paramIsMalloced;
  DW_PMU_clk_T *dwork;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick1;
    uint32_T clockTickH1;
    struct {
      uint8_T TID[2];
    } TaskCounters;
  } Timing;
};

/* External data declarations for dependent source files */
static const char *RT_MEMORY_ALLOCATION_ERROR = "memory allocation error";
extern P_PMU_clk_T PMU_clk_P;          /* parameters */
extern const ConstB_PMU_clk_T PMU_clk_ConstB;/* constant block i/o */

/* Constant parameters (auto storage) */
extern const ConstP_PMU_clk_T PMU_clk_ConstP;

/* Model entry point functions */
extern RT_MODEL_PMU_clk_T *PMU_clk(void);
extern void PMU_clk_initialize(RT_MODEL_PMU_clk_T *const PMU_clk_M);
extern void PMU_clk_step(RT_MODEL_PMU_clk_T *const PMU_clk_M);
extern void PMU_clk_terminate(RT_MODEL_PMU_clk_T * PMU_clk_M);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'PMU_clk'
 * '<S1>'   : 'PMU_clk/PMU_50Hz_M_100'
 * '<S2>'   : 'PMU_clk/PMU_50Hz_M_25'
 * '<S3>'   : 'PMU_clk/PMU_50Hz_M_50'
 * '<S4>'   : 'PMU_clk/PMU_50Hz_P_100'
 * '<S5>'   : 'PMU_clk/PMU_50Hz_P_25'
 * '<S6>'   : 'PMU_clk/PMU_50Hz_P_50'
 * '<S7>'   : 'PMU_clk/PMU_60Hz_M_120'
 * '<S8>'   : 'PMU_clk/PMU_60Hz_M_30'
 * '<S9>'   : 'PMU_clk/PMU_60Hz_M_60'
 * '<S10>'  : 'PMU_clk/PMU_60Hz_P_120'
 * '<S11>'  : 'PMU_clk/PMU_60Hz_P_30'
 * '<S12>'  : 'PMU_clk/PMU_60Hz_P_60'
 * '<S13>'  : 'PMU_clk/PMU_50Hz_M_100/PMU'
 * '<S14>'  : 'PMU_clk/PMU_50Hz_M_100/PMU/Simpmu'
 * '<S15>'  : 'PMU_clk/PMU_50Hz_M_100/PMU/decimate'
 * '<S16>'  : 'PMU_clk/PMU_50Hz_M_100/PMU/Simpmu/digital filter'
 * '<S17>'  : 'PMU_clk/PMU_50Hz_M_100/PMU/Simpmu/digital filter1'
 * '<S18>'  : 'PMU_clk/PMU_50Hz_M_100/PMU/Simpmu/digital filter2'
 * '<S19>'  : 'PMU_clk/PMU_50Hz_M_100/PMU/decimate/Compare To Constant'
 * '<S20>'  : 'PMU_clk/PMU_50Hz_M_25/PMU'
 * '<S21>'  : 'PMU_clk/PMU_50Hz_M_25/PMU/Simpmu'
 * '<S22>'  : 'PMU_clk/PMU_50Hz_M_25/PMU/decimate'
 * '<S23>'  : 'PMU_clk/PMU_50Hz_M_25/PMU/Simpmu/digital filter'
 * '<S24>'  : 'PMU_clk/PMU_50Hz_M_25/PMU/Simpmu/digital filter1'
 * '<S25>'  : 'PMU_clk/PMU_50Hz_M_25/PMU/Simpmu/digital filter2'
 * '<S26>'  : 'PMU_clk/PMU_50Hz_M_25/PMU/decimate/Compare To Constant'
 * '<S27>'  : 'PMU_clk/PMU_50Hz_M_50/PMU'
 * '<S28>'  : 'PMU_clk/PMU_50Hz_M_50/PMU/Simpmu'
 * '<S29>'  : 'PMU_clk/PMU_50Hz_M_50/PMU/decimate'
 * '<S30>'  : 'PMU_clk/PMU_50Hz_M_50/PMU/Simpmu/digital filter'
 * '<S31>'  : 'PMU_clk/PMU_50Hz_M_50/PMU/Simpmu/digital filter1'
 * '<S32>'  : 'PMU_clk/PMU_50Hz_M_50/PMU/Simpmu/digital filter2'
 * '<S33>'  : 'PMU_clk/PMU_50Hz_M_50/PMU/decimate/Compare To Constant'
 * '<S34>'  : 'PMU_clk/PMU_50Hz_P_100/PMU'
 * '<S35>'  : 'PMU_clk/PMU_50Hz_P_100/PMU/Simpmu'
 * '<S36>'  : 'PMU_clk/PMU_50Hz_P_100/PMU/decimate'
 * '<S37>'  : 'PMU_clk/PMU_50Hz_P_100/PMU/Simpmu/digital filter'
 * '<S38>'  : 'PMU_clk/PMU_50Hz_P_100/PMU/Simpmu/digital filter1'
 * '<S39>'  : 'PMU_clk/PMU_50Hz_P_100/PMU/Simpmu/digital filter2'
 * '<S40>'  : 'PMU_clk/PMU_50Hz_P_100/PMU/decimate/Compare To Constant'
 * '<S41>'  : 'PMU_clk/PMU_50Hz_P_25/PMU'
 * '<S42>'  : 'PMU_clk/PMU_50Hz_P_25/PMU/Simpmu'
 * '<S43>'  : 'PMU_clk/PMU_50Hz_P_25/PMU/decimate'
 * '<S44>'  : 'PMU_clk/PMU_50Hz_P_25/PMU/Simpmu/digital filter'
 * '<S45>'  : 'PMU_clk/PMU_50Hz_P_25/PMU/Simpmu/digital filter1'
 * '<S46>'  : 'PMU_clk/PMU_50Hz_P_25/PMU/Simpmu/digital filter2'
 * '<S47>'  : 'PMU_clk/PMU_50Hz_P_25/PMU/decimate/Compare To Constant'
 * '<S48>'  : 'PMU_clk/PMU_50Hz_P_50/PMU'
 * '<S49>'  : 'PMU_clk/PMU_50Hz_P_50/PMU/Simpmu'
 * '<S50>'  : 'PMU_clk/PMU_50Hz_P_50/PMU/decimate'
 * '<S51>'  : 'PMU_clk/PMU_50Hz_P_50/PMU/Simpmu/digital filter'
 * '<S52>'  : 'PMU_clk/PMU_50Hz_P_50/PMU/Simpmu/digital filter1'
 * '<S53>'  : 'PMU_clk/PMU_50Hz_P_50/PMU/Simpmu/digital filter2'
 * '<S54>'  : 'PMU_clk/PMU_50Hz_P_50/PMU/decimate/Compare To Constant'
 * '<S55>'  : 'PMU_clk/PMU_60Hz_M_120/PMU'
 * '<S56>'  : 'PMU_clk/PMU_60Hz_M_120/PMU/Simpmu'
 * '<S57>'  : 'PMU_clk/PMU_60Hz_M_120/PMU/decimate'
 * '<S58>'  : 'PMU_clk/PMU_60Hz_M_120/PMU/Simpmu/digital filter'
 * '<S59>'  : 'PMU_clk/PMU_60Hz_M_120/PMU/Simpmu/digital filter1'
 * '<S60>'  : 'PMU_clk/PMU_60Hz_M_120/PMU/Simpmu/digital filter2'
 * '<S61>'  : 'PMU_clk/PMU_60Hz_M_120/PMU/decimate/Compare To Constant'
 * '<S62>'  : 'PMU_clk/PMU_60Hz_M_30/PMU'
 * '<S63>'  : 'PMU_clk/PMU_60Hz_M_30/PMU/Simpmu'
 * '<S64>'  : 'PMU_clk/PMU_60Hz_M_30/PMU/decimate'
 * '<S65>'  : 'PMU_clk/PMU_60Hz_M_30/PMU/Simpmu/digital filter'
 * '<S66>'  : 'PMU_clk/PMU_60Hz_M_30/PMU/Simpmu/digital filter1'
 * '<S67>'  : 'PMU_clk/PMU_60Hz_M_30/PMU/Simpmu/digital filter2'
 * '<S68>'  : 'PMU_clk/PMU_60Hz_M_30/PMU/decimate/Compare To Constant'
 * '<S69>'  : 'PMU_clk/PMU_60Hz_M_60/PMU'
 * '<S70>'  : 'PMU_clk/PMU_60Hz_M_60/PMU/Simpmu'
 * '<S71>'  : 'PMU_clk/PMU_60Hz_M_60/PMU/decimate'
 * '<S72>'  : 'PMU_clk/PMU_60Hz_M_60/PMU/Simpmu/digital filter'
 * '<S73>'  : 'PMU_clk/PMU_60Hz_M_60/PMU/Simpmu/digital filter1'
 * '<S74>'  : 'PMU_clk/PMU_60Hz_M_60/PMU/Simpmu/digital filter2'
 * '<S75>'  : 'PMU_clk/PMU_60Hz_M_60/PMU/decimate/Compare To Constant'
 * '<S76>'  : 'PMU_clk/PMU_60Hz_P_120/PMU'
 * '<S77>'  : 'PMU_clk/PMU_60Hz_P_120/PMU/Simpmu'
 * '<S78>'  : 'PMU_clk/PMU_60Hz_P_120/PMU/decimate'
 * '<S79>'  : 'PMU_clk/PMU_60Hz_P_120/PMU/Simpmu/digital filter'
 * '<S80>'  : 'PMU_clk/PMU_60Hz_P_120/PMU/Simpmu/digital filter1'
 * '<S81>'  : 'PMU_clk/PMU_60Hz_P_120/PMU/Simpmu/digital filter2'
 * '<S82>'  : 'PMU_clk/PMU_60Hz_P_120/PMU/decimate/Compare To Constant'
 * '<S83>'  : 'PMU_clk/PMU_60Hz_P_30/PMU'
 * '<S84>'  : 'PMU_clk/PMU_60Hz_P_30/PMU/Simpmu'
 * '<S85>'  : 'PMU_clk/PMU_60Hz_P_30/PMU/decimate'
 * '<S86>'  : 'PMU_clk/PMU_60Hz_P_30/PMU/Simpmu/digital filter'
 * '<S87>'  : 'PMU_clk/PMU_60Hz_P_30/PMU/Simpmu/digital filter1'
 * '<S88>'  : 'PMU_clk/PMU_60Hz_P_30/PMU/Simpmu/digital filter2'
 * '<S89>'  : 'PMU_clk/PMU_60Hz_P_30/PMU/decimate/Compare To Constant'
 * '<S90>'  : 'PMU_clk/PMU_60Hz_P_60/PMU'
 * '<S91>'  : 'PMU_clk/PMU_60Hz_P_60/PMU/Simpmu'
 * '<S92>'  : 'PMU_clk/PMU_60Hz_P_60/PMU/decimate'
 * '<S93>'  : 'PMU_clk/PMU_60Hz_P_60/PMU/Simpmu/digital filter'
 * '<S94>'  : 'PMU_clk/PMU_60Hz_P_60/PMU/Simpmu/digital filter1'
 * '<S95>'  : 'PMU_clk/PMU_60Hz_P_60/PMU/Simpmu/digital filter2'
 * '<S96>'  : 'PMU_clk/PMU_60Hz_P_60/PMU/decimate/Compare To Constant'
 */
#endif                                 /* RTW_HEADER_PMU_clk_h_ */
