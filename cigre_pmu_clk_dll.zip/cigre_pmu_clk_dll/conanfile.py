from conans import ConanFile
import os


class PMUClk(ConanFile):
    name = "cigre-pmu-clk"
    major_minor = "1.0"
    settings = "os", "compiler", "build_type", "arch"
    
    default_user = "opal-rt-hypersim"
    default_channel = "stable"

    scm = {
         "type": "git",
         "url": "auto",
         "revision": "auto"
      }

    url = "None"
    license = "None"
    description = "None"
    revision_mode = "scm"
    short_paths = True
    generators = [
        "cmake",
        "cmake_find_package"
    ]

    python_requires = ["conan-baseclasses/[>=7.3 <8.0]@opal-rt-buildsystem/stable"]
    python_requires_extend = "conan-baseclasses.OpalCMakeBase"

    def requirements(self):
        self.requires("common-cigre-interface/[>=6.0]@opal-rt-components/stable")

    def package(self):
        self.copy("*", src=self.get_build_bin_folder(), dst="bin", excludes=("Tests-*"))
        self.copy("*", src="configuration", dst="configuration")
