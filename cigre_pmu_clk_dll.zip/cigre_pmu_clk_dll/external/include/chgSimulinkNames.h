#ifndef CHGSIMULINKNAMES_H
#define CHGSIMULINKNAMES_H

/*  @(#)chgSimulinkNames.h	1.1	 12/08/09
*/ 

/*******************************************************************************
    chgSimulinkNames.h

   Version HyperLink : 7.5
   Release Matlab    : R2017b

   Definitions de nouveaux noms pour certaines fonctions de Matlab
   afin d'empecher de multiples definitions dues aux differentes versions
   Le prefixe "hkR2017b_" est ajoute au nom de chaque fonction de Simulink.

   ATTENTION!!! FICHIER GENERE AUTOMATIQUEMENT PAR:  Bruned Boris

   Date de generation: 09/11/27 - 16:03

   Copyright Hydro-Quebec (2000-2001)
*******************************************************************************/


/*      Nom dans Rtw                       Nom dans HyperLink                 */
/*      ---------------------------------  -----------------------------------*/
#define rt_InitInfAndNaN                   hkR2017b_rt_InitInfAndNaN
#define rtIsInf                            hkR2017b_rtIsInf
#define rtIsInfF                           hkR2017b_rtIsInfF
#define rtIsNaN                            hkR2017b_rtIsNaN
#define rtIsNaNF                           hkR2017b_rtIsNaNF
#define rtGetInf                           hkR2017b_rtGetInf
#define rtGetInfF                          hkR2017b_rtGetInfF
#define rtGetMinusInf                      hkR2017b_rtGetMinusInf
#define rtGetMinusInfF                     hkR2017b_rtGetMinusInfF
#define rtGetNaN                           hkR2017b_rtGetNaN
#define rtGetNaNF                          hkR2017b_rtGetNaNF
#define rt_Lookup                          hkR2017b_rt_Lookup
#define rt_GetLookupIndex                  hkR2017b_rt_GetLookupIndex
#define rt_nonfinite                       hkR2017b_rt_nonfinite
#define rt_ZCFcn                           hkR2017b_rt_ZCFcn
#define rt_BackwardSubstitutionRR_Dbl      hkR2017b_rt_BackwardSubstitutionRR_Dbl
#define rt_ForwardSubstitutionRR_Dbl       hkR2017b_rt_ForwardSubstitutionRR_Dbl
#define rt_lu_real                         hkR2017b_rt_lu_real

#define rtInf                              hkR2017b_rtInf
#define rtInfF                             hkR2017b_rtInfF
#define rtMinusInf                         hkR2017b_rtMinusInf
#define rtMinusInfF                        hkR2017b_rtMinusInfF
#define rtNaN                              hkR2017b_rtNaN
#define rtNaNF                             hkR2017b_rtNaNF



#endif /* CHGSIMULINKNAMES_H */
