#ifndef CHGNAMESDECLARATIONS_H
#define CHGNAMESDECLARATIONS_H

/*  @(#)chgNamesDeclarations.h	1.1	 12/08/09
*/ 

/*******************************************************************************
    chgNamesDeclarations.h

   Version HyperLink : 7.5
   Release Matlab    : R2017b

   Definitions de nouveaux noms pour certaines fonctions de Matlab
   afin d'empecher de multiples definitions dues aux differentes versions
   Le prefixe "hkR2017b_" est ajoute au nom de chaque fonction de Simulink.

   ATTENTION!!! FICHIER GENERE AUTOMATIQUEMENT PAR:  Bruned Boris

   Date de generation: 09/11/27 - 16:03

   Copyright Hydro-Quebec (2000-2001)
*******************************************************************************/

/*
* Need function declaration to prevent implicit function declaration which cause runtime problem. 
* This can be observe when precompiling a simulink model for distribution.
*/
void 		hkR2017b_rt_InitInfAndNaN(size_t);
boolean_T 	hkR2017b_rtIsInf(real_T);
boolean_T 	hkR2017b_rtIsInfF(real32_T);
boolean_T 	hkR2017b_rtIsNaN(real_T);
boolean_T 	hkR2017b_rtIsNaNF(real32_T);
real_T 		hkR2017b_rtGetInf(void);
real32_T 	hkR2017b_rtGetInfF(void);
real_T 		hkR2017b_rtGetMinusInf(void);
real32_T 	hkR2017b_rtGetMinusInfF(void);
real_T 		hkR2017b_rtGetNaN(void);
real32_T 	hkR2017b_rtGetNaNF(void);
real_T 		hkR2017b_rt_Lookup(const real_T *, int_T, real_T, const real_T *);
int_T 		hkR2017b_rt_GetLookupIndex(const real_T *, int_T, real_T);

ZCEventType hkR2017b_rt_ZCFcn(ZCDirection, ZCSigState*, real_T);
void 		hkR2017b_rt_BackwardSubstitutionRR_Dbl(real_T *, const real_T *, real_T *, int_T, int_T, boolean_T);
void 		hkR2017b_rt_ForwardSubstitutionRR_Dbl(real_T *, const real_T *, real_T *, int_T, int_T, const int32_T *, boolean_T);
void 		hkR2017b_rt_lu_real(real_T *, const int_T, int32_T *);


/*
* Not functions
*
* rt_nonfinite
* rtInf      
* rtInfF     
* rtMinusInf 
* rtMinusInfF
* rtNaN      
* rtNaNF
*/

#endif /* CHGNAMESDECLARATIONS_H */
