//-------------------------------------------------------------------------
// Preparation functions for model : cigre_PMU_clk
//
// Generated on : Tue Nov 15 09:27:04 EST 2022
//
// DO NOT EDIT !!!
//
// Hypersim (Ucm) : (c) Hydro-Quebec -- 2018
//-------------------------------------------------------------------------

#include "hyStruct.h"
#include "HyUCMprepData.h"
#include "ucm_cigre_PMU_clk_prep.h"

#ifdef __cplusplus
#  define EXTERN_C_DECLARATION extern "C"
#else
#  define EXTERN_C_DECLARATION
#endif // __cplusplus

#ifdef UCM_TEST_COMPILATION
# line 373 "../ucm_cigre_PMU_clk.def"
#endif /* UCM_TEST_COMPILATION */
/* 8.3.1.1 -- User includes */

/* 8.3.1.2 -- Definitions */

/* 8.3.1.3 -- Declarations */

/* 8.3.1.4 -- Local functions (static) */

// Preparation Function

EXTERN_C_DECLARATION void ucm_cigre_PMU_clk_prep(HyUCMprepData *prepData)
{

    // Begin User code >>>>>>>>>>>>>>>>

#ifdef UCM_TEST_COMPILATION
# line 391 "../ucm_cigre_PMU_clk.def"
#endif /* UCM_TEST_COMPILATION */
    // <<<<<<<<<<<<< End of User Code

}

//End of File
