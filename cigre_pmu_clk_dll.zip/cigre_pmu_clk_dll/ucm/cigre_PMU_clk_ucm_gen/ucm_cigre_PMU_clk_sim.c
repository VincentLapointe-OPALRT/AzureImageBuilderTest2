/*-------------------------------------------------------------------------
 * Simulation functions for model : cigre_PMU_clk
 *
 * Generated on : Tue Nov 15 09:27:04 EST 2022
 *
 * DO NOT EDIT !!!
 *
 * Hypersim (Ucm) : (c) Hydro-Quebec -- 2018
 *-------------------------------------------------------------------------
 */

#include "HyUCMsimData.h"
#include "ucm_cigre_PMU_clk_sim.h"

#ifdef UCM_TEST_COMPILATION
# line 508 "../ucm_cigre_PMU_clk.def"
#endif /* UCM_TEST_COMPILATION */
/* 9.3.1 -- User includes */
#define PRECISION 1e-15
#if defined(__cplusplus) && defined(_WIN32)
extern "C" {
#endif
#include "chgSimulinkNames.h"
#if defined(__cplusplus) && defined(_WIN32)
}
#endif

#include <string.h>
#include <float.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#if defined(_WIN32)
#   include <Libloaderapi.h>
#else
#   include <dlfcn.h>
#endif

#include "IEEE_Cigre_DLLInterface.h"
#include "RtOpalStruct.h"

/* 9.3.3 -- Declarations */
#if defined(_WIN32)
HMODULE lib = NULL;
#else
void* lib = NULL;
#endif

//Model_GetInfo getInfoFunc = NULL; // Not used until generic way of loading CIGRE
Model_Initialize modelInitialize = NULL;
Model_Outputs modelOutputs = NULL;
Model_Terminate modelTerminate = NULL;

RtOpalModelStruct rtOpalModelStruct;
RtOpalStruct rtOpalStruct;
InstanceExtSimEnvCapi simEnv;

#define INPUT_COUNT 4
#define OUTPUT_COUNT 11
#define PARAM_COUNT 5

double inputs[INPUT_COUNT] = { 0.0 };
double outputs[OUTPUT_COUNT] = { 0.0 };
double parameters[PARAM_COUNT] = { 0.0 };

/* 9.3.4 -- Local functions (static) */

/* Simulation Initialization Function */

void ucm_cigre_PMU_clk_init(HyUCMsimData *simData)
{

    /* Begin User code >>>>>>>>>>>>>>>> */

#ifdef UCM_TEST_COMPILATION
# line 568 "../ucm_cigre_PMU_clk.def"
#endif /* UCM_TEST_COMPILATION */


#if defined(_WIN32)
    const char* dllName = "C:/OPAL-RT/HYPERSIM/hyconfig/cigre-pmu-clk/windows/CigrePMUClk.dll";
    lib = LoadLibraryA(dllName);
#   define GET_LIB_FUNC_ADDR GetProcAddress
#else
    const char* dllName = "/export/local/ssr/hyconfig/cigre-pmu-clk/linux/CigrePMUClk.so";
    lib = (void*) dlopen(dllName, RTLD_LAZY | RTLD_NODELETE);
#   define GET_LIB_FUNC_ADDR dlsym
#endif

    if (lib != NULL) { 
        printf("Succesfully loaded %s\n", dllName);

        //getInfoFunc = (Model_GetInfo) GET_LIB_FUNC_ADDR(lib, "Model_GetInfo"); // Not used until generic way of loading CIGRE
        modelInitialize = (Model_Initialize) GET_LIB_FUNC_ADDR(lib, "Model_Initialize");
        modelOutputs = (Model_Outputs) GET_LIB_FUNC_ADDR(lib, "Model_Outputs");
        modelTerminate = (Model_Terminate) GET_LIB_FUNC_ADDR(lib, "Model_Terminate");

        if (NULL == modelInitialize || NULL == modelOutputs) {
            printf("ERROR: required functions not found in CIGRE library! You may run into a disaster!");
        }

        if (modelInitialize != NULL) {
            rtoInitialize(rtOpalStruct);
            rtoSetTimeStep(rtOpalStruct, ucmTimeStep);
            rtoModelInitialize(rtOpalModelStruct, rtOpalStruct, ucmTimeStep);
            ESEExtension eseExtension;
            // set the RtOpalStruct that will used to pass the time
            eseExtension.UserVoidPtr = (void*)(&rtOpalModelStruct);

            inputs[0] = Xabc_0;
            inputs[1] = Xabc_1;
            inputs[2] = Xabc_2;
            inputs[3] = Clock_i;
            parameters[0] = bMclass_param;
            parameters[1] = clk_choice_param;
            parameters[2] = mode_param;
            parameters[3] = rF0_param;
            parameters[4] = z_param;

            simEnv.ExternalInputs = &inputs[0];
            simEnv.ExternalOutputs = &outputs[0];
            simEnv.Parameters = &parameters[0];
            simEnv.ContinuousStates = NULL;
            simEnv.StateDerivatives = NULL;
            simEnv.MiscStates = NULL;
            simEnv.LastErrorMessage = NULL;
            simEnv.LastGeneralMessage = NULL;
            simEnv.VerboseLevel = 0;
            simEnv.IntStates = NULL;
            simEnv.FloatStates = NULL;
            simEnv.DoubleStates = NULL;
            simEnv.Extension = eseExtension;

            // Initialize the library
            modelInitialize(&simEnv);
        }
    }
    else {
        printf("ERROR: Failed to load %s\n", dllName);
    }

    /* <<<<<<<<<<<<<<< End of User Code */
}


/* Before voltages calculation simulation function */

void ucm_cigre_PMU_clk_preVNode(HyUCMsimData *simData)
{

    /* Begin User code >>>>>>>>>>>>>>>> */

#ifdef UCM_TEST_COMPILATION
# line 640 "../ucm_cigre_PMU_clk.def"
#endif /* UCM_TEST_COMPILATION */
    /* <<<<<<<<<<<<<<< End of User Code */
}


/* After voltages calculation simulation function */

void ucm_cigre_PMU_clk_postVNode(HyUCMsimData *simData)
{

    /* Begin User code >>>>>>>>>>>>>>>> */

#ifdef UCM_TEST_COMPILATION
# line 648 "../ucm_cigre_PMU_clk.def"
#endif /* UCM_TEST_COMPILATION */

inputs[0] = Xabc_0;
inputs[1] = Xabc_1;
inputs[2] = Xabc_2;
inputs[3] = Clock_i;
parameters[0] = bMclass_param;
parameters[1] = clk_choice_param;
parameters[2] = mode_param;
parameters[3] = rF0_param;
parameters[4] = z_param;

if (modelOutputs != NULL) {
    modelOutputs(&simEnv, 0);
}


PhXabc_0 = simEnv.ExternalOutputs[0];
PhXabc_1 = simEnv.ExternalOutputs[1];
PhXabc_2 = simEnv.ExternalOutputs[2];
PhXabc_3 = simEnv.ExternalOutputs[3];
PhXabc_4 = simEnv.ExternalOutputs[4];
PhXabc_5 = simEnv.ExternalOutputs[5];
PhX1_0 = simEnv.ExternalOutputs[6];
PhX1_1 = simEnv.ExternalOutputs[7];
Freq_o = simEnv.ExternalOutputs[8];
ROCOF_o = simEnv.ExternalOutputs[9];
Timestamp_o = simEnv.ExternalOutputs[10];

rtoIncrementSimulationTime(rtOpalStruct);
rtoUpdateModelSimulationTime(rtOpalModelStruct);

    /* <<<<<<<<<<<<<<< End of User Code */
}


/* Simulation Finalization Function */

void ucm_cigre_PMU_clk_terminate(HyUCMsimData *simData)
{

    /* Begin User code >>>>>>>>>>>>>>>> */

#ifdef UCM_TEST_COMPILATION
# line 734 "../ucm_cigre_PMU_clk.def"
#endif /* UCM_TEST_COMPILATION */
if (modelTerminate != NULL) {
    modelTerminate(&simEnv);
}
if (NULL != lib) {
#if defined(_WIN32)
    FreeLibrary(lib);
#else
    dlclose(lib);
#endif
    lib = NULL;
}

    /* <<<<<<<<<<<<<<< End of User Code */
}


/* End of file */

