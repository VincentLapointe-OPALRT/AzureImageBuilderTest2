#ifndef UCM_cigre_PMU_clk_SIMFCNDECL_H
#define UCM_cigre_PMU_clk_SIMFCNDECL_H
/*
 * Simulation functions declarations file for model : cigre_PMU_clk
 *
 * Generated on : Tue Nov 15 09:27:04 EST 2022
 *
 * DO NOT EDIT !!!
 *
 * Hypersim (Ucm) : (c) Hydro-Quebec -- 2018
 */

void ucm_cigre_PMU_clk_init(HyUCMsimData *simData);
void ucm_cigre_PMU_clk_preVNode(HyUCMsimData *simData);
void ucm_cigre_PMU_clk_preVNodeIter(HyUCMsimData *simData);
void ucm_cigre_PMU_clk_postVNode(HyUCMsimData *simData);
int ucm_cigre_PMU_clk_postVNodeIter(HyUCMsimData *simData);
void ucm_cigre_PMU_clk_terminate(HyUCMsimData *simData);

#endif
