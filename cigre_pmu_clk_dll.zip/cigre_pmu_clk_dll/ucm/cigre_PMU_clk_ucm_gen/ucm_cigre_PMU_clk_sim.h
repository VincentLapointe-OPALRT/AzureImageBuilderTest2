#ifndef UCM_cigre_PMU_clk_SIM_H
#define UCM_cigre_PMU_clk_SIM_H
/*
 * Simulation functions include file for model : cigre_PMU_clk
 *
 * Generated on : Tue Nov 15 09:27:04 EST 2022
 *
 * DO NOT EDIT !!!
 *
 * Hypersim (Ucm) : (c) Hydro-Quebec -- 2018
 */

/* Utilites */

#include "ucm_cigre_PMU_clk_simFcnDecl.h"

#define ucmNodePoste (&(simData->ParI[simData->indNoNodePoste]))
#define ucmVNode(noNode) (*(simData->AdrSigF[simData->indVNode+ucmNodePoste[noNode]]))
#define ucmIndSimPar  (&(simData->ParI[simData->indIndSimPar]))
#define ucmIndHist    (&(simData->ParI[simData->indIndHist]))
#define ucmYadd(i,j)  (simData->ParF[simData->indYadd + simData->nNode*(i)+(j)])
#define ucmTimeStep   (simData->timeStep)
#define ucmId         (simData->id)
#define ucmName       (simData->modelName)
#define ucmInitData   (simData->modelInitData)
#define ucmNoSP       (simData->noSP)
#define ucmNodeChanged(noNode) (simData->ParI[simData->indNodeNlinChg + (noNode)])


/* Form Parameters  */

#define bMclass_param (simData->ParF[ucmIndSimPar[0]])
#define clk_choice_param (simData->ParF[ucmIndSimPar[1]])
#define mode_param (simData->ParF[ucmIndSimPar[2]])
#define rF0_param (simData->ParF[ucmIndSimPar[3]])
#define z_param (simData->ParF[ucmIndSimPar[4]])

/* User signals (control IOs)  */

#define Xabc_0 (*(simData->AdrSigF[simData->indSigF+(0)]))
#define Xabc_1 (*(simData->AdrSigF[simData->indSigF+(1)]))
#define Xabc_2 (*(simData->AdrSigF[simData->indSigF+(2)]))
#define Clock_i (*(simData->AdrSigF[simData->indSigF+(3)]))
#define PhXabc_0 (*(simData->AdrSigF[simData->indSigF+(4)]))
#define PhXabc_1 (*(simData->AdrSigF[simData->indSigF+(5)]))
#define PhXabc_2 (*(simData->AdrSigF[simData->indSigF+(6)]))
#define PhXabc_3 (*(simData->AdrSigF[simData->indSigF+(7)]))
#define PhXabc_4 (*(simData->AdrSigF[simData->indSigF+(8)]))
#define PhXabc_5 (*(simData->AdrSigF[simData->indSigF+(9)]))
#define PhX1_0 (*(simData->AdrSigF[simData->indSigF+(10)]))
#define PhX1_1 (*(simData->AdrSigF[simData->indSigF+(11)]))
#define Freq_o (*(simData->AdrSigF[simData->indSigF+(12)]))
#define ROCOF_o (*(simData->AdrSigF[simData->indSigF+(13)]))
#define Timestamp_o (*(simData->AdrSigF[simData->indSigF+(14)]))

/* Nodes  */


/* Current sources */


/* Historical Currents */


/* Calculated parameters */


/* Historical values */


#endif
