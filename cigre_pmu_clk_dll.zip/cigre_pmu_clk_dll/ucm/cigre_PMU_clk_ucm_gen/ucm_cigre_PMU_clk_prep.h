#ifndef UCM_cigre_PMU_clk_PREP_H
#define UCM_cigre_PMU_clk_PREP_H
/*
 * Preparation functions include file for model : cigre_PMU_clk
 *
 * Generated on : Tue Nov 15 09:27:04 EST 2022
 *
 * DO NOT EDIT !!!
 *
 * Hypersim (Ucm) : (c) Hydro-Quebec -- 2018
 */

/* Utilites */

#define ucmYini(i,j)  (prepData->Yini[(i)*prepData->nNode + (j)])
#define ucmYfill(i,j) (prepData->Yfill[(i)*prepData ->nNode + (j)])
#define ucmTimeStep   (prepData->timeStep)

#define ucmBlockFullName   (prepData->fullname)

#define ucmYlfReal(i,j) (prepData->YlfReal[(i)*prepData ->nNode + (j)])
#define ucmYlfImag(i,j) (prepData->YlfImag[(i)*prepData ->nNode + (j)])
#define ucmIlfHist(i) (prepData->IlfHist[(i)])
#define ucmIlfActual(i) (prepData->IlfActual[(i)])
#define ucmVlfHist(i) (prepData->VlfHist[(i)])
#define ucmVlfActual(i) (prepData->VlfActual[(i)])
#define ucmVintReal(i) (prepData->VintReal[(i)])
#define ucmVintImag(i) (prepData->VintImag[(i)])

/* Form Parameters  */

#define bMclass_param (*(double*)(prepData->simParStr[0].value))
#define clk_choice_param (*(double*)(prepData->simParStr[1].value))
#define mode_param (*(double*)(prepData->simParStr[2].value))
#define rF0_param (*(double*)(prepData->simParStr[3].value))
#define z_param (*(double*)(prepData->simParStr[4].value))

/* Nodes  */


/* Calculated parameters */


#ifdef __cplusplus
extern "C" {
#endif
void ucm_cigre_PMU_clk_prep(HyUCMprepData *prepData);
#ifdef __cplusplus
}
#endif

#endif
