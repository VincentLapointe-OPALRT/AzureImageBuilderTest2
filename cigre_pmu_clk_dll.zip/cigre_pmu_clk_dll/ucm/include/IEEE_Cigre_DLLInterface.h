/* 
File: IEEE_Cigre_DLLInterface.h

This is C header file for power system models written according to the IEEE/Cigre DLL Modeling Standard.

The IEEE/Cigre DLL standard is based highly on the IEC 61400-27-1 DLL standard
(with minor changes to allow complete automation of connecting signals within 
transient stability programs).

A model written according to the DLL standard, can then  be used in ANY power system
simulation program by running the "DLLImport" tool that comes with each program.

*/
#ifndef __IEEE_Cigre_DLLInterface__
#define __IEEE_Cigre_DLLInterface__

/* Use standard data types */
#include "IEEE_Cigre_DLLInterface_types.h"

#ifndef DLLEXPORT
    #ifdef _WIN32
        #define DLLEXPORT __declspec(dllexport)
    #else
        #define DLLEXPORT
    #endif
#endif

#ifndef FUNCALLTYPE
	#ifdef _WIN32
		#define FUNCALLTYPE __cdecl
	#else
		#define FUNCALLTYPE
	#endif
#endif



/* Static input, output information; vectorized signals are allowed */
typedef struct _StaticESEInputSignal
{
   const char_T * const   Name;         // Input signal name
   const char_T * const   BlockPath;    // Path to block in Simulink model
   const int32_T          Width;        // Signal array dimension
   const char_T * const   Unit;         // Units

// Additional Input data needed to automatically create interface to TS Programs

   const int32_T          InputType;    // Vector of Integer Types (see full list)
// ----------------------------------------------------------------------------------
// InputType                                                            PSS/E Symbol
// ---------                                                            -------------
//  0 = NoSignalTypeDefined                                             -

// --------------------------------------------------------------------
// ----------------------MACHINE MODELS-------------------------------- USRMDL(+USRBUS variables)
// --------------------------------------------------------------------
//  1 = Machine Voltage Mag(pu)                                         ETERM
//  2 = Machine Angle(Deg)                                              ANGLE
//  3 = Machine Electrical P(pu on Machine MVA Base)                    PELEC(but need to convert to MBase, not SBase)
//  4 = Machine Electrical Q(pu on Machine MVA Base)                    QELEC(but need to convert to MBase, not SBase)
//  5 = Machine Mechanical Power (pu on Machine MVABase)                PMECH
//  6 = Machine Speed(pu)                                               SPEED(but need to convert from speed deviation to Speed in pu)
//  7 = Machine Field Voltage(pu)                                       EFD
//  8 = Machine Field Current(pu)                                       XADIFD
//  9 = Machine Real Current(pu on Machine Base)                        computed from GENTMC
// 10 = Machine Imaginary Current(pu on Machine Base)                   computed from GENTMC
// 11 = Machine Apparant Impedance Real(pu on Machine Base)             computed from GENTMZ
// 12 = Machine Apparant Impedance Imag(pu on Machine Base)             computed from GENTMZ
    
// 20 = Exciter VoltRef(pu)                                             VREF
// 21 = Exciter VCompensation(pu)                                       ECOMP
// 22 = Exciter StabilizerSignal(pu)                                    VOTHSG
// 23 = Exciter VUEL(pu)                                                VUEL 
// 24 = Exciter VOEL(pu)                                                VOEL

// 30 = Governor SpeedRef(pu)                                           GREF
// 31 = Governor Turbine Load Control Reference                         LCREF        
    
// --------------------------------------------------------------------
// ----------------------BUS MODELS------------------------------------ USRBUS
// --------------------------------------------------------------------
// 40 = Bus 1 Frequency(pu)                                               BSFREQ(but need to convert from speed deviation to Speed in pu)
// 41 = Bus 1 Voltage Mag(pu)                                             ABS(VOLT)
// 42 = Bus 1 Voltage Angle(Deg)                                          computed from VOLT
// 43 = Bus 1 Current Injection Real (pu on System MVA Base)              REAL(CURNT)
// 44 = Bus 1 Current Injection Imaginary (deg)                           IMAG(CURNT)

// for 2 bus, 3 bus models (or HVDC models) only:
// 240 = Bus 2 Frequency(pu)                                               BSFREQ(but need to convert from speed deviation to Speed in pu)
// 241 = Bus 2 Voltage Mag(pu)                                             ABS(VOLT)
// 242 = Bus 2 Voltage Angle(Deg)                                          computed from VOLT
// 243 = Bus 2 Current Injection Real (pu on System MVA Base)              REAL(CURNT)
// 244 = Bus 2 Current Injection Imaginary (deg)                           IMAG(CURNT)

// for 3 bus models only:
// 340 = Bus 3 Frequency(pu)                                               BSFREQ(but need to convert from speed deviation to Speed in pu)
// 341 = Bus 3 Voltage Mag(pu)                                             ABS(VOLT)
// 342 = Bus 3 Voltage Angle(Deg)                                          computed from VOLT
// 343 = Bus 3 Current Injection Real (pu on System MVA Base)              REAL(CURNT)
// 344 = Bus 3 Current Injection Imaginary (deg)                           IMAG(CURNT)

// and higher for multi-terminal HVDC?

// --------------------------------------------------------------------
// ----------------------2 BUS/BRANCH,TRANSFORMER,RELAY MODELS--------- USRBRN,USR2WT,USRREL(+USRBUS variables of first bus)
// --------------------------------------------------------------------
// 50 = Branch P Flow(MW   leaving bus1, including any line shunts)     P from FLOW1 function
// 51 = Branch Q Flow(MVAR leaving bus1, including any line shunts)     Q from FLOW1 function
// 52 = Branch S Flow(MVA  leaving bus1, including any line shunts)     MVA from FLOW1 function
// 53 = Branch Apparent R (pu on System MVA Base)                       computed from RELAY2
// 54 = Branch Apparent X (pu on System MVA Base)                       computed from RELAY2

// --------------------------------------------------------------------
// ----------------------3 BUS/TRANSFORMER MODELS---------------------- USR3WT(+USRBUS variables of first bus)
// --------------------------------------------------------------------
// 60 = Three WindingTransformer P Flow(MW   leaving bus1)              P from FLOW3 function
// 61 = Three WindingTransformer Q Flow(MVAR leaving bus1)              Q from FLOW3 function
// 62 = Three WindingTransformer S Flow(MVA  leaving bus1)              MVA from FLOW3 function

// --------------------------------------------------------------------
// ----------------------1 BUS/LOAD MODELS----------------------------- USRLOD(+USRBUS variables)
// --------------------------------------------------------------------
// 70 = Load Real Power(pu on System MVA Base)                          TPLOAD
// 71 = Load Imag Power(pu on System MVA Base)                          TQLOAD

// --------------------------------------------------------------------
// ----------------------1 BUS/SWITCHED SHUNT MODELS------------------- USRSWS(+USRBUS variables)
// --------------------------------------------------------------------
// 80 = Switched Shunt Voltage Reference (pu)                           SWSREF

// --------------------------------------------------------------------
// ----------------------GENERAL INDEX MODELS-------------------------- Accessible for USRMSC and all Model Types
// --------------------------------------------------------------------
// 90 = General Variable                                                VAR
// 91 = State Variable                                                  STATE
// 92 = Deriviative State Variable                                      DSTATE
// 93 = General State Variable Memory                                   STORE

// --------------------------------------------------------------------
// ----------------------POWER ELECTRONIC MODELS----------------------- USRMDL(+USRBUS variables)
// --------------------------------------------------------------------
// 100 = PE Velocity (meters/sec)                                       WVLCTY
// 101 = PE Generator Speed (pu)                                        WTRBSP (but need to convert from speed deviation to Speed in pu)
// 102 = PE Real Power Command (pu)                                     WEPCMD
// 103 = PE Reactive Power Command (pu)                                 WEQCMD
// 104 = PE Turbine Blade Pitch (deg)                                   WPITCH
// 105 = PE Turbine Blade Torque (pu)                                   WAEROT 
// 106 = PE Turbine Blade Speed (pu)                                    WTRBPS 
// 107 = PE Auxiliary Control Output (pu)                               WAUXSG
// 108 = PE Rotor Voltage Mag (pu)                                      WROTRV
// 109 = PE Rotor Current Mag (pu)                                      WROTRI
// 110 = PE Rotor Voltage D Component (pu)                              WROTVD
// 111 = PE Rotor Voltage Q Component (pu)                              WROTVQ
// 112 = PE Current D Component (pu)                                    WROTID
// 113 = PE Current Q Component (pu)                                    WROTIQ
// 114 = PE Active Current Command Real Component (pu)                  WIPCMD
// 115 = PE Active Current Command Reactive Component (pu)              WIQCMD
// 116 = PE Voltage Command from Wind Control Q Component(pu)           WEQCMD
// ----------------------------------------------------------------------------------
// TODO - ADD FACTS/HVDC and Aux Model Variable Types
//
}StaticESEInputSignal;

typedef struct _StaticESEOutputSignal
{
   const char_T * const   Name;            // Output signal name
   const char_T * const   BlockPath;       // Path to block in Simulink model
   const int32_T          Width;           // Signal array dimension
   const char_T * const   Unit;            // Units

// Additional Input data needed to automatically create interface to TS Programs
   const int32_T          OutputType;      // Integer Output Signal Type (see full list)

// ----------------------------------------------------------------------------------
// Note - Output Types are the same as the Input Types, but some variables should not be changed by custom models.
// Variables which can be Outputs are:
// ----------------------------------------------------------------------------------
// --------------------------------------------------------------------
// ----------------------MACHINE MODELS-------------------------------- USRMDL(+USRBUS variables)
// --------------------------------------------------------------------
//  5 = Machine Mechanical Power (pu on Machine MVABase)                PMECH
//  6 = Machine Speed(pu)                                               SPEED(but need to convert from speed deviation to Speed in pu)
//  7 = Machine Field Voltage(pu)                                       EFD
    
// 20 = Exciter VoltRef(pu)                                             VREF
// 21 = Exciter VCompensation(pu)                                       ECOMP
// 22 = Exciter StabilizerSignal(pu)                                    VOTHSG
// 23 = Exciter VUEL(pu)                                                VUEL 
// 24 = Exciter VOEL(pu)                                                VOEL

// 30 = Governor SpeedRef(pu)                                           GREF
// 31 = Governor Turbine Load Control Reference                         LCREF        
    
// --------------------------------------------------------------------
// ----------------------BUS MODELS------------------------------------ USRBUS
// --------------------------------------------------------------------
// 43 = Bus Current Injection Real (pu on System MVA Base)              REAL(CURNT)
// 44 = Bus Current Injection Imaginary (deg)                           IMAG(CURNT)

// --------------------------------------------------------------------
// ----------------------1 BUS/SWITCHED SHUNT MODELS------------------- USRSWS(+USRBUS variables)
// --------------------------------------------------------------------
// 80 = Switched Shunt Voltage Reference (pu)                           SWSREF

// --------------------------------------------------------------------
// ----------------------GENERAL INDEX MODELS-------------------------- Accessible for all Model Types
// --------------------------------------------------------------------
// 90 = General Variable                                                VAR
// 91 = State Variable                                                  STATE
// 92 = Deriviative State Variable                                      DSTATE
// 93 = General State Variable Memory                                   STORE

// --------------------------------------------------------------------
// ----------------------POWER ELECTRONIC MODELS----------------------- USRMDL(+USRBUS variables)
// --------------------------------------------------------------------
// 100 = PE Velocity (meters/sec)                                       WVLCTY
// 101 = PE Generator Speed (pu)                                        WTRBSP (but need to convert from speed deviation to Speed in pu)
// 102 = PE Real Power Command (pu)                                     WEPCMD
// 103 = PE Reactive Power Command (pu)                                 WEQCMD
// 104 = PE Turbine Blade Pitch (deg)                                   WPITCH
// 105 = PE Turbine Blade Torque (pu)                                   WAEROT 
// 106 = PE Turbine Blade Speed (pu)                                    WTRBPS 
// 107 = PE Auxiliary Control Output (pu)                               WAUXSG
// 114 = PE Active Current Command Real Component (pu)                  WIPCMD
// 115 = PE Active Current Command Reactive Component (pu)              WIQCMD
// 116 = PE Voltage Command from Wind Control Q Component(pu)           WEQCMD
// ----------------------------------------------------------------------------------
// TODO - ADD FACTS/HVDC and Aux Model Variable Types
//
}StaticESEOutputSignal;



/* Static parameter information; only scalar parameters are allowed */
typedef struct _StaticESEParameter
{
   const char_T * const   Name;          // Parameter name
   const char_T * const   Description;   // Description
   const char_T * const   Unit;          // Unit
   const real64_T         DefaultValue;  // Default value
   const real64_T         MinValue;      // Minimum value
   const real64_T         MaxValue;      // Maximum value
   const int32_T          Type;          // 0 for parameters which can be modified at any time, 1 for parameters which need to be defined at T0 but cannot be changed.
}StaticESEParameter;



/* Union definition added to the static and instance specific structures and may be used for extension*/
typedef union _ESEExtension
{
   int8_T       UserInt8_8[8];
   uint8_T      UserUint8_8[8];
   int16_T      UserInt16_4[4];
   uint16_T     UserUint16_4[4];
   int32_T      UserInt32_2[2];
   uint32_T     UserUint32_2[2];
   char_T       UserChar_8[8];
   real32_T     UserReal32_2[2];
   real64_T     UserReal64;
   void         *UserVoidPtr;
}ESEExtension;



/* Static (not instance specific) model information */
typedef struct _StaticExtSimEnvCapi
{
   const uint8_T                       APIRelease[4];            // Release number of the API used during code generation
   const char_T * const                ModelName;                // Model name
   const char_T * const                ModelVersion;             // Model version
   const char_T * const                ModelDescription;         // Model description
   const char_T * const                VersionControlInfo;       // Version control information
   const char_T * const                GeneralInformation;       // General info - here some RTW info
   const char_T * const                ModelCreated;             // Model created on
   const char_T * const                ModelCreator;             // Model created by
   const char_T * const                ModelLastModifiedDate;    // Model last modified on
   const char_T * const                ModelLastModifiedBy;      // Model last modified by
   const char_T * const                ModelModifiedComment;     // Model modified comment
   const char_T * const                ModelModifiedHistory;     // Model modified history
   const char_T * const                CodeGeneratedOn;          // Code generated on
   const char_T * const                IncludedSolver;           // Solver name (can be empty)
   const real64_T                      FixedStepBaseSampleTime;  // Base sample time
   const int32_T                       NumInputPorts;            // Number of inputs
   const StaticESEInputSignal * const  InputPortsInfo;           // Pointer to input signal description array
   const int32_T                       NumOutputPorts;           // Number of outputs
   const StaticESEOutputSignal * const OutputPortsInfo;          // Pointer to output signal description array
   const int32_T                       NumParameters;            // Number of parameters
   const StaticESEParameter * const    ParametersInfo;           // Pointer to parameter description array
   const int32_T                       NumContStates;            // Number of continuous states
   const int32_T                       SizeofMiscStates;         // Size of work variables / misc states
   const uint32_T                      ModelChecksum[4];         // Simulink model checksum
   const char_T                        *LastErrorMessage;        // Error string pointer
   const uint8_T                       EMT_RMS_Mode;             // Mode: EMT = 1, RMS = 2, EMT & RMS = 3, otherwise: 0
   const uint8_T                       LoadflowFlag;             // Model contains a loadflow function: 0 = no, 1 = yes
// New PSS/E Specific Variables
   const char_T * const                PSSE_ModelType;           // PSS/E Specific Data - ModelType (USRMDL, USRMSC etc.)
   const int32_T                       PSSE_IC;                  // PSS/E Specific Data - IC Model Type Code
// See PSS/E Manual for a full list of IC Codes
   const int32_T                       PSSE_IT;                  // PSS/E Specific Data - IT Code
   const int32_T                       PSSE_DVTYP;               // PSS/E Specific Data - DVTYP used in Aux models
   const int32_T                       PSSE_XGNDX;               // PSS/E Specific Data - XGNDX used in Aux models
// Number of State Variables
   const int32_T                       NumIntStates;             // Number of Integer states
   const int32_T                       NumFloatStates;           // Number of Float states
   const int32_T                       NumDoubleStates;          // Number of Double states
   ESEExtension                        Extension;                // Provided for extensions
}StaticExtSimEnvCapi;



/* Instance specific model information */
typedef struct _InstanceExtSimEnvCapi
{
   real64_T         *ExternalInputs;        // Input signals, all elements in one long vector
   real64_T         *ExternalOutputs;       // Output signals, all elements in one long vector
   real64_T         *Parameters;            // Parameters as vector
   real64_T         *ContinuousStates;      // We assume a states vector - not used in current version
   real64_T         *StateDerivatives;      // We assume a states derivatives vector - not used in current version
   uint8_T          *MiscStates;            // Work variables / states with unknown content
   const char_T     *LastErrorMessage;      // Error string pointer
   const char_T     *LastGeneralMessage;    // General message
   uint8_T          VerboseLevel;           // Decides how much the code "should talk"
   int32_T          *IntStates;             // Int State vector
   real32_T         *FloatStates;           // Float State vector
   real64_T         *DoubleStates;          // Double State vector
   ESEExtension     Extension;              // Provided for extensions
}InstanceExtSimEnvCapi;



/* If macro is defined then you make sure that the function is exported. Importing files must not define this macro */
#ifndef DLL_EXPORT
 #define DLL_EXPORT
#endif





#ifndef EXPORT_DLL
/* Function pointer types used when DLL is loaded explicitely via LoadLibrary */
typedef const StaticExtSimEnvCapi *(FUNCALLTYPE* Model_GetInfo)(void);
typedef InstanceExtSimEnvCapi *(FUNCALLTYPE* Model_Instance)(uint32_T UseSolverInDLL, real64_T Ta);
typedef const char_T *(FUNCALLTYPE* Model_CheckParameters)(InstanceExtSimEnvCapi *pInstanceCapi);
typedef const char_T *(FUNCALLTYPE* Model_Loadflow)(InstanceExtSimEnvCapi *pInstanceCapi);
typedef const char_T *(FUNCALLTYPE* Model_Initialize)(InstanceExtSimEnvCapi *pInstanceCapi);
typedef const char_T *(FUNCALLTYPE* Model_Outputs)(InstanceExtSimEnvCapi *pInstanceCapi, uint32_T IsMajorTimeStep);
typedef const char_T *(FUNCALLTYPE* Model_Update)(InstanceExtSimEnvCapi *pInstanceCapi);
typedef const char_T *(FUNCALLTYPE* Model_Derivatives)(InstanceExtSimEnvCapi *pInstanceCapi);
typedef const char_T *(FUNCALLTYPE* Model_Terminate)(InstanceExtSimEnvCapi *pInstanceCapi);
#endif


#endif /* __IEEE_Cigre_DLLInterface__ */

