/*
 * File: IEEE_Cigre_DLLInterface_types.h
 */
typedef char  int8_T;
typedef unsigned char   uint8_T;
typedef short  int16_T;
typedef unsigned short  uint16_T;
typedef int  int32_T;
typedef unsigned int  uint32_T;
typedef float  real32_T;
typedef double real64_T;
typedef char char_T;