/** @file */
#ifndef __RT_OPAL_STRUCT__H__
#define __RT_OPAL_STRUCT__H__

#include "inttypes.h"

#ifdef __cplusplus
#   include <cmath>
extern "C" {
#else
#   include <math.h>
#endif

#ifndef FALSE
#   define FALSE 0
#endif
#ifndef TRUE
#   define TRUE (!(FALSE))
#endif


/* Modify these version number when the structure/macros are modified */
#define RTOPALSTRUCT_VERSION_MAJOR 3
#define RTOPALSTRUCT_VERSION_MINOR 0
#define RTOPALSTRUCT_VERSION_PATCH 0
#define RTOPALSTRUCT_VERSION_DUMMY 0


/** Declare new instance of the RtOpalStructure
 * @param name[out]: object name to create.
 */
#define rtoDeclare(name) \
    RtOpalStruct name

/** Initialize a previously declared instance of the RtOpalStructure
 * @param name[in]: object name to initialize.
 */
#define rtoInitialize(name) \
    (name).Version[0] = RTOPALSTRUCT_VERSION_MAJOR; \
    (name).Version[1] = RTOPALSTRUCT_VERSION_MINOR; \
    (name).Version[2] = RTOPALSTRUCT_VERSION_PATCH; \
    (name).Version[3] = RTOPALSTRUCT_VERSION_DUMMY; \
    (name).TimeStepSec = 0; \
    (name).StepCount = 0; \
    (name).SimulationTimeSec = 0

/** Create new instance of the RtOpalStructure
 * @param name[out]: object name to create.
 */
#define rtoCreate(name) \
    rtoDeclare(name); \
    rtoInitialize(name)

/** Create new instance of the RtOpalModelStructure
 * @param name[out]: object name to create.
 * @param rtoName[in]: name of the RtOpalStructure previously created with @a rtoCreate().
 */
#define rtoModelCreate(name, rtoName) \
    RtOpalModelStruct name = { \
        &rtoName, 0., 0, 0., 0. \
    }

/** Declare a RtOpalModelStructure
 * @param name[out]: object name to declare.
 */
#define rtoModelDeclare(name) \
    RtOpalModelStruct name

/** Initialize a RtOpalModelStructure
 * @param rtOpalModelStruct[in,out]: RtOpalModelStructure to initialize.
 * @param rtOpalStruct[in]: RtOpalStructure used to initialize the @a rtOpalModelStruct RtOpalModelStructure.
 * @param timeStepSec[in]: model time step in seconds
 */
#define rtoModelInitialize(rtOpalModelStruct, rtOpalStruct, timeStepSec) \
    rtOpalModelStruct.Global = &rtOpalStruct; \
    rtOpalModelStruct.SimulationTimeSec = rtOpalStruct.SimulationTimeSec; \
    rtOpalModelStruct.TimeStepSec = timeStepSec


/** Declare reference to RtOpalStructure from pointer.
 * /!\ The provided pointer must be a valid pointer /!\
 * @param name[out]: reference name
 * @param ptr[in]: void pointer to cast to appropriate type
 */
#define rtoDeclareFromPointer(name, ptr) \
    RtOpalStruct& name = *static_cast<RtOpalStruct*>(ptr);

/** Declare reference to RtOpalModelStructure from pointer.
 * /!\ The provided pointer must be a valid pointer /!\
 * @param name[out]: reference name
 * @param ptr[in]: void pointer to cast to appropriate type
 */
#define rtoModelDeclareFromPointer(name, ptr) \
    RtOpalModelStruct& name = *static_cast<RtOpalModelStruct*>(ptr);


/** Version management
 * @{
 */
/** Check version compatibility
 * - major version numbers mismatch: incompatibility
 * - minor version numbers:
 *   - current minor version is greater or equal to tested minor version: compatibility
 *   - current version number lower than tested minor version: incompatibility
 * - patch version numbers: not tested always compatible
 *
 * @return @a TRUE when the provided structure is compatible with current code implementation, @a FALSE otherwise.
 */
#define rtoCheckCompatibility(s) \
    (rtoGetVersionMajor((s)) != RTOPALSTRUCT_VERSION_MAJOR) \
    ? FALSE \
    : (rtoGetVersionMinor((s)) > RTOPALSTRUCT_VERSION_MINOR) \
        ? FALSE \
        : TRUE
#define rtoModelCheckCompatibility(m) \
    (rtoGetVersionMajor(*(m).Global) != RTOPALSTRUCT_VERSION_MAJOR) \
    ? FALSE \
    : (rtoGetVersionMinor(*(m).Global) > RTOPALSTRUCT_VERSION_MINOR) \
        ? FALSE \
        : TRUE

/** Retrieve major, minor, patch version numbers */
#define rtoGetVersionMajor(s) \
    (s).Version[0]
#define rtoGetVersionMinor(s) \
    (s).Version[1]
#define rtoGetVersionPatch(s) \
    (s).Version[2]

#define rtoModelGetVersionMajor(s) \
    (s).Global->Version[0]
#define rtoModelGetVersionMinor(s) \
    (s).Global->Version[1]
#define rtoModelGetVersionPatch(s) \
    (s).Global->Version[2]
/** @} */


/** Retrieve the simulation time step in seconds */
#define rtoGetTimeStep(s) \
    (s).TimeStepSec
/** Set the simulation time step in seconds */
#define rtoSetTimeStep(s, timeStepS) \
    (s).TimeStepSec = (timeStepS)
/** Retrieve the global simulation time step in seconds */
#define rtoGetGlobalTimeStep(m) \
    (m).Global->TimeStepSec


/** Simulation time
 * @{
 */
/** Retrieve the simulation time in seconds */
#define rtoGetSimulationTime(s) \
    (s).SimulationTimeSec
/** Set the simulation time in seconds
 *
 * IT IS UP TO THE USER TO MAINTAIN COHERENT VALUES BETWEEN STEPS AND SIMULATION TIME.
 */
#define rtoSetSimulationTime(s, simuTimeS) \
    (s).SimulationTimeSec = (simuTimeS)
/** Increment the simulation time for one step */
#define rtoIncrementSimulationTime(s) \
    ++(s).StepCount; \
    (s).SimulationTimeSec = (s).TimeStepSec * (double)((s).StepCount)
/** Increment minor step simulation time */
#define rtoIncrementMinorStepTime(m) \
    ++(m).MinorStepCount; \
    (m).SimulationTimeSec = (m).MajorSimulationTimeSec + (static_cast<double>((m).MinorStepCount) * (m).TimeStepSec)

/** Retrieve the global simulation time in seconds
 * This may be usefull in case of multi-rate and the running model need this value for interpolation/extrapolation
 */
#define rtoGetGlobalSimulationTime(m) \
    (m).Global->SimulationTimeSec
/** Update the model simulation time with the global simulation time */
#define rtoUpdateModelSimulationTime(m) \
    (m).MinorStepCount = 0; \
    (m).MajorSimulationTimeSec = rtoGetGlobalSimulationTime((m)); \
    (m).SimulationTimeSec = rtoGetGlobalSimulationTime((m))
/** @} */

/** Step count
 * @{
 */
/** Retrieve the number of steps */
#define rtoGetStepCount(s) \
    (s).StepCount
/** Set the number of steps.
 *
 * IT IS UP TO THE USER TO MAINTAIN COHERENT VALUES BETWEEN STEPS AND SIMULATION TIME.
 */
#define rtoSetStepCount(s, stepCount) \
    (s).StepCount = stepCount
/** @} */


/** Main RT structure for all Opal global variables */
typedef struct {
    uint8_t Version[4];        ///< Version of the extension <major>.<minor>.<fix> (<unused>)
    double TimeStepSec;        ///< Main time step in seconds
    uint64_t StepCount;        ///< Number of simulation steps for the whole simulation
    double SimulationTimeSec;  ///< Simulation time in seconds
} RtOpalStruct;

/** RT structure for model variables */
typedef struct {
    const RtOpalStruct* Global;     ///< Pointer to RtOpalStruct
    double TimeStepSec;             ///< Model time step in seconds
    uint64_t MinorStepCount;        ///< Number of minor simulation (ie model) steps between two major simulation steps
    double SimulationTimeSec;       ///< Local simulation time in case of multi-rate system
    double MajorSimulationTimeSec;  ///< Simulation time synchronized with main simulation time (see @a rtoUpdateModelSimulationTime)
} RtOpalModelStruct;

#ifdef __cplusplus
}
#endif

#endif // __RT_OPAL_STRUCT__H__
