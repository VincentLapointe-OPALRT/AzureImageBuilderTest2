# UCM : cigre_PMU_clk

## Compilation

Copy folder `include` that contains CIGRE include files to hyconfig/cigre-pmu-clk folder, for example `C:\OPAL-RT\HYPERSIM\hyconfig\cigre-pmu-clk\include`.

## Execution

Copy `CigrePMUClk.dll` to `C:\OPAL-RT\HYPERSIM\hyconfig\cigre-pmu-clk\bin`